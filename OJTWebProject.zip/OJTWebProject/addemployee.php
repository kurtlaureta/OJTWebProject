<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php";

$message = "";
$errors = [];

/* =========================
   DEFAULT VALUES
========================= */
$fields = [
    "first_name" => "",
    "middle_name" => "",
    "last_name" => "",
    "suffix" => "",
    "birthdate" => "",
    "gender" => "",
    "civil_status" => "",
    "birthplace" => "",
    "contact_number" => "",
    "permanent_address" => "",
    "present_address" => "",
    "present_address_alt" => "",

    "father_name" => "",
    "mother_name" => "",
    "emergency_person" => "",
    "emergency_number" => "",
    "education" => "",
    "course" => "",

    "employee_id" => "",
    "hris_id" => "",
    "store_code" => "",
    "department" => "",
    "position" => "",
    "hire_date" => "",
    "regularization_date" => "",
    "end_of_employment" => "",
    "employment_status" => "",
    "assigned_area" => "",

    "salary_basis" => "",
    "rate" => "",
    "basic_salary" => "",
    "kpi" => "",
    "accommodation" => "",

    "personal_email" => "",
    "company_email" => "",
    "region" => "",

    "tin_no" => "",
    "sss_no" => "",
    "philhealth_no" => "",
    "pagibig_no" => "",

    "medical" => "0",
    "id_file" => "0",
    "contract" => "0"
];

foreach ($fields as $key => $value) {
    $$key = $value;
}

/* =========================
   HELPERS
========================= */
function clean_input($value)
{
    return trim((string)($value ?? ""));
}

function is_valid_name($value)
{
    return preg_match("/^[a-zA-Z\s.'-]+$/", $value);
}

function is_valid_email_custom($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function is_valid_decimal($value)
{
    return preg_match('/^\d+(\.\d{1,2})?$/', $value);
}

function normalize_gov_id($value)
{
    return preg_replace('/\D+/', '', (string)$value);
}

function old($name)
{
    global $$name;
    return htmlspecialchars($$name ?? "");
}

function error_text($name)
{
    global $errors;
    return isset($errors[$name])
        ? '<p class="text-red-600 text-xs mt-1">' . htmlspecialchars($errors[$name]) . '</p>'
        : '';
}

function checked_value($name)
{
    global $$name;
    return ($$name === "1" || $$name === 1) ? 'checked' : '';
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    foreach ($fields as $key => $value) {
        if (in_array($key, ["medical", "id_file", "contract"], true)) {
            $$key = isset($_POST[$key]) ? "1" : "0";
        } else {
            $$key = clean_input($_POST[$key] ?? "");
        }
    }

    /* =========================
       REQUIRED FIELDS
    ========================= */
    $required = [
        "first_name" => "First name is required.",
        "last_name" => "Last name is required.",
        "employee_id" => "Employee ID is required.",
        "contact_number" => "Contact number is required.",
        "birthdate" => "Birthdate is required.",
        "gender" => "Gender is required.",
        "civil_status" => "Civil status is required.",
        "hire_date" => "Hire date is required.",
        "employment_status" => "Employment status is required."
    ];

    foreach ($required as $field => $msg) {
        if ($$field === "") {
            $errors[$field] = $msg;
        }
    }

    /* =========================
       NAME VALIDATION
    ========================= */
    $name_fields = [
        "first_name" => "First name",
        "middle_name" => "Middle name",
        "last_name" => "Last name",
        "father_name" => "Father's name",
        "mother_name" => "Mother's name",
        "emergency_person" => "Emergency contact person"
    ];

    foreach ($name_fields as $field => $label) {
        if ($$field !== "" && !is_valid_name($$field)) {
            $errors[$field] = $label . " contains invalid characters.";
        }
    }

    /* =========================
       PHONE VALIDATION
    ========================= */
    if ($contact_number !== "" && !preg_match('/^09\d{9}$/', $contact_number)) {
        $errors["contact_number"] = "Contact number must be exactly 11 digits and start with 09.";
    }

    if ($emergency_number !== "" && !preg_match('/^09\d{9}$/', $emergency_number)) {
        $errors["emergency_number"] = "Emergency number must be exactly 11 digits and start with 09.";
    }

    /* =========================
       EMPLOYEE ID / CODE VALIDATION
    ========================= */
    if ($employee_id !== "" && !preg_match('/^[A-Za-z0-9_-]+$/', $employee_id)) {
        $errors["employee_id"] = "Employee ID must only contain letters, numbers, dash, or underscore.";
    }

    if ($hris_id !== "" && !preg_match('/^[A-Za-z0-9_-]+$/', $hris_id)) {
        $errors["hris_id"] = "HRIS ID must only contain letters, numbers, dash, or underscore.";
    }

    if ($store_code !== "" && !preg_match('/^[A-Za-z0-9_\-\s]+$/', $store_code)) {
        $errors["store_code"] = "Store code contains invalid characters.";
    }

    /* =========================
       VALID CHOICES
    ========================= */
    $valid_genders = ["Male", "Female"];
    $valid_civil_status = ["Single", "Married", "Widowed"];
    $valid_education = ["High School", "College Level", "College Graduate", "Vocational"];
    $valid_employment_status = ["Probationary", "Regular", "Resigned", "Terminated", "Active"];
    $valid_salary_basis = ["Daily", "Weekly", "Semi-Monthly", "Monthly"];

    if ($gender !== "" && !in_array($gender, $valid_genders, true)) {
        $errors["gender"] = "Invalid gender selected.";
    }

    if ($civil_status !== "" && !in_array($civil_status, $valid_civil_status, true)) {
        $errors["civil_status"] = "Invalid civil status selected.";
    }

    if ($education !== "" && !in_array($education, $valid_education, true)) {
        $errors["education"] = "Invalid educational attainment selected.";
    }

    if ($employment_status !== "" && !in_array($employment_status, $valid_employment_status, true)) {
        $errors["employment_status"] = "Invalid employment status selected.";
    }

    if ($salary_basis !== "" && !in_array($salary_basis, $valid_salary_basis, true)) {
        $errors["salary_basis"] = "Invalid salary basis selected.";
    }

    /* =========================
       EMAIL VALIDATION
    ========================= */
    if ($personal_email !== "" && !is_valid_email_custom($personal_email)) {
        $errors["personal_email"] = "Invalid personal email format.";
    }

    if ($company_email !== "" && !is_valid_email_custom($company_email)) {
        $errors["company_email"] = "Invalid company email format.";
    }

    /* =========================
       NUMBER / MONEY VALIDATION
    ========================= */
    $decimal_fields = [
        "rate" => "Rate",
        "basic_salary" => "Basic salary",
        "kpi" => "KPI",
        "accommodation" => "Accommodation"
    ];

    foreach ($decimal_fields as $field => $label) {
        if ($$field !== "" && !is_valid_decimal($$field)) {
            $errors[$field] = $label . " must be a valid number with up to 2 decimal places.";
        }
    }

    /* =========================
       GOVERNMENT ID VALIDATION
    ========================= */
    $tin_no = normalize_gov_id($tin_no);
    $sss_no = normalize_gov_id($sss_no);
    $philhealth_no = normalize_gov_id($philhealth_no);
    $pagibig_no = normalize_gov_id($pagibig_no);

    if ($tin_no !== "" && !in_array(strlen($tin_no), [9, 12], true)) {
        $errors["tin_no"] = "TIN number must be exactly 9 or 12 digits.";
    }

    if ($sss_no !== "" && strlen($sss_no) !== 10) {
        $errors["sss_no"] = "SSS number must be exactly 10 digits.";
    }

    if ($philhealth_no !== "" && strlen($philhealth_no) !== 12) {
        $errors["philhealth_no"] = "PhilHealth number must be exactly 12 digits.";
    }

    if ($pagibig_no !== "" && strlen($pagibig_no) !== 12) {
        $errors["pagibig_no"] = "PAG-IBIG number must be exactly 12 digits.";
    }

    /* =========================
       DATE VALIDATION
    ========================= */
    $today = date("Y-m-d");

    $date_fields = [
        "birthdate" => "Birthdate",
        "hire_date" => "Hire date",
        "regularization_date" => "Regularization date",
        "end_of_employment" => "End of employment"
    ];

    foreach ($date_fields as $field => $label) {
        if ($$field !== "") {
            $obj = DateTime::createFromFormat("Y-m-d", $$field);
            if (!$obj || $obj->format("Y-m-d") !== $$field) {
                $errors[$field] = "Invalid " . strtolower($label) . ".";
            }
        }
    }

    if ($birthdate !== "" && !isset($errors["birthdate"]) && $birthdate > $today) {
        $errors["birthdate"] = "Birthdate cannot be in the future.";
    }

    if ($hire_date !== "" && !isset($errors["hire_date"]) && $hire_date > $today) {
        $errors["hire_date"] = "Hire date cannot be in the future.";
    }

    if (
        $birthdate !== "" && $hire_date !== "" &&
        !isset($errors["birthdate"]) && !isset($errors["hire_date"])
    ) {
        $birth_ts = strtotime($birthdate);
        $hire_ts = strtotime($hire_date);

        if ($hire_ts < $birth_ts) {
            $errors["hire_date"] = "Hire date cannot be earlier than birthdate.";
        } else {
            $age_at_hire = date_diff(date_create($birthdate), date_create($hire_date))->y;
            if ($age_at_hire < 16) {
                $errors["hire_date"] = "Employee age at hire must be at least 16 years old.";
            }
        }
    }

    if (
        $regularization_date !== "" && $hire_date !== "" &&
        !isset($errors["regularization_date"]) && !isset($errors["hire_date"])
    ) {
        if (strtotime($regularization_date) < strtotime($hire_date)) {
            $errors["regularization_date"] = "Regularization date cannot be earlier than hire date.";
        }
    }

    if (
        $end_of_employment !== "" && $hire_date !== "" &&
        !isset($errors["end_of_employment"]) && !isset($errors["hire_date"])
    ) {
        if (strtotime($end_of_employment) < strtotime($hire_date)) {
            $errors["end_of_employment"] = "End of employment cannot be earlier than hire date.";
        }
    }

    if (in_array($employment_status, ["Resigned", "Terminated"], true) && $end_of_employment === "") {
        $errors["end_of_employment"] = "End of employment is required for resigned or terminated employees.";
    }

    if (in_array($employment_status, ["Active", "Probationary", "Regular"], true) && $end_of_employment !== "") {
        $errors["end_of_employment"] = "End of employment should be blank for active employees.";
    }

    /* =========================
       AUTO COMPLETE NAME
    ========================= */
    $complete_name = trim(
        $first_name .
        ($middle_name !== "" ? " " . $middle_name : "") .
        " " . $last_name .
        ($suffix !== "" ? " " . $suffix : "")
    );

    /* =========================
       DUPLICATE CHECKS
    ========================= */
    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM employees WHERE employee_id = ?");
        if ($stmt) {
            $stmt->bind_param("s", $employee_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            if ((int)($row["total"] ?? 0) > 0) {
                $errors["employee_id"] = "Employee ID already exists.";
            }
            $stmt->close();
        } else {
            $message = "Failed to prepare employee ID duplicate check.";
        }
    }

    if (empty($errors) && $company_email !== "") {
        $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM employees WHERE company_email = ?");
        if ($stmt) {
            $stmt->bind_param("s", $company_email);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            if ((int)($row["total"] ?? 0) > 0) {
                $errors["company_email"] = "Company email already exists.";
            }
            $stmt->close();
        }
    }

    if (empty($errors) && $tin_no !== "") {
        $stmt = $conn->prepare("
            SELECT COUNT(*) AS total
            FROM employees
            WHERE REPLACE(REPLACE(REPLACE(tin_no, '-', ''), ' ', ''), '.', '') = ?
        ");
        if ($stmt) {
            $stmt->bind_param("s", $tin_no);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            if ((int)($row["total"] ?? 0) > 0) {
                $errors["tin_no"] = "TIN number already exists.";
            }
            $stmt->close();
        }
    }

    if (empty($errors) && $sss_no !== "") {
        $stmt = $conn->prepare("
            SELECT COUNT(*) AS total
            FROM employees
            WHERE REPLACE(REPLACE(REPLACE(sss_no, '-', ''), ' ', ''), '.', '') = ?
        ");
        if ($stmt) {
            $stmt->bind_param("s", $sss_no);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            if ((int)($row["total"] ?? 0) > 0) {
                $errors["sss_no"] = "SSS number already exists.";
            }
            $stmt->close();
        }
    }

    if (empty($errors) && $philhealth_no !== "") {
        $stmt = $conn->prepare("
            SELECT COUNT(*) AS total
            FROM employees
            WHERE REPLACE(REPLACE(REPLACE(philhealth_no, '-', ''), ' ', ''), '.', '') = ?
        ");
        if ($stmt) {
            $stmt->bind_param("s", $philhealth_no);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            if ((int)($row["total"] ?? 0) > 0) {
                $errors["philhealth_no"] = "PhilHealth number already exists.";
            }
            $stmt->close();
        }
    }

    if (empty($errors) && $pagibig_no !== "") {
        $stmt = $conn->prepare("
            SELECT COUNT(*) AS total
            FROM employees
            WHERE REPLACE(REPLACE(REPLACE(pagibig_no, '-', ''), ' ', ''), '.', '') = ?
        ");
        if ($stmt) {
            $stmt->bind_param("s", $pagibig_no);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            if ((int)($row["total"] ?? 0) > 0) {
                $errors["pagibig_no"] = "PAG-IBIG number already exists.";
            }
            $stmt->close();
        }
    }

    /* =========================
       INSERT
    ========================= */
    if (empty($errors) && $message === "") {
        $sql = "INSERT INTO employees (
            first_name, middle_name, last_name, suffix, complete_name,
            birthdate, gender, civil_status, birthplace, contact_number,
            permanent_address, present_address, present_address_alt,
            father_name, mother_name, emergency_person, emergency_number,
            education, course,
            employee_id, hris_id, store_code,
            department, position, hire_date, regularization_date, end_of_employment,
            employment_status, assigned_area,
            salary_basis, rate, basic_salary, kpi, accommodation,
            personal_email, company_email, region,
            tin_no, sss_no, philhealth_no, pagibig_no,
            medical, id_file, contract
        ) VALUES (
            ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?,
            ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?,
            ?, ?, ?,
            ?, ?, ?, ?, ?,
            ?, ?,
            ?, ?, ?, ?, ?,
            ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?
        )";

        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param(
                "ssssssssssssssssssssssssssssssssssssssssssss",
                $first_name, $middle_name, $last_name, $suffix, $complete_name,
                $birthdate, $gender, $civil_status, $birthplace, $contact_number,
                $permanent_address, $present_address, $present_address_alt,
                $father_name, $mother_name, $emergency_person, $emergency_number,
                $education, $course,
                $employee_id, $hris_id, $store_code,
                $department, $position, $hire_date, $regularization_date, $end_of_employment,
                $employment_status, $assigned_area,
                $salary_basis, $rate, $basic_salary, $kpi, $accommodation,
                $personal_email, $company_email, $region,
                $tin_no, $sss_no, $philhealth_no, $pagibig_no,
                $medical, $id_file, $contract
            );

            if ($stmt->execute()) {
                header("Location: employee.php?added=1");
                exit;
            } else {
                $message = "Error saving employee: " . $stmt->error;
            }

            $stmt->close();
        } else {
            $message = "Failed to prepare insert query.";
        }
    }

    if (!empty($errors) && $message === "") {
        $message = "Please fix the highlighted fields below.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../index.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <title>Add Employee</title>
</head>
<body class="flex overflow-x-hidden bg-gray-100">
<?php include 'navbar.php'; ?>

<section class="flex-1 min-h-screen ml-47">
    <nav class="bg-gray-200 w-full h-auto p-4 shadow-md shadow-gray-500">
        <div class="flex justify-between items-center flex-wrap gap-3">
            <div class="bg-blue-400 p-1 px-4 rounded-3xl cursor-pointer text-white duration-200 transition-all hover:bg-blue-700 w-fit">
                <a href="employee.php" class="flex w-auto h-auto items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 mr-1">
                        <path fill-rule="evenodd" d="M9.53 2.47a.75.75 0 0 1 0 1.06L4.81 8.25H15a6.75 6.75 0 0 1 0 13.5h-3a.75.75 0 0 1 0-1.5h3a5.25 5.25 0 1 0 0-10.5H4.81l4.72 4.72a.75.75 0 1 1-1.06 1.06l-6-6a.75.75 0 0 1 0-1.06l6-6a.75.75 0 0 1 1.06 0Z" clip-rule="evenodd" />
                    </svg>
                    Back
                </a>
            </div>

            <div class="flex items-center font-bold text-black p-2 px-4 rounded-2xl">
                ADD EMPLOYEE
            </div>

            <div class="flex text-[10px] font-bold text-black items-center">
                WH1 SANTA ROSA
            </div>
        </div>
    </nav>

    <section class="p-3 flex justify-center">
        <div class="border-2 p-3 w-full max-w-7xl bg-white rounded-2xl shadow">
            <div class="w-full mx-auto px-6 py-6">

                <?php if (!empty($message)): ?>
                    <div class="mb-4 rounded-xl bg-red-100 text-red-700 px-4 py-3">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" id="employeeForm" class="grid grid-cols-1 xl:grid-cols-2 gap-6" novalidate>

                    <div class="bg-white border border-gray-200 rounded-3xl shadow-sm p-6">
                        <h2 class="text-lg font-bold text-center text-black mb-5">Personal Details</h2>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-semibold mb-1">First Name</label>
                                <input type="text" name="first_name" value="<?php echo old('first_name'); ?>" placeholder="First Name" class="w-full rounded-2xl border <?php echo isset($errors['first_name']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('first_name'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Middle Name</label>
                                <input type="text" name="middle_name" value="<?php echo old('middle_name'); ?>" placeholder="Middle Name" class="w-full rounded-2xl border <?php echo isset($errors['middle_name']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('middle_name'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Last Name</label>
                                <input type="text" name="last_name" value="<?php echo old('last_name'); ?>" placeholder="Last Name" class="w-full rounded-2xl border <?php echo isset($errors['last_name']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('last_name'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Suffix</label>
                                <input type="text" name="suffix" value="<?php echo old('suffix'); ?>" placeholder="Suffix (Jr., Sr., III)" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Birthdate</label>
                                <input type="date" name="birthdate" title="Birthdate" value="<?php echo old('birthdate'); ?>" class="w-full rounded-2xl border <?php echo isset($errors['birthdate']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('birthdate'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Gender</label>
                                <select name="gender" class="w-full rounded-2xl border <?php echo isset($errors['gender']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <option value="">Gender</option>
                                    <option value="Male" <?php echo ($gender === "Male") ? "selected" : ""; ?>>Male</option>
                                    <option value="Female" <?php echo ($gender === "Female") ? "selected" : ""; ?>>Female</option>
                                </select>
                                <?php echo error_text('gender'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Civil Status</label>
                                <select name="civil_status" class="w-full rounded-2xl border <?php echo isset($errors['civil_status']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <option value="">Civil Status</option>
                                    <option value="Single" <?php echo ($civil_status === "Single") ? "selected" : ""; ?>>Single</option>
                                    <option value="Married" <?php echo ($civil_status === "Married") ? "selected" : ""; ?>>Married</option>
                                    <option value="Widowed" <?php echo ($civil_status === "Widowed") ? "selected" : ""; ?>>Widowed</option>
                                </select>
                                <?php echo error_text('civil_status'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Birth Place</label>
                                <input type="text" name="birthplace" value="<?php echo old('birthplace'); ?>" placeholder="Birth Place" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                            </div>

                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold mb-1">Contact Number</label>
                                <input type="tel" id="contact_number" name="contact_number" maxlength="11" value="<?php echo old('contact_number'); ?>" placeholder="Contact Number" class="w-full rounded-2xl border <?php echo isset($errors['contact_number']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('contact_number'); ?>
                            </div>

                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold mb-1">Permanent Address</label>
                                <textarea name="permanent_address" placeholder="Permanent Address" rows="3" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm resize-none"><?php echo old('permanent_address'); ?></textarea>
                            </div>

                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold mb-1">Present Address</label>
                                <textarea name="present_address" placeholder="Present Address" rows="3" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm resize-none"><?php echo old('present_address'); ?></textarea>
                            </div>

                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold mb-1">Emergency Contact Address</label>
                                <textarea name="present_address_alt" placeholder="Emergency Contact Address" rows="3" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm resize-none"><?php echo old('present_address_alt'); ?></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white border border-gray-200 rounded-3xl shadow-sm p-6">
                        <h2 class="text-lg font-bold text-center text-black mb-5">Family / Emergency / Education</h2>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold mb-1">Father's Name</label>
                                <input type="text" name="father_name" value="<?php echo old('father_name'); ?>" placeholder="Father's Name" class="w-full rounded-2xl border <?php echo isset($errors['father_name']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('father_name'); ?>
                            </div>

                            <div class="md:col-span-2">
                                <label class="block text-sm font-semibold mb-1">Mother's Maiden Name</label>
                                <input type="text" name="mother_name" value="<?php echo old('mother_name'); ?>" placeholder="Mother's Maiden Name" class="w-full rounded-2xl border <?php echo isset($errors['mother_name']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('mother_name'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Emergency Contact Person</label>
                                <input type="text" name="emergency_person" value="<?php echo old('emergency_person'); ?>" placeholder="Emergency Contact Person" class="w-full rounded-2xl border <?php echo isset($errors['emergency_person']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('emergency_person'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Emergency Contact Number</label>
                                <input type="tel" id="emergency_number" name="emergency_number" maxlength="11" value="<?php echo old('emergency_number'); ?>" placeholder="Emergency Contact Number" class="w-full rounded-2xl border <?php echo isset($errors['emergency_number']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('emergency_number'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Educational Attainment</label>
                                <select name="education" class="w-full rounded-2xl border <?php echo isset($errors['education']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <option value="">Educational Attainment</option>
                                    <option value="High School" <?php echo ($education === "High School") ? "selected" : ""; ?>>High School</option>
                                    <option value="College Level" <?php echo ($education === "College Level") ? "selected" : ""; ?>>College Level</option>
                                    <option value="College Graduate" <?php echo ($education === "College Graduate") ? "selected" : ""; ?>>College Graduate</option>
                                    <option value="Vocational" <?php echo ($education === "Vocational") ? "selected" : ""; ?>>Vocational</option>
                                </select>
                                <?php echo error_text('education'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Course of Study</label>
                                <input type="text" name="course" value="<?php echo old('course'); ?>" placeholder="Course of Study" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                            </div>
                        </div>
                    </div>

                    <div class="bg-white border border-gray-200 rounded-3xl shadow-sm p-6 xl:col-span-2">
                        <h2 class="text-lg font-bold text-center text-black mb-5">Company / Payroll / IDs</h2>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="block text-sm font-semibold mb-1">Employee Number</label>
                                <input type="text" name="employee_id" id="employee_id" value="<?php echo old('employee_id'); ?>" placeholder="Employee Number" class="w-full rounded-2xl border <?php echo isset($errors['employee_id']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('employee_id'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">HRIS ID</label>
                                <input type="text" name="hris_id" value="<?php echo old('hris_id'); ?>" placeholder="HRIS ID#" class="w-full rounded-2xl border <?php echo isset($errors['hris_id']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('hris_id'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Store Code</label>
                                <input type="text" name="store_code" value="<?php echo old('store_code'); ?>" placeholder="Store Code" class="w-full rounded-2xl border <?php echo isset($errors['store_code']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('store_code'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Area / Assigned Branch</label>
                                <input type="text" name="assigned_area" value="<?php echo old('assigned_area'); ?>" placeholder="Area / Assigned Branch" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Position</label>
                                <input type="text" name="position" value="<?php echo old('position'); ?>" placeholder="Position" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Department</label>
                                <input type="text" name="department" value="<?php echo old('department'); ?>" placeholder="Department" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Hire Date</label>
                                <input type="date" name="hire_date" title="Hire Date" value="<?php echo old('hire_date'); ?>" class="w-full rounded-2xl border <?php echo isset($errors['hire_date']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('hire_date'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Regularization Date</label>
                                <input type="date" name="regularization_date" title="Regularization Date" value="<?php echo old('regularization_date'); ?>" class="w-full rounded-2xl border <?php echo isset($errors['regularization_date']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('regularization_date'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">End of Employment</label>
                                <input type="date" name="end_of_employment" title="End of Employment" value="<?php echo old('end_of_employment'); ?>" class="w-full rounded-2xl border <?php echo isset($errors['end_of_employment']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('end_of_employment'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Employment Status</label>
                                <select name="employment_status" class="w-full rounded-2xl border <?php echo isset($errors['employment_status']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <option value="">Employment Status</option>
                                    <option value="Active" <?php echo ($employment_status === "Active") ? "selected" : ""; ?>>Active</option>
                                    <option value="Probationary" <?php echo ($employment_status === "Probationary") ? "selected" : ""; ?>>Probationary</option>
                                    <option value="Regular" <?php echo ($employment_status === "Regular") ? "selected" : ""; ?>>Regular</option>
                                    <option value="Resigned" <?php echo ($employment_status === "Resigned") ? "selected" : ""; ?>>Resigned</option>
                                    <option value="Terminated" <?php echo ($employment_status === "Terminated") ? "selected" : ""; ?>>Terminated</option>
                                </select>
                                <?php echo error_text('employment_status'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Salary Basis</label>
                                <select name="salary_basis" class="w-full rounded-2xl border <?php echo isset($errors['salary_basis']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <option value="">Salary Basis</option>
                                    <option value="Daily" <?php echo ($salary_basis === "Daily") ? "selected" : ""; ?>>Daily</option>
                                    <option value="Weekly" <?php echo ($salary_basis === "Weekly") ? "selected" : ""; ?>>Weekly</option>
                                    <option value="Semi-Monthly" <?php echo ($salary_basis === "Semi-Monthly") ? "selected" : ""; ?>>Semi-Monthly</option>
                                    <option value="Monthly" <?php echo ($salary_basis === "Monthly") ? "selected" : ""; ?>>Monthly</option>
                                </select>
                                <?php echo error_text('salary_basis'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Rate</label>
                                <input type="text" name="rate" value="<?php echo old('rate'); ?>" placeholder="Rate" class="w-full rounded-2xl border <?php echo isset($errors['rate']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('rate'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Basic Salary</label>
                                <input type="text" name="basic_salary" value="<?php echo old('basic_salary'); ?>" placeholder="Basic Salary" class="w-full rounded-2xl border <?php echo isset($errors['basic_salary']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('basic_salary'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">KPI</label>
                                <input type="text" name="kpi" value="<?php echo old('kpi'); ?>" placeholder="KPI" class="w-full rounded-2xl border <?php echo isset($errors['kpi']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('kpi'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Accommodation (Transpo/Food)</label>
                                <input type="text" name="accommodation" value="<?php echo old('accommodation'); ?>" placeholder="Accommodation (Transpo/Food)" class="w-full rounded-2xl border <?php echo isset($errors['accommodation']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('accommodation'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Personal Email</label>
                                <input type="email" name="personal_email" value="<?php echo old('personal_email'); ?>" placeholder="Personal Email" class="w-full rounded-2xl border <?php echo isset($errors['personal_email']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('personal_email'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Company Email</label>
                                <input type="email" name="company_email" value="<?php echo old('company_email'); ?>" placeholder="Company Email" class="w-full rounded-2xl border <?php echo isset($errors['company_email']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('company_email'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">Region</label>
                                <input type="text" name="region" value="<?php echo old('region'); ?>" placeholder="Region" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">TIN No.</label>
                                <input type="text" name="tin_no" value="<?php echo old('tin_no'); ?>" placeholder="TIN No." class="w-full rounded-2xl border <?php echo isset($errors['tin_no']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('tin_no'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">SSS No.</label>
                                <input type="text" name="sss_no" value="<?php echo old('sss_no'); ?>" placeholder="SSS No." class="w-full rounded-2xl border <?php echo isset($errors['sss_no']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('sss_no'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">PhilHealth No.</label>
                                <input type="text" name="philhealth_no" value="<?php echo old('philhealth_no'); ?>" placeholder="PhilHealth No." class="w-full rounded-2xl border <?php echo isset($errors['philhealth_no']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('philhealth_no'); ?>
                            </div>

                            <div>
                                <label class="block text-sm font-semibold mb-1">PAG-IBIG No.</label>
                                <input type="text" name="pagibig_no" value="<?php echo old('pagibig_no'); ?>" placeholder="PAG-IBIG No." class="w-full rounded-2xl border <?php echo isset($errors['pagibig_no']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                <?php echo error_text('pagibig_no'); ?>
                            </div>

                            <div class="md:col-span-3">
                                <label class="block text-sm font-semibold mb-2">Document Checklist</label>
                                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                    <label class="flex items-center gap-2 rounded-2xl border border-gray-300 bg-gray-100 px-4 py-3 cursor-pointer">
                                        <input type="checkbox" name="medical" value="1" <?php echo checked_value('medical'); ?>>
                                        <span>Medical</span>
                                    </label>

                                    <label class="flex items-center gap-2 rounded-2xl border border-gray-300 bg-gray-100 px-4 py-3 cursor-pointer">
                                        <input type="checkbox" name="id_file" value="1" <?php echo checked_value('id_file'); ?>>
                                        <span>ID</span>
                                    </label>

                                    <label class="flex items-center gap-2 rounded-2xl border border-gray-300 bg-gray-100 px-4 py-3 cursor-pointer">
                                        <input type="checkbox" name="contract" value="1" <?php echo checked_value('contract'); ?>>
                                        <span>Contract</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="xl:col-span-2 flex justify-end gap-3">
                        <button type="button" onclick="window.location.href='employee.php'" class="px-5 py-3 cursor-pointer rounded-2xl bg-red-500 text-black hover:bg-red-800 transition">
                            Cancel
                        </button>

                        <button type="submit" class="px-6 py-3 rounded-2xl bg-blue-600 text-white font-medium hover:bg-blue-800 transition cursor-pointer">
                            Save Employee
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</section>

<script>
document.getElementById("employeeForm").addEventListener("submit", function () {
    let hasError = false;

    const contactNumber = document.getElementById("contact_number").value.trim();
    const emergencyNumber = document.getElementById("emergency_number").value.trim();
    const employeeId = document.getElementById("employee_id").value.trim();

    if (!/^09\d{9}$/.test(contactNumber)) {
        hasError = true;
    }

    if (emergencyNumber !== "" && !/^09\d{9}$/.test(emergencyNumber)) {
        hasError = true;
    }

    if (employeeId !== "" && !/^[A-Za-z0-9_-]+$/.test(employeeId)) {
        hasError = true;
    }

    if (hasError) {
        // PHP will display exact errors
    }
});
</script>
</body>
</html>
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int) $_SESSION["user_id"];

$conn->query("SET time_zone = '+08:00'");

$stmt = $conn->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result ? $result->fetch_assoc() : null;

if (!$user || $user["role"] !== "admin") {
    header("Location: home.php");
    exit;
}

/*
|---------------------------------------------------
| Mark current user as online + refresh last_activity
|---------------------------------------------------
*/
$update = $conn->prepare("UPDATE users SET status = 'online', last_activity = NOW() WHERE id = ?");
$update->bind_param("i", $user_id);
$update->execute();
?>
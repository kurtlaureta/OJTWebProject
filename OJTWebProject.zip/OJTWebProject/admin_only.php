<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION["user_id"], $_SESSION["session_token"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION["user_id"];

$conn->query("SET time_zone = '+08:00'");

$stmt = $conn->prepare("SELECT id, username, role, session_token FROM users WHERE id = ? LIMIT 1");
if (!$stmt) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result ? $result->fetch_assoc() : null;
$stmt->close();

if (!$user) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

/* =========================
   VALIDATE SESSION TOKEN
========================= */
if (
    empty($user["session_token"]) ||
    !hash_equals($user["session_token"], $_SESSION["session_token"])
) {
    session_unset();
    session_destroy();
    header("Location: login.php?session_expired=1");
    exit;
}

/* =========================
   ADMIN CHECK
========================= */
if (strtolower(trim($user["role"] ?? "")) !== "admin") {
    header("Location: user_home.php");
    exit;
}

/* =========================
   REFRESH SESSION VALUES
========================= */
$_SESSION["username"] = $user["username"];
$_SESSION["role"] = strtolower(trim($user["role"]));

/* =========================
   MARK CURRENT USER ONLINE
========================= */
$update = $conn->prepare("UPDATE users SET status = 'online', last_activity = NOW() WHERE id = ?");
if ($update) {
    $update->bind_param("i", $user_id);
    $update->execute();
    $update->close();
}
?>
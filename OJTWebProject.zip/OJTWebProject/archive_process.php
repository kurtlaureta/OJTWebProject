<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php";

$id = (int)($_POST["id"] ?? $_GET["id"] ?? 0);
$status = trim($_POST["status"] ?? $_GET["status"] ?? "Terminated");
$separation_date = trim($_POST["separation_date"] ?? $_GET["separation_date"] ?? date("Y-m-d"));

$allowed_statuses = ["Terminated", "Resigned", "Banned"];
if (!in_array($status, $allowed_statuses, true)) {
    $status = "Terminated";
}

if ($id <= 0) {
    header("Location: employee.php");
    exit;
}

if ($separation_date === "") {
    $separation_date = date("Y-m-d");
}

$date_obj = DateTime::createFromFormat("Y-m-d", $separation_date);
if (!$date_obj || $date_obj->format("Y-m-d") !== $separation_date) {
    die("Invalid separation date.");
}

/*
|--------------------------------------------------------------------------
| Save "Banned" as 2 in DB
|--------------------------------------------------------------------------
*/
$dbStatus = ($status === "Banned") ? "2" : $status;

$sql = "UPDATE employees 
        SET employment_status = ?, 
            separation_date = ?, 
            is_archived = 1
        WHERE id = ?";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("ssi", $dbStatus, $separation_date, $id);

if ($stmt->execute()) {
    $stmt->close();
    header("Location: employee.php?msg=archived");
    exit;
} else {
    $error = $stmt->error;
    $stmt->close();
    die("Error archiving employee: " . $error);
}
?>
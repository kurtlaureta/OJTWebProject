<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php";

$id = (int)($_GET["id"] ?? 0);
$status = trim($_GET["status"] ?? "Terminated");

$allowed_statuses = ["Terminated", "Resigned"];
if (!in_array($status, $allowed_statuses, true)) {
    $status = "Terminated";
}

if ($id <= 0) {
    header("Location: employee.php");
    exit;
}

$sql = "UPDATE employees 
        SET employment_status = ?, is_archived = 1
        WHERE id = ?";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("si", $status, $id);

if ($stmt->execute()) {
    $stmt->close();
    header("Location: employee.php?msg=archived");
    exit;
} else {
    $error = $stmt->error;
    $stmt->close();
    die("Error archiving employee: " . $error);
}
?>
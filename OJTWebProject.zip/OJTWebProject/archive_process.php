<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php";

// Get the employee ID from the URL (GET parameter)
$id = (int)($_GET["id"] ?? 0);

// Validate if the ID is greater than 0 (valid ID)
if ($id > 0) {
    // Prepare the SQL query to update the employee status and employee_id
    $sql = "UPDATE employees SET employee_id = NULL, employment_status = 'Terminated', is_archived = 1 WHERE id = ?";

    // Prepare the statement to prevent SQL injection
    $stmt = $conn->prepare($sql);

    // Check if the statement was prepared successfully
    if ($stmt === false) {
        die("Error preparing the statement: " . $conn->error);
    }

    // Bind the ID parameter to the prepared statement
    $stmt->bind_param("i", $id);

    // Execute the query
    if ($stmt->execute()) {
        // Redirect back to the employee list page after successful update
        header("Location: employee.php");
        exit;
    } else {
        // If the query execution fails, show an error message
        echo "Error updating employee: " . $conn->error;
    }

    // Close the prepared statement
    $stmt->close();
} else {
    // If the ID is invalid, redirect back to the employee list page
    header("Location: employee.php");
    exit;
}
?>
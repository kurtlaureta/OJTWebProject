<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php";

$branch   = trim($_GET["branch"] ?? "");
$group_by = trim($_GET["group_by"] ?? "");
$sort     = trim($_GET["sort"] ?? "");
$search   = trim($_GET["search"] ?? "");
$page     = max(1, (int)($_GET["page"] ?? 1));
$limit    = 10;
$offset   = ($page - 1) * $limit;

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/
function formatDisplayDate($dateValue) {
    if (empty($dateValue) || $dateValue === "0000-00-00") {
        return "N/A";
    }
    $ts = strtotime($dateValue);
    if (!$ts) {
        return "N/A";
    }
    return strtoupper(date("M. d, Y", $ts));
}

function displayEmploymentStatus($value) {
    if ((string)$value === "2") {
        return "Banned";
    }
    return $value !== null && $value !== "" ? $value : "N/A";
}

/*
|--------------------------------------------------------------------------
| Load distinct archived branches for dropdown
|--------------------------------------------------------------------------
*/
$branches = [];
$branchSql = "SELECT DISTINCT assigned_area
              FROM employees
              WHERE is_archived = 1
                AND assigned_area IS NOT NULL
                AND assigned_area != ''
              ORDER BY assigned_area ASC";

$branchResult = $conn->query($branchSql);
if ($branchResult) {
    while ($branchRow = $branchResult->fetch_assoc()) {
        $branches[] = $branchRow["assigned_area"];
    }
}

/*
|--------------------------------------------------------------------------
| WHERE clause builder
|--------------------------------------------------------------------------
*/
$whereSql = " WHERE is_archived = 1 ";
$params = [];
$types = "";

if ($branch !== "") {
    $whereSql .= " AND assigned_area = ? ";
    $params[] = $branch;
    $types .= "s";
}

if ($search !== "") {
    $whereSql .= " AND (
        employee_id LIKE ?
        OR CONCAT(first_name, ' ', middle_name, ' ', last_name) LIKE ?
        OR department LIKE ?
        OR position LIKE ?
        OR employment_status LIKE ?
        OR assigned_area LIKE ?
        OR separation_date LIKE ?
        OR end_of_employment LIKE ?
        OR (? LIKE '%Banned%' AND employment_status = 2)
    ) ";
    $searchLike = "%" . $search . "%";

    $params[] = $searchLike; $types .= "s";
    $params[] = $searchLike; $types .= "s";
    $params[] = $searchLike; $types .= "s";
    $params[] = $searchLike; $types .= "s";
    $params[] = $searchLike; $types .= "s";
    $params[] = $searchLike; $types .= "s";
    $params[] = $searchLike; $types .= "s";
    $params[] = $searchLike; $types .= "s";
    $params[] = $search;     $types .= "s";
}

/*
|--------------------------------------------------------------------------
| ORDER BY builder
|--------------------------------------------------------------------------
*/
$orderParts = [];

switch ($group_by) {
    case "department":
        $orderParts[] = "department ASC";
        break;
    case "position":
        $orderParts[] = "position ASC";
        break;
    case "name":
        $orderParts[] = "first_name ASC";
        $orderParts[] = "last_name ASC";
        break;
    case "employee_id":
        $orderParts[] = "employee_id ASC";
        break;
    case "status":
        $orderParts[] = "employment_status ASC";
        break;
    case "separation_date":
        $orderParts[] = "COALESCE(end_of_employment, separation_date) ASC";
        break;
}

switch ($sort) {
    case "az":
        $orderParts[] = "first_name ASC";
        $orderParts[] = "last_name ASC";
        break;
    case "za":
        $orderParts[] = "first_name DESC";
        $orderParts[] = "last_name DESC";
        break;
    case "newest":
        $orderParts[] = "hire_date DESC";
        break;
    case "oldest":
        $orderParts[] = "hire_date ASC";
        break;
    case "empid_asc":
        $orderParts[] = "employee_id ASC";
        break;
    case "empid_desc":
        $orderParts[] = "employee_id DESC";
        break;
    case "status_az":
        $orderParts[] = "employment_status ASC";
        break;
    case "status_za":
        $orderParts[] = "employment_status DESC";
        break;
    case "sep_oldest":
        $orderParts[] = "COALESCE(end_of_employment, separation_date) ASC";
        break;
    case "sep_newest":
        $orderParts[] = "COALESCE(end_of_employment, separation_date) DESC";
        break;
}

$orderSql = !empty($orderParts)
    ? " ORDER BY " . implode(", ", $orderParts)
    : " ORDER BY COALESCE(end_of_employment, separation_date) DESC, id DESC ";

/*
|--------------------------------------------------------------------------
| Count total rows for pagination
|--------------------------------------------------------------------------
*/
$countSql = "SELECT COUNT(*) AS total FROM employees" . $whereSql;

if (!empty($params)) {
    $countStmt = $conn->prepare($countSql);
    if (!$countStmt) {
        die("Error preparing count statement: " . $conn->error);
    }

    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();
    $countResult = $countStmt->get_result();
    $totalRows = (int)($countResult->fetch_assoc()["total"] ?? 0);
    $countStmt->close();
} else {
    $countResult = $conn->query($countSql);
    $totalRows = (int)($countResult->fetch_assoc()["total"] ?? 0);
}

$totalPages = max(1, (int)ceil($totalRows / $limit));
if ($page > $totalPages) {
    $page = $totalPages;
    $offset = ($page - 1) * $limit;
}

/*
|--------------------------------------------------------------------------
| Main paginated query
|--------------------------------------------------------------------------
*/
$sql = "SELECT * FROM employees" . $whereSql . $orderSql . " LIMIT ? OFFSET ?";

$mainParams = $params;
$mainTypes = $types . "ii";
$mainParams[] = $limit;
$mainParams[] = $offset;

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Error preparing main query: " . $conn->error);
}

$stmt->bind_param($mainTypes, ...$mainParams);
$stmt->execute();
$result = $stmt->get_result();

/*
|--------------------------------------------------------------------------
| Pagination helper
|--------------------------------------------------------------------------
*/
function buildPageUrl($pageNum, $branch, $group_by, $sort, $search) {
    $query = http_build_query([
        "branch" => $branch,
        "group_by" => $group_by,
        "sort" => $sort,
        "search" => $search,
        "page" => $pageNum
    ]);
    return "archiveemployee.php?" . $query;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../index.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100..900&display=swap" rel="stylesheet">
    <title>Archived Employees</title>
</head>
<body class="flex bg-white">
    <?php include 'navbar.php'; ?>

    <section class="flex-1 min-h-screen ml-47">
        <div class="bg-gray-200 w-full h-fit p-3 flex shadow-xl border-b justify-between border-gray-300">
            <div class="text-black font-bold flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-4 mr-2 text-green-700">
                    <path d="M3.375 3C2.339 3 1.5 3.84 1.5 4.875v.75c0 1.036.84 1.875 1.875 1.875h17.25c1.035 0 1.875-.84 1.875-1.875v-.75C22.5 3.839 21.66 3 20.625 3H3.375Z" />
                    <path fill-rule="evenodd" d="m3.087 9 .54 9.176A3 3 0 0 0 6.62 21h10.757a3 3 0 0 0 2.995-2.824L20.913 9H3.087ZM12 10.5a.75.75 0 0 1 .75.75v4.94l1.72-1.72a.75.75 0 1 1 1.06 1.06l-3 3a.75.75 0 0 1-1.06 0l-3-3a.75.75 0 1 1 1.06-1.06l1.72 1.72v-4.94a.75.75 0 0 1 .75-.75Z" clip-rule="evenodd" />
                </svg>
                ARCHIVED EMPLOYEES
            </div>

            <div id="liveDateTime" class="font-bold text-black"></div>
        </div>

        <div class="w-full max-w-7xl mx-auto bg-gray-200 p-4 m-4 rounded-3xl flex flex-col lg:flex-row lg:items-center gap-3">
            <div class="w-full lg:flex-1 flex items-center border px-2 py-2 rounded-2xl hover:shadow-gray-400 hover:shadow-md bg-white">
                <input
                    type="text"
                    id="searchInput"
                    value="<?php echo htmlspecialchars($search); ?>"
                    placeholder="Search archived employees..."
                    class="w-full p-1 outline-none bg-transparent text-sm md:text-base"
                >
            </div>

            <form id="filterForm" method="GET" action="" class="w-full sm:w-full md:w-full lg:w-auto flex flex-col sm:flex-row gap-3">
                <input type="hidden" name="search" id="searchHidden" value="<?php echo htmlspecialchars($search); ?>">
                <input type="hidden" name="page" id="pageHidden" value="1">

                <select name="branch" onchange="syncSearchAndSubmit()"
                    class="w-full lg:w-auto appearance-none border border-black rounded-2xl text-sm bg-white p-2 text-center cursor-pointer hover:border-red-400 hover:bg-red-50">
                    <option value="">ALL BRANCHES</option>
                    <?php foreach ($branches as $branchName): ?>
                        <option value="<?php echo htmlspecialchars($branchName); ?>" <?php echo ($branch === $branchName) ? "selected" : ""; ?>>
                            <?php echo htmlspecialchars($branchName); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select name="group_by" onchange="syncSearchAndSubmit()"
                    class="w-full lg:w-auto appearance-none border border-black rounded-2xl text-sm bg-white p-2 text-center cursor-pointer hover:border-red-400 hover:bg-red-50">
                    <option value="">GROUP BY (ALL)</option>
                    <option value="department" <?php echo ($group_by === "department") ? "selected" : ""; ?>>Department</option>
                    <option value="position" <?php echo ($group_by === "position") ? "selected" : ""; ?>>Position</option>
                    <option value="name" <?php echo ($group_by === "name") ? "selected" : ""; ?>>Name</option>
                    <option value="employee_id" <?php echo ($group_by === "employee_id") ? "selected" : ""; ?>>Employee ID</option>
                    <option value="status" <?php echo ($group_by === "status") ? "selected" : ""; ?>>Status</option>
                    <option value="separation_date" <?php echo ($group_by === "separation_date") ? "selected" : ""; ?>>Separation Date</option>
                </select>

                <select name="sort" onchange="syncSearchAndSubmit()"
                    class="w-full lg:w-auto appearance-none border border-black rounded-2xl text-sm bg-white p-2 text-center cursor-pointer hover:border-red-400 hover:bg-red-50">
                    <option value="">SORT</option>
                    <option value="az" <?php echo ($sort === "az") ? "selected" : ""; ?>>A-Z Name</option>
                    <option value="za" <?php echo ($sort === "za") ? "selected" : ""; ?>>Z-A Name</option>
                    <option value="newest" <?php echo ($sort === "newest") ? "selected" : ""; ?>>Date Hired: Newest</option>
                    <option value="oldest" <?php echo ($sort === "oldest") ? "selected" : ""; ?>>Date Hired: Oldest</option>
                    <option value="empid_asc" <?php echo ($sort === "empid_asc") ? "selected" : ""; ?>>Employee ID Ascending</option>
                    <option value="empid_desc" <?php echo ($sort === "empid_desc") ? "selected" : ""; ?>>Employee ID Descending</option>
                    <option value="status_az" <?php echo ($sort === "status_az") ? "selected" : ""; ?>>Status A-Z</option>
                    <option value="status_za" <?php echo ($sort === "status_za") ? "selected" : ""; ?>>Status Z-A</option>
                    <option value="sep_oldest" <?php echo ($sort === "sep_oldest") ? "selected" : ""; ?>>Separation Date: Oldest to Newest</option>
                    <option value="sep_newest" <?php echo ($sort === "sep_newest") ? "selected" : ""; ?>>Separation Date: Newest to Oldest</option>
                </select>
            </form>
        </div>

        <div class="w-full max-w-7xl mx-auto">
            <div class="bg-gray-200 border border-gray-200 rounded-3xl shadow-sm p-3">
                <div class="flex justify-between items-center mb-2">
                    <h2 class="text-lg font-bold text-gray-800">Archived Employee List</h2>
                    <div class="text-sm text-gray-600">
                        Showing <?php echo $totalRows > 0 ? ($offset + 1) : 0; ?> -
                        <?php echo min($offset + $limit, $totalRows); ?>
                        of <?php echo $totalRows; ?> archived employees
                    </div>
                </div>

                <div class="overflow-x-auto rounded-3xl overflow-hidden border border-gray-300">
                    <table class="w-full text-sm text-center border-collapse">
                        <thead>
                            <tr class="bg-gray-800 text-white">
                                <th class="p-3 border-b">Employee ID</th>
                                <th class="p-3 border-b">Full Name</th>
                                <th class="p-3 border-b">Birthdate</th>
                                <th class="p-3 border-b">Gender</th>
                                <th class="p-3 border-b">Contact Number</th>
                                <th class="p-3 border-b">Department</th>
                                <th class="p-3 border-b">Position</th>
                                <th class="p-3 border-b">Status</th>
                                <th class="p-3 border-b">Branch / Area</th>
                                <th class="p-3 border-b">Date of Termination / Resignation / Ban</th>
                            </tr>
                        </thead>
                        <tbody id="archiveTableBody">
                            <?php if ($result && $result->num_rows > 0): ?>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                    <?php
                                    $fullName = trim(
                                        ($row["first_name"] ?? "") . " " .
                                        ($row["middle_name"] ?? "") . " " .
                                        ($row["last_name"] ?? "") .
                                        (!empty($row["suffix"]) ? " " . $row["suffix"] : "")
                                    );
                                    $displayStatus = displayEmploymentStatus($row["employment_status"] ?? "");
                                    $archivedDate = $row["end_of_employment"] ?? ($row["separation_date"] ?? "");
                                    ?>
                                    <tr
                                        class="hover:bg-green-200 archive-row cursor-pointer"
                                        data-id="<?php echo (int)$row["id"]; ?>"
                                        data-employee_id="<?php echo htmlspecialchars($row["employee_id"] ?? ""); ?>"
                                        data-hris_id="<?php echo htmlspecialchars($row["hris_id"] ?? ""); ?>"
                                        data-store_code="<?php echo htmlspecialchars($row["store_code"] ?? ""); ?>"
                                        data-fullname="<?php echo htmlspecialchars($fullName); ?>"
                                        data-first_name="<?php echo htmlspecialchars($row["first_name"] ?? ""); ?>"
                                        data-middle_name="<?php echo htmlspecialchars($row["middle_name"] ?? ""); ?>"
                                        data-last_name="<?php echo htmlspecialchars($row["last_name"] ?? ""); ?>"
                                        data-suffix="<?php echo htmlspecialchars($row["suffix"] ?? ""); ?>"
                                        data-complete_name="<?php echo htmlspecialchars($row["complete_name"] ?? ""); ?>"
                                        data-birthdate="<?php echo htmlspecialchars($row["birthdate"] ?? ""); ?>"
                                        data-gender="<?php echo htmlspecialchars($row["gender"] ?? ""); ?>"
                                        data-civil_status="<?php echo htmlspecialchars($row["civil_status"] ?? ""); ?>"
                                        data-birthplace="<?php echo htmlspecialchars($row["birthplace"] ?? ""); ?>"
                                        data-contact_number="<?php echo htmlspecialchars($row["contact_number"] ?? ""); ?>"
                                        data-permanent_address="<?php echo htmlspecialchars($row["permanent_address"] ?? ""); ?>"
                                        data-present_address="<?php echo htmlspecialchars($row["present_address"] ?? ""); ?>"
                                        data-present_address_alt="<?php echo htmlspecialchars($row["present_address_alt"] ?? ""); ?>"
                                        data-father_name="<?php echo htmlspecialchars($row["father_name"] ?? ""); ?>"
                                        data-mother_name="<?php echo htmlspecialchars($row["mother_name"] ?? ""); ?>"
                                        data-emergency_person="<?php echo htmlspecialchars($row["emergency_person"] ?? ""); ?>"
                                        data-emergency_number="<?php echo htmlspecialchars($row["emergency_number"] ?? ""); ?>"
                                        data-education="<?php echo htmlspecialchars($row["education"] ?? ""); ?>"
                                        data-course="<?php echo htmlspecialchars($row["course"] ?? ""); ?>"
                                        data-department="<?php echo htmlspecialchars($row["department"] ?? ""); ?>"
                                        data-position="<?php echo htmlspecialchars($row["position"] ?? ""); ?>"
                                        data-hire_date="<?php echo htmlspecialchars($row["hire_date"] ?? ""); ?>"
                                        data-regularization_date="<?php echo htmlspecialchars($row["regularization_date"] ?? ""); ?>"
                                        data-end_of_employment="<?php echo htmlspecialchars($row["end_of_employment"] ?? ""); ?>"
                                        data-employment_status="<?php echo htmlspecialchars($displayStatus); ?>"
                                        data-assigned_area="<?php echo htmlspecialchars($row["assigned_area"] ?? ""); ?>"
                                        data-salary_basis="<?php echo htmlspecialchars($row["salary_basis"] ?? ""); ?>"
                                        data-rate="<?php echo htmlspecialchars($row["rate"] ?? ""); ?>"
                                        data-basic_salary="<?php echo htmlspecialchars($row["basic_salary"] ?? ""); ?>"
                                        data-kpi="<?php echo htmlspecialchars($row["kpi"] ?? ""); ?>"
                                        data-accommodation="<?php echo htmlspecialchars($row["accommodation"] ?? ""); ?>"
                                        data-personal_email="<?php echo htmlspecialchars($row["personal_email"] ?? ""); ?>"
                                        data-company_email="<?php echo htmlspecialchars($row["company_email"] ?? ""); ?>"
                                        data-region="<?php echo htmlspecialchars($row["region"] ?? ""); ?>"
                                        data-tin_no="<?php echo htmlspecialchars($row["tin_no"] ?? ""); ?>"
                                        data-sss_no="<?php echo htmlspecialchars($row["sss_no"] ?? ""); ?>"
                                        data-philhealth_no="<?php echo htmlspecialchars($row["philhealth_no"] ?? ""); ?>"
                                        data-pagibig_no="<?php echo htmlspecialchars($row["pagibig_no"] ?? ""); ?>"
                                        data-medical="<?php echo ((string)($row["medical"] ?? "0") === "1") ? "Submitted" : "Not Submitted"; ?>"
                                        data-id_file="<?php echo ((string)($row["id_file"] ?? "0") === "1") ? "Submitted" : "Not Submitted"; ?>"
                                        data-contract="<?php echo ((string)($row["contract"] ?? "0") === "1") ? "Submitted" : "Not Submitted"; ?>"
                                        data-separation_date="<?php echo htmlspecialchars($archivedDate); ?>"
                                    >
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["employee_id"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($fullName); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["birthdate"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["gender"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["contact_number"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["department"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["position"] ?? ""); ?></td>
                                        <td class="p-3 border-b <?php echo $displayStatus === 'Banned' ? 'text-red-600 font-bold' : ''; ?>">
                                            <?php echo htmlspecialchars($displayStatus); ?>
                                        </td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["assigned_area"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars(formatDisplayDate($archivedDate)); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="10" class="p-4 text-gray-500">No archived employees found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                    <div class="mt-4 flex flex-wrap justify-center items-center gap-2">
                        <?php if ($page > 1): ?>
                            <a href="<?php echo htmlspecialchars(buildPageUrl($page - 1, $branch, $group_by, $sort, $search)); ?>"
                               class="px-4 py-2 rounded-xl bg-gray-300 hover:bg-gray-400 text-black">
                                Previous
                            </a>
                        <?php endif; ?>

                        <?php
                        $startPage = max(1, $page - 2);
                        $endPage = min($totalPages, $page + 2);

                        if ($startPage > 1) {
                            echo '<a href="' . htmlspecialchars(buildPageUrl(1, $branch, $group_by, $sort, $search)) . '" class="px-4 py-2 rounded-xl bg-gray-300 hover:bg-gray-400 text-black">1</a>';
                            if ($startPage > 2) {
                                echo '<span class="px-2">...</span>';
                            }
                        }

                        for ($i = $startPage; $i <= $endPage; $i++):
                        ?>
                            <a href="<?php echo htmlspecialchars(buildPageUrl($i, $branch, $group_by, $sort, $search)); ?>"
                               class="px-4 py-2 rounded-xl <?php echo $i === $page ? 'bg-green-500 text-white' : 'bg-gray-300 hover:bg-gray-400 text-black'; ?>">
                                <?php echo $i; ?>
                            </a>
                        <?php endfor; ?>

                        <?php
                        if ($endPage < $totalPages) {
                            if ($endPage < $totalPages - 1) {
                                echo '<span class="px-2">...</span>';
                            }
                            echo '<a href="' . htmlspecialchars(buildPageUrl($totalPages, $branch, $group_by, $sort, $search)) . '" class="px-4 py-2 rounded-xl bg-gray-300 hover:bg-gray-400 text-black">' . $totalPages . '</a>';
                        }
                        ?>

                        <?php if ($page < $totalPages): ?>
                            <a href="<?php echo htmlspecialchars(buildPageUrl($page + 1, $branch, $group_by, $sort, $search)); ?>"
                               class="px-4 py-2 rounded-xl bg-gray-300 hover:bg-gray-400 text-black">
                                Next
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- ARCHIVED EMPLOYEE DETAIL MODAL -->
    <div id="archiveModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-50 p-4">
        <div class="bg-white w-full max-w-6xl rounded-3xl shadow-2xl relative overflow-hidden">
            <button id="closeModalBtn" class="absolute top-3 right-4 cursor-pointer bg-red-500 hover:bg-red-700 text-white w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold z-10">
                ×
            </button>

            <div class="bg-gray-900 text-white px-6 py-5 pr-16">
                <h2 class="text-2xl font-bold break-words" id="modalFullName">Employee Name</h2>
                <div class="mt-2 flex flex-wrap gap-2 text-sm">
                    <span class="bg-white/10 px-3 py-1 rounded-full">Employee No: <span id="modalEmployeeId"></span></span>
                    <span class="bg-white/10 px-3 py-1 rounded-full">HRIS ID: <span id="modalHrisId"></span></span>
                    <span class="bg-white/10 px-3 py-1 rounded-full">Store Code: <span id="modalStoreCode"></span></span>
                    <span class="bg-white/10 px-3 py-1 rounded-full">Status: <span id="modalEmploymentStatusTop"></span></span>
                    <span class="bg-white/10 px-3 py-1 rounded-full"><span id="modalArchivedDateLabelTop">Archived Date</span>: <span id="modalSeparationDateTop"></span></span>
                </div>
            </div>

            <div class="p-6 max-h-[72vh] overflow-y-auto">
                <div class="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">

                    <div class="bg-gray-50 rounded-2xl border border-gray-200 p-4">
                        <h3 class="font-bold text-gray-800 mb-3 text-base">Personal Information</h3>
                        <div class="space-y-2 text-sm text-gray-700">
                            <p><strong>First Name:</strong> <span id="modalFirstName"></span></p>
                            <p><strong>Middle Name:</strong> <span id="modalMiddleName"></span></p>
                            <p><strong>Last Name:</strong> <span id="modalLastName"></span></p>
                            <p><strong>Suffix:</strong> <span id="modalSuffix"></span></p>
                            <p><strong>Complete Name:</strong> <span id="modalCompleteName"></span></p>
                            <p><strong>Birthdate:</strong> <span id="modalBirthdate"></span></p>
                            <p><strong>Gender:</strong> <span id="modalGender"></span></p>
                            <p><strong>Civil Status:</strong> <span id="modalCivilStatus"></span></p>
                            <p><strong>Birthplace:</strong> <span id="modalBirthplace"></span></p>
                            <p><strong>Contact Number:</strong> <span id="modalContactNumber"></span></p>
                        </div>
                    </div>

                    <div class="bg-gray-50 rounded-2xl border border-gray-200 p-4">
                        <h3 class="font-bold text-gray-800 mb-3 text-base">Address Information</h3>
                        <div class="space-y-2 text-sm text-gray-700 break-words">
                            <p><strong>Permanent Address:</strong> <span id="modalPermanentAddress"></span></p>
                            <p><strong>Present Address:</strong> <span id="modalPresentAddress"></span></p>
                            <p><strong>Emergency Contact Address:</strong> <span id="modalPresentAddressAlt"></span></p>
                            <p><strong>Region:</strong> <span id="modalRegion"></span></p>
                        </div>
                    </div>

                    <div class="bg-gray-50 rounded-2xl border border-gray-200 p-4">
                        <h3 class="font-bold text-gray-800 mb-3 text-base">Family / Emergency</h3>
                        <div class="space-y-2 text-sm text-gray-700">
                            <p><strong>Father's Name:</strong> <span id="modalFatherName"></span></p>
                            <p><strong>Mother's Maiden Name:</strong> <span id="modalMotherName"></span></p>
                            <p><strong>Emergency Contact:</strong> <span id="modalEmergencyPerson"></span></p>
                            <p><strong>Emergency Number:</strong> <span id="modalEmergencyNumber"></span></p>
                        </div>
                    </div>

                    <div class="bg-gray-50 rounded-2xl border border-gray-200 p-4">
                        <h3 class="font-bold text-gray-800 mb-3 text-base">Education</h3>
                        <div class="space-y-2 text-sm text-gray-700">
                            <p><strong>Educational Attainment:</strong> <span id="modalEducation"></span></p>
                            <p><strong>Course of Study:</strong> <span id="modalCourse"></span></p>
                        </div>
                    </div>

                    <div class="bg-gray-50 rounded-2xl border border-gray-200 p-4">
                        <h3 class="font-bold text-gray-800 mb-3 text-base">Company Details</h3>
                        <div class="space-y-2 text-sm text-gray-700">
                            <p><strong>Department:</strong> <span id="modalDepartment"></span></p>
                            <p><strong>Position:</strong> <span id="modalPosition"></span></p>
                            <p><strong>Hire Date:</strong> <span id="modalHireDate"></span></p>
                            <p><strong>Regularization Date:</strong> <span id="modalRegularizationDate"></span></p>
                            <p><strong>End of Employment:</strong> <span id="modalEndOfEmployment"></span></p>
                            <p><strong>Status:</strong> <span id="modalEmploymentStatus" class="font-semibold"></span></p>
                            <p><strong>Assigned Area:</strong> <span id="modalAssignedArea"></span></p>
                            <p><strong><span id="modalArchivedDateLabel">Date of Termination</span>:</strong> <span id="modalSeparationDate"></span></p>
                        </div>
                    </div>

                    <div class="bg-gray-50 rounded-2xl border border-gray-200 p-4">
                        <h3 class="font-bold text-gray-800 mb-3 text-base">Compensation</h3>
                        <div class="space-y-2 text-sm text-gray-700">
                            <p><strong>Salary Basis:</strong> <span id="modalSalaryBasis"></span></p>
                            <p><strong>Rate:</strong> <span id="modalRate"></span></p>
                            <p><strong>Basic Salary:</strong> <span id="modalBasicSalary"></span></p>
                            <p><strong>KPI:</strong> <span id="modalKpi"></span></p>
                            <p><strong>Accommodation:</strong> <span id="modalAccommodation"></span></p>
                        </div>
                    </div>

                    <div class="bg-gray-50 rounded-2xl border border-gray-200 p-4">
                        <h3 class="font-bold text-gray-800 mb-3 text-base">Emails / Government IDs</h3>
                        <div class="space-y-2 text-sm text-gray-700 break-words">
                            <p><strong>Personal Email:</strong> <span id="modalPersonalEmail"></span></p>
                            <p><strong>Company Email:</strong> <span id="modalCompanyEmail"></span></p>
                            <p><strong>TIN No.:</strong> <span id="modalTinNo"></span></p>
                            <p><strong>SSS No.:</strong> <span id="modalSssNo"></span></p>
                            <p><strong>PhilHealth No.:</strong> <span id="modalPhilhealthNo"></span></p>
                            <p><strong>PAG-IBIG No.:</strong> <span id="modalPagibigNo"></span></p>
                        </div>
                    </div>

                    <div class="bg-gray-50 rounded-2xl border border-gray-200 p-4">
                        <h3 class="font-bold text-gray-800 mb-3 text-base">Document Checklist</h3>
                        <div class="space-y-2 text-sm text-gray-700 break-words">
                            <p><strong>Medical:</strong> <span id="modalMedical"></span></p>
                            <p><strong>ID:</strong> <span id="modalIdFile"></span></p>
                            <p><strong>Contract:</strong> <span id="modalContract"></span></p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <script>
        function updateDateTime() {
            const now = new Date();
            document.getElementById('liveDateTime').textContent =
                now.toLocaleString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: 'numeric',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true
                });
        }

        function formatDateToCustom(dateString) {
            if (!dateString) return "N/A";
            const d = new Date(dateString + "T00:00:00");
            if (isNaN(d.getTime())) return "N/A";

            const month = d.toLocaleString("en-US", { month: "short" }).toUpperCase();
            const day = String(d.getDate()).padStart(2, "0");
            const year = d.getFullYear();
            return `${month}. ${day}, ${year}`;
        }

        function safeValue(value) {
            return value && value.trim() !== "" ? value : "N/A";
        }

        updateDateTime();
        setInterval(updateDateTime, 1000);

        const searchInput = document.getElementById("searchInput");
        const searchHidden = document.getElementById("searchHidden");
        const pageHidden = document.getElementById("pageHidden");
        const filterForm = document.getElementById("filterForm");

        const modal = document.getElementById("archiveModal");
        const closeModalBtn = document.getElementById("closeModalBtn");
        const rows = document.querySelectorAll(".archive-row");

        function syncSearchAndSubmit() {
            searchHidden.value = searchInput.value.trim();
            pageHidden.value = 1;
            filterForm.submit();
        }

        let searchTimer = null;
        searchInput.addEventListener("input", function () {
            searchHidden.value = searchInput.value.trim();
            pageHidden.value = 1;

            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                filterForm.submit();
            }, 500);
        });

        rows.forEach(row => {
            row.addEventListener("click", function(e) {
                if (e.target.closest("a")) return;

                document.getElementById("modalFullName").textContent = safeValue(this.dataset.fullname);
                document.getElementById("modalEmployeeId").textContent = safeValue(this.dataset.employee_id);
                document.getElementById("modalHrisId").textContent = safeValue(this.dataset.hris_id);
                document.getElementById("modalStoreCode").textContent = safeValue(this.dataset.store_code);
                document.getElementById("modalEmploymentStatusTop").textContent = safeValue(this.dataset.employment_status);

                document.getElementById("modalFirstName").textContent = safeValue(this.dataset.first_name);
                document.getElementById("modalMiddleName").textContent = safeValue(this.dataset.middle_name);
                document.getElementById("modalLastName").textContent = safeValue(this.dataset.last_name);
                document.getElementById("modalSuffix").textContent = safeValue(this.dataset.suffix);
                document.getElementById("modalCompleteName").textContent = safeValue(this.dataset.complete_name || this.dataset.fullname);
                document.getElementById("modalBirthdate").textContent = safeValue(this.dataset.birthdate);
                document.getElementById("modalGender").textContent = safeValue(this.dataset.gender);
                document.getElementById("modalCivilStatus").textContent = safeValue(this.dataset.civil_status);
                document.getElementById("modalBirthplace").textContent = safeValue(this.dataset.birthplace);
                document.getElementById("modalContactNumber").textContent = safeValue(this.dataset.contact_number);

                document.getElementById("modalPermanentAddress").textContent = safeValue(this.dataset.permanent_address);
                document.getElementById("modalPresentAddress").textContent = safeValue(this.dataset.present_address);
                document.getElementById("modalPresentAddressAlt").textContent = safeValue(this.dataset.present_address_alt);
                document.getElementById("modalRegion").textContent = safeValue(this.dataset.region);

                document.getElementById("modalFatherName").textContent = safeValue(this.dataset.father_name);
                document.getElementById("modalMotherName").textContent = safeValue(this.dataset.mother_name);
                document.getElementById("modalEmergencyPerson").textContent = safeValue(this.dataset.emergency_person);
                document.getElementById("modalEmergencyNumber").textContent = safeValue(this.dataset.emergency_number);

                document.getElementById("modalEducation").textContent = safeValue(this.dataset.education);
                document.getElementById("modalCourse").textContent = safeValue(this.dataset.course);

                document.getElementById("modalDepartment").textContent = safeValue(this.dataset.department);
                document.getElementById("modalPosition").textContent = safeValue(this.dataset.position);
                document.getElementById("modalHireDate").textContent = safeValue(this.dataset.hire_date);
                document.getElementById("modalRegularizationDate").textContent = safeValue(this.dataset.regularization_date);
                document.getElementById("modalEndOfEmployment").textContent = safeValue(this.dataset.end_of_employment);
                document.getElementById("modalAssignedArea").textContent = safeValue(this.dataset.assigned_area);

                document.getElementById("modalSalaryBasis").textContent = safeValue(this.dataset.salary_basis);
                document.getElementById("modalRate").textContent = safeValue(this.dataset.rate);
                document.getElementById("modalBasicSalary").textContent = safeValue(this.dataset.basic_salary);
                document.getElementById("modalKpi").textContent = safeValue(this.dataset.kpi);
                document.getElementById("modalAccommodation").textContent = safeValue(this.dataset.accommodation);

                document.getElementById("modalPersonalEmail").textContent = safeValue(this.dataset.personal_email);
                document.getElementById("modalCompanyEmail").textContent = safeValue(this.dataset.company_email);
                document.getElementById("modalTinNo").textContent = safeValue(this.dataset.tin_no);
                document.getElementById("modalSssNo").textContent = safeValue(this.dataset.sss_no);
                document.getElementById("modalPhilhealthNo").textContent = safeValue(this.dataset.philhealth_no);
                document.getElementById("modalPagibigNo").textContent = safeValue(this.dataset.pagibig_no);

                document.getElementById("modalMedical").textContent = safeValue(this.dataset.medical);
                document.getElementById("modalIdFile").textContent = safeValue(this.dataset.id_file);
                document.getElementById("modalContract").textContent = safeValue(this.dataset.contract);

                const employeeStatus = safeValue(this.dataset.employment_status);
                const modalEmploymentStatus = document.getElementById("modalEmploymentStatus");
                modalEmploymentStatus.textContent = employeeStatus;
                modalEmploymentStatus.classList.remove("text-red-600");

                if (employeeStatus === "Banned") {
                    modalEmploymentStatus.classList.add("text-red-600");
                }

                const separationLabel = document.getElementById("modalArchivedDateLabel");
                const separationLabelTop = document.getElementById("modalArchivedDateLabelTop");

                if (employeeStatus === "Resigned") {
                    separationLabel.textContent = "Date of Resignation";
                    separationLabelTop.textContent = "Resigned Date";
                } else if (employeeStatus === "Banned") {
                    separationLabel.textContent = "Date Banned";
                    separationLabelTop.textContent = "Banned Date";
                } else {
                    separationLabel.textContent = "Date of Termination";
                    separationLabelTop.textContent = "Terminated Date";
                }

                const formattedArchivedDate = formatDateToCustom(this.dataset.separation_date || "");
                document.getElementById("modalSeparationDate").textContent = formattedArchivedDate;
                document.getElementById("modalSeparationDateTop").textContent = formattedArchivedDate;

                modal.classList.remove("hidden");
                modal.classList.add("flex");
            });
        });

        function closeModal() {
            modal.classList.add("hidden");
            modal.classList.remove("flex");
        }

        closeModalBtn.addEventListener("click", closeModal);

        modal.addEventListener("click", function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });

        document.addEventListener("keydown", function(e) {
            if (e.key === "Escape") {
                closeModal();
            }
        });
    </script>
</body>
</html>
<?php
session_start();
include "db.php";

header("Content-Type: application/json");

$employee_id = trim($_GET["employee_id"] ?? "");
$archived_id = (int)($_GET["archived_id"] ?? 0);

$response = [
    "exists" => false
];

if ($employee_id === "") {
    echo json_encode($response);
    exit;
}

$sql = "SELECT id FROM employees WHERE employee_id = ? AND id != ? LIMIT 1";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(["exists" => true]);
    exit;
}

$stmt->bind_param("si", $employee_id, $archived_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $response["exists"] = true;
}

$stmt->close();

echo json_encode($response);
?>
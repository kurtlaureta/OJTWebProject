<?php
include 'db.php';

// Check if the 'id' parameter is present in the URL
if (isset($_GET['id'])) {
    $employeeId = trim($_GET['id']);

    // Validate employee ID (you can customize the validation rule as needed)
    if (empty($employeeId) || !preg_match("/^[A-Za-z0-9]+$/", $employeeId)) {
        // Return error if employee ID is invalid
        http_response_code(400); // Bad Request
        echo json_encode(["error" => "Invalid employee ID format"]);
        exit;
    }

    // Prepare SQL query to check if the employee ID exists
    $stmt = $conn->prepare("SELECT COUNT(*) FROM employees WHERE employee_id = ?");
    $stmt->bind_param("s", $employeeId);
    
    if ($stmt === false) {
        // If there's an issue with preparing the statement, return an error
        http_response_code(500); // Internal Server Error
        echo json_encode(["error" => "Database error: " . $conn->error]);
        exit;
    }

    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    // Return a JSON response indicating whether the employee ID exists
    echo json_encode(["exists" => $count > 0]);
} else {
    // If 'id' parameter is not provided, return a bad request error
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "Missing employee ID parameter"]);
}
?>
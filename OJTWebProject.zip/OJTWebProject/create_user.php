<?php
include "admin_only.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"] ?? "");
    $password = trim($_POST["password"] ?? "");
    $role     = trim($_POST["role"] ?? "user");

    if ($username === "" || $password === "") {
        header("Location: users.php");
        exit;
    }

    $allowed_roles = ["user", "staff", "employee", "manager", "admin"];
    if (!in_array($role, $allowed_roles)) {
        $role = "user";
    }

    $check = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
    $check->bind_param("s", $username);
    $check->execute();
    $checkResult = $check->get_result();

    if ($checkResult && $checkResult->num_rows > 0) {
        header("Location: users.php");
        exit;
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $status = "active";

    $stmt = $conn->prepare("INSERT INTO users (username, password, role, status, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssss", $username, $hashedPassword, $role, $status);
    $stmt->execute();

    header("Location: users.php");
    exit;
}

header("Location: users.php");
exit;
?>
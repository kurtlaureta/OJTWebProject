<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php";

$id = (int)($_GET["id"] ?? $_POST["id"] ?? 0);

if ($id <= 0) {
    die("Invalid employee ID.");
}

$message = "";
$errors = [];

/* =========================
   HELPERS
========================= */
function clean_input($value)
{
    return trim((string)($value ?? ""));
}

function is_valid_name($value)
{
    return preg_match("/^[a-zA-Z\s.'-]+$/", $value);
}

function is_valid_email_custom($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function is_valid_decimal($value)
{
    return preg_match('/^\d+(\.\d{1,2})?$/', $value);
}

function normalize_gov_id($value)
{
    return preg_replace('/\D+/', '', (string)$value);
}

function gov_id_exists_except_current($conn, $column, $value, $currentId)
{
    if ($value === "") {
        return false;
    }

    $allowedColumns = ['tin_no', 'sss_no', 'philhealth_no', 'pagibig_no'];
    if (!in_array($column, $allowedColumns, true)) {
        return false;
    }

    $sql = "
        SELECT COUNT(*) AS total
        FROM employees
        WHERE REPLACE(REPLACE(REPLACE(REPLACE($column, '-', ''), ' ', ''), '.', ''), '/', '') = ?
          AND id != ?
    ";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("si", $value, $currentId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();

    return (int)($row["total"] ?? 0) > 0;
}

function error_text($name)
{
    global $errors;
    return isset($errors[$name])
        ? '<p class="text-red-600 text-xs mt-1">' . htmlspecialchars($errors[$name]) . '</p>'
        : '';
}

function checked_value_edit($value)
{
    return ((string)$value === "1") ? "checked" : "";
}

/* =========================
   LOAD EMPLOYEE DATA FIRST
========================= */
$stmt = $conn->prepare("SELECT * FROM employees WHERE id = ? LIMIT 1");
if (!$stmt) {
    die("Failed to prepare employee query.");
}

$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result || $result->num_rows === 0) {
    die("Employee not found.");
}

$row = $result->fetch_assoc();
$stmt->close();

/* =========================
   UPDATE EMPLOYEE
========================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $first_name = clean_input($_POST["first_name"] ?? "");
    $middle_name = clean_input($_POST["middle_name"] ?? "");
    $last_name = clean_input($_POST["last_name"] ?? "");
    $suffix = clean_input($_POST["suffix"] ?? "");
    $birthdate = clean_input($_POST["birthdate"] ?? "");
    $gender = clean_input($_POST["gender"] ?? "");
    $civil_status = clean_input($_POST["civil_status"] ?? "");
    $birthplace = clean_input($_POST["birthplace"] ?? "");
    $contact_number = clean_input($_POST["contact_number"] ?? "");
    $permanent_address = clean_input($_POST["permanent_address"] ?? "");
    $present_address = clean_input($_POST["present_address"] ?? "");
    $present_address_alt = clean_input($_POST["present_address_alt"] ?? "");

    $father_name = clean_input($_POST["father_name"] ?? "");
    $mother_name = clean_input($_POST["mother_name"] ?? "");
    $emergency_person = clean_input($_POST["emergency_person"] ?? "");
    $emergency_number = clean_input($_POST["emergency_number"] ?? "");
    $education = clean_input($_POST["education"] ?? "");
    $course = clean_input($_POST["course"] ?? "");

    $employee_id = clean_input($_POST["employee_id"] ?? "");
    $hris_id = clean_input($_POST["hris_id"] ?? "");
    $store_code = clean_input($_POST["store_code"] ?? "");
    $department = clean_input($_POST["department"] ?? "");
    $position = clean_input($_POST["position"] ?? "");
    $hire_date = clean_input($_POST["hire_date"] ?? "");
    $regularization_date = clean_input($_POST["regularization_date"] ?? "");
    $end_of_employment = clean_input($_POST["end_of_employment"] ?? "");
    $employment_status = clean_input($_POST["employment_status"] ?? "");
    $assigned_area = clean_input($_POST["assigned_area"] ?? "");

    $salary_basis = clean_input($_POST["salary_basis"] ?? "");
    $rate = clean_input($_POST["rate"] ?? "");
    $basic_salary = clean_input($_POST["basic_salary"] ?? "");
    $kpi = clean_input($_POST["kpi"] ?? "");
    $accommodation = clean_input($_POST["accommodation"] ?? "");

    $personal_email = clean_input($_POST["personal_email"] ?? "");
    $company_email = clean_input($_POST["company_email"] ?? "");
    $region = clean_input($_POST["region"] ?? "");

    $tin_no = normalize_gov_id($_POST["tin_no"] ?? "");
    $sss_no = normalize_gov_id($_POST["sss_no"] ?? "");
    $philhealth_no = normalize_gov_id($_POST["philhealth_no"] ?? "");
    $pagibig_no = normalize_gov_id($_POST["pagibig_no"] ?? "");

    $medical = isset($_POST["medical"]) ? "1" : "0";
    $id_file = isset($_POST["id_file"]) ? "1" : "0";
    $contract = isset($_POST["contract"]) ? "1" : "0";

    /* =========================
       REQUIRED FIELDS
    ========================= */
    if ($first_name === "") $errors["first_name"] = "First name is required.";
    if ($last_name === "") $errors["last_name"] = "Last name is required.";
    if ($employee_id === "") $errors["employee_id"] = "Employee ID is required.";
    if ($contact_number === "") $errors["contact_number"] = "Contact number is required.";
    if ($birthdate === "") $errors["birthdate"] = "Birthdate is required.";
    if ($gender === "") $errors["gender"] = "Gender is required.";
    if ($civil_status === "") $errors["civil_status"] = "Civil status is required.";
    if ($hire_date === "") $errors["hire_date"] = "Hire date is required.";
    if ($employment_status === "") $errors["employment_status"] = "Employment status is required.";

    if (($employment_status === "Resigned" || $employment_status === "Terminated") && $end_of_employment === "") {
        $errors["end_of_employment"] = "End of employment is required for resigned or terminated employees.";
    }

    /* =========================
       NAME VALIDATION
    ========================= */
    $name_fields = [
        "first_name" => $first_name,
        "middle_name" => $middle_name,
        "last_name" => $last_name,
        "father_name" => $father_name,
        "mother_name" => $mother_name,
        "emergency_person" => $emergency_person
    ];

    $name_labels = [
        "first_name" => "First name",
        "middle_name" => "Middle name",
        "last_name" => "Last name",
        "father_name" => "Father's name",
        "mother_name" => "Mother's name",
        "emergency_person" => "Emergency contact person"
    ];

    foreach ($name_fields as $field => $value) {
        if ($value !== "" && !is_valid_name($value)) {
            $errors[$field] = $name_labels[$field] . " contains invalid characters.";
        }
    }

    /* =========================
       PHONE NUMBER VALIDATION
    ========================= */
    if ($contact_number !== "" && !preg_match('/^09\d{9}$/', $contact_number)) {
        $errors["contact_number"] = "Contact number must be exactly 11 digits and start with 09.";
    }

    if ($emergency_number !== "" && !preg_match('/^09\d{9}$/', $emergency_number)) {
        $errors["emergency_number"] = "Emergency contact number must be exactly 11 digits and start with 09.";
    }

    /* =========================
       EMPLOYEE / HRIS / STORE VALIDATION
    ========================= */
    if ($employee_id !== "" && !preg_match('/^[A-Za-z0-9_-]+$/', $employee_id)) {
        $errors["employee_id"] = "Employee ID must only contain letters, numbers, dash, or underscore.";
    }

    if ($hris_id !== "" && !preg_match('/^[A-Za-z0-9_-]+$/', $hris_id)) {
        $errors["hris_id"] = "HRIS ID must only contain letters, numbers, dash, or underscore.";
    }

    if ($store_code !== "" && !preg_match('/^[A-Za-z0-9_\-\s]+$/', $store_code)) {
        $errors["store_code"] = "Store code contains invalid characters.";
    }

    /* =========================
       VALID CHOICES
    ========================= */
    $valid_genders = ["Male", "Female"];
    $valid_civil_status = ["Single", "Married", "Widowed"];
    $valid_education = ["High School", "College Level", "College Graduate", "Vocational"];
    $valid_employment_status = ["Active", "Regular", "Probationary", "Resigned", "Terminated"];
    $valid_salary_basis = ["Daily", "Weekly", "Semi-Monthly", "Monthly"];

    if ($gender !== "" && !in_array($gender, $valid_genders, true)) {
        $errors["gender"] = "Invalid gender selected.";
    }

    if ($civil_status !== "" && !in_array($civil_status, $valid_civil_status, true)) {
        $errors["civil_status"] = "Invalid civil status selected.";
    }

    if ($education !== "" && !in_array($education, $valid_education, true)) {
        $errors["education"] = "Invalid educational attainment selected.";
    }

    if ($employment_status !== "" && !in_array($employment_status, $valid_employment_status, true)) {
        $errors["employment_status"] = "Invalid employment status selected.";
    }

    if ($salary_basis !== "" && !in_array($salary_basis, $valid_salary_basis, true)) {
        $errors["salary_basis"] = "Invalid salary basis selected.";
    }

    /* =========================
       MONEY / DECIMAL VALIDATION
    ========================= */
    $decimal_fields = [
        "rate" => $rate,
        "basic_salary" => $basic_salary,
        "kpi" => $kpi,
        "accommodation" => $accommodation
    ];

    $decimal_labels = [
        "rate" => "Rate",
        "basic_salary" => "Basic salary",
        "kpi" => "KPI",
        "accommodation" => "Accommodation"
    ];

    foreach ($decimal_fields as $field => $value) {
        if ($value !== "" && !is_valid_decimal($value)) {
            $errors[$field] = $decimal_labels[$field] . " must be a valid number with up to 2 decimal places.";
        }
    }

    /* =========================
       EMAIL VALIDATION
    ========================= */
    if ($personal_email !== "" && !is_valid_email_custom($personal_email)) {
        $errors["personal_email"] = "Invalid personal email format.";
    }

    if ($company_email !== "" && !is_valid_email_custom($company_email)) {
        $errors["company_email"] = "Invalid company email format.";
    }

    /* =========================
       GOV ID VALIDATION
    ========================= */
    if ($tin_no !== "" && !in_array(strlen($tin_no), [9, 12], true)) {
        $errors["tin_no"] = "TIN number must be exactly 9 or 12 digits.";
    }

    if ($sss_no !== "" && strlen($sss_no) !== 10) {
        $errors["sss_no"] = "SSS number must be exactly 10 digits.";
    }

    if ($philhealth_no !== "" && strlen($philhealth_no) !== 12) {
        $errors["philhealth_no"] = "PhilHealth number must be exactly 12 digits.";
    }

    if ($pagibig_no !== "" && strlen($pagibig_no) !== 12) {
        $errors["pagibig_no"] = "PAG-IBIG number must be exactly 12 digits.";
    }

    /* =========================
       DATE VALIDATION
    ========================= */
    $today = date("Y-m-d");

    if ($birthdate !== "") {
        $birth_obj = DateTime::createFromFormat("Y-m-d", $birthdate);
        if (!$birth_obj || $birth_obj->format("Y-m-d") !== $birthdate) {
            $errors["birthdate"] = "Invalid birthdate.";
        } elseif ($birthdate > $today) {
            $errors["birthdate"] = "Birthdate cannot be in the future.";
        }
    }

    if ($hire_date !== "") {
        $hire_obj = DateTime::createFromFormat("Y-m-d", $hire_date);
        if (!$hire_obj || $hire_obj->format("Y-m-d") !== $hire_date) {
            $errors["hire_date"] = "Invalid hire date.";
        } elseif ($hire_date > $today) {
            $errors["hire_date"] = "Hire date cannot be in the future.";
        }
    }

    if ($regularization_date !== "") {
        $reg_obj = DateTime::createFromFormat("Y-m-d", $regularization_date);
        if (!$reg_obj || $reg_obj->format("Y-m-d") !== $regularization_date) {
            $errors["regularization_date"] = "Invalid regularization date.";
        }
    }

    if ($end_of_employment !== "") {
        $end_obj = DateTime::createFromFormat("Y-m-d", $end_of_employment);
        if (!$end_obj || $end_obj->format("Y-m-d") !== $end_of_employment) {
            $errors["end_of_employment"] = "Invalid end of employment date.";
        } elseif ($end_of_employment > $today) {
            $errors["end_of_employment"] = "End of employment date cannot be in the future.";
        }
    }

    if ($birthdate !== "" && $hire_date !== "") {
        $birth_ts = strtotime($birthdate);
        $hire_ts = strtotime($hire_date);

        if ($hire_ts < $birth_ts) {
            $errors["hire_date"] = "Hire date cannot be earlier than birthdate.";
        } else {
            $age_at_hire = date_diff(date_create($birthdate), date_create($hire_date))->y;
            if ($age_at_hire < 16) {
                $errors["hire_date"] = "Employee age at hire must be at least 16 years old.";
            }
        }
    }

    if ($regularization_date !== "" && $hire_date !== "") {
        if ($regularization_date < $hire_date) {
            $errors["regularization_date"] = "Regularization date cannot be earlier than hire date.";
        }
    }

    if ($hire_date !== "" && $end_of_employment !== "") {
        if ($end_of_employment < $hire_date) {
            $errors["end_of_employment"] = "End of employment date cannot be earlier than hire date.";
        }
    }

    if (in_array($employment_status, ["Active", "Regular", "Probationary"], true) && $end_of_employment !== "") {
        $errors["end_of_employment"] = "End of employment should be blank for active employees.";
    }

    /* =========================
       DUPLICATE CHECKS
    ========================= */
    if (empty($errors)) {
        $checkQuery = "SELECT COUNT(*) AS count FROM employees WHERE employee_id = ? AND id != ?";
        $stmt = $conn->prepare($checkQuery);

        if ($stmt) {
            $stmt->bind_param("si", $employee_id, $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $duplicate = $result->fetch_assoc();

            if (($duplicate["count"] ?? 0) > 0) {
                $errors["employee_id"] = "Employee ID already exists.";
            }

            $stmt->close();
        } else {
            $errors["employee_id"] = "Failed to prepare duplicate employee ID check.";
        }
    }

    if (empty($errors) && $company_email !== "") {
        $checkEmail = $conn->prepare("SELECT COUNT(*) AS count FROM employees WHERE company_email = ? AND id != ?");
        if ($checkEmail) {
            $checkEmail->bind_param("si", $company_email, $id);
            $checkEmail->execute();
            $emailResult = $checkEmail->get_result();
            $emailDuplicate = $emailResult->fetch_assoc();

            if (($emailDuplicate["count"] ?? 0) > 0) {
                $errors["company_email"] = "Company email already exists.";
            }
            $checkEmail->close();
        }
    }

    if (empty($errors) && $tin_no !== "" && gov_id_exists_except_current($conn, 'tin_no', $tin_no, $id)) {
        $errors["tin_no"] = "TIN number already exists.";
    }

    if (empty($errors) && $sss_no !== "" && gov_id_exists_except_current($conn, 'sss_no', $sss_no, $id)) {
        $errors["sss_no"] = "SSS number already exists.";
    }

    if (empty($errors) && $philhealth_no !== "" && gov_id_exists_except_current($conn, 'philhealth_no', $philhealth_no, $id)) {
        $errors["philhealth_no"] = "PhilHealth number already exists.";
    }

    if (empty($errors) && $pagibig_no !== "" && gov_id_exists_except_current($conn, 'pagibig_no', $pagibig_no, $id)) {
        $errors["pagibig_no"] = "PAG-IBIG number already exists.";
    }

    /* =========================
       AUTO ARCHIVE
    ========================= */
    $is_archived = ($employment_status === "Resigned" || $employment_status === "Terminated") ? 1 : 0;

    if ($employment_status !== "Resigned" && $employment_status !== "Terminated") {
        $end_of_employment = null;
    }

    $complete_name = trim(
        $first_name .
        ($middle_name !== "" ? " " . $middle_name : "") .
        " " . $last_name .
        ($suffix !== "" ? " " . $suffix : "")
    );

    /* =========================
       UPDATE RECORD
    ========================= */
    if (empty($errors)) {
    $stmt = $conn->prepare("UPDATE employees SET
        first_name = ?,
        middle_name = ?,
        last_name = ?,
        suffix = ?,
        complete_name = ?,
        birthdate = ?,
        gender = ?,
        civil_status = ?,
        birthplace = ?,
        contact_number = ?,
        permanent_address = ?,
        present_address = ?,
        present_address_alt = ?,
        father_name = ?,
        mother_name = ?,
        emergency_person = ?,
        emergency_number = ?,
        education = ?,
        course = ?,
        employee_id = ?,
        hris_id = ?,
        store_code = ?,
        department = ?,
        position = ?,
        hire_date = ?,
        regularization_date = ?,
        end_of_employment = ?,
        employment_status = ?,
        assigned_area = ?,
        salary_basis = ?,
        rate = ?,
        basic_salary = ?,
        kpi = ?,
        accommodation = ?,
        personal_email = ?,
        company_email = ?,
        region = ?,
        tin_no = ?,
        sss_no = ?,
        philhealth_no = ?,
        pagibig_no = ?,
        medical = ?,
        id_file = ?,
        contract = ?,
        separation_date = ?,
        is_archived = ?
        WHERE id = ?");

    if ($stmt) {
        $separation_date = $end_of_employment;

        $stmt->bind_param(
            "sssssssssssssssssssssssssssssssssssssssssssssii",
            $first_name,
            $middle_name,
            $last_name,
            $suffix,
            $complete_name,
            $birthdate,
            $gender,
            $civil_status,
            $birthplace,
            $contact_number,
            $permanent_address,
            $present_address,
            $present_address_alt,
            $father_name,
            $mother_name,
            $emergency_person,
            $emergency_number,
            $education,
            $course,
            $employee_id,
            $hris_id,
            $store_code,
            $department,
            $position,
            $hire_date,
            $regularization_date,
            $end_of_employment,
            $employment_status,
            $assigned_area,
            $salary_basis,
            $rate,
            $basic_salary,
            $kpi,
            $accommodation,
            $personal_email,
            $company_email,
            $region,
            $tin_no,
            $sss_no,
            $philhealth_no,
            $pagibig_no,
            $medical,
            $id_file,
            $contract,
            $separation_date,
            $is_archived,
            $id
        );

        if ($stmt->execute()) {
            header("Location: employee.php?updated=1");
            exit;
        } else {
            $message = "Error updating employee: " . htmlspecialchars($stmt->error);
        }

        $stmt->close();
    } else {
        $message = "Failed to prepare update query.";
    }
}

    if (!empty($errors)) {
        $message = "Please fix the highlighted fields below.";

        $row = array_merge($row, [
            "first_name" => $first_name,
            "middle_name" => $middle_name,
            "last_name" => $last_name,
            "suffix" => $suffix,
            "complete_name" => $complete_name ?? "",
            "birthdate" => $birthdate,
            "gender" => $gender,
            "civil_status" => $civil_status,
            "birthplace" => $birthplace,
            "contact_number" => $contact_number,
            "permanent_address" => $permanent_address,
            "present_address" => $present_address,
            "present_address_alt" => $present_address_alt,
            "father_name" => $father_name,
            "mother_name" => $mother_name,
            "emergency_person" => $emergency_person,
            "emergency_number" => $emergency_number,
            "education" => $education,
            "course" => $course,
            "employee_id" => $employee_id,
            "hris_id" => $hris_id,
            "store_code" => $store_code,
            "department" => $department,
            "position" => $position,
            "hire_date" => $hire_date,
            "regularization_date" => $regularization_date,
            "end_of_employment" => $end_of_employment,
            "employment_status" => $employment_status,
            "assigned_area" => $assigned_area,
            "salary_basis" => $salary_basis,
            "rate" => $rate,
            "basic_salary" => $basic_salary,
            "kpi" => $kpi,
            "accommodation" => $accommodation,
            "personal_email" => $personal_email,
            "company_email" => $company_email,
            "region" => $region,
            "tin_no" => $tin_no,
            "sss_no" => $sss_no,
            "philhealth_no" => $philhealth_no,
            "pagibig_no" => $pagibig_no,
            "medical" => $medical,
            "id_file" => $id_file,
            "contract" => $contract
        ]);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../index.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <title>Edit Employee</title>
</head>
<body class="flex overflow-x-hidden bg-gray-100">
    <?php include 'navbar.php'; ?>

    <section class="flex-1 min-h-screen ml-47">
        <nav class="bg-gray-200 w-full h-auto p-4 shadow-md shadow-gray-500">
            <div class="flex justify-between items-center flex-wrap gap-3">
                <div class="bg-blue-400 p-1 px-4 rounded-3xl cursor-pointer text-white duration-200 transition-all hover:bg-blue-700 w-fit">
                    <a href="employee.php" class="flex w-auto h-auto items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 mr-1">
                            <path fill-rule="evenodd" d="M9.53 2.47a.75.75 0 0 1 0 1.06L4.81 8.25H15a6.75 6.75 0 0 1 0 13.5h-3a.75.75 0 0 1 0-1.5h3a5.25 5.25 0 1 0 0-10.5H4.81l4.72 4.72a.75.75 0 1 1-1.06 1.06l-6-6a.75.75 0 0 1 0-1.06l6-6a.75.75 0 0 1 1.06 0Z" clip-rule="evenodd" />
                        </svg>
                        Back
                    </a>
                </div>

                <div class="flex items-center font-bold text-white bg-yellow-500 p-2 px-4 rounded-2xl">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 mr-2 text-blue-900">
                        <path d="M16.862 4.487a2.625 2.625 0 1 1 3.712 3.713L8.197 20.577a4.5 4.5 0 0 1-1.897 1.13l-2.685.895a.75.75 0 0 1-.948-.948l.895-2.685a4.5 4.5 0 0 1 1.13-1.897L16.862 4.487Z" />
                    </svg>
                    EDIT EMPLOYEE
                </div>

                <div class="flex text-[10px] font-bold text-black items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-3 text-green-500 mr-1">
                        <path fill-rule="evenodd" d="m11.54 22.351.07.04.028.016a.76.76 0 0 0 .723 0l.028-.015.071-.041a16.975 16.975 0 0 0 1.144-.742 19.58 19.58 0 0 0 2.683-2.282c1.944-1.99 3.963-4.98 3.963-8.827a8.25 8.25 0 0 0-16.5 0c0 3.846 2.02 6.837 3.963 8.827a19.58 19.58 0 0 0 2.682 2.282 16.975 16.975 0 0 0 1.145.742ZM12 13.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" clip-rule="evenodd" />
                    </svg>
                    WH1 SANTA ROSA
                </div>
            </div>
        </nav>

        <section class="p-3 flex justify-center">
            <div class="border-2 p-3 w-full max-w-7xl bg-white rounded-2xl shadow">
                <div class="w-full mx-auto px-6 py-6">

                    <?php if (!empty($message)): ?>
                        <div class="mb-4 rounded-xl bg-red-100 text-red-700 px-4 py-3">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="" id="employeeForm" class="grid grid-cols-1 xl:grid-cols-2 gap-6" novalidate>
                        <input type="hidden" name="id" value="<?php echo (int)($row["id"] ?? 0); ?>">

                        <div class="bg-white border border-gray-200 rounded-3xl shadow-sm p-6">
                            <h2 class="text-lg font-bold text-center text-black mb-5">Personal Details</h2>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-semibold mb-1">First Name</label>
                                    <input type="text" name="first_name" value="<?php echo htmlspecialchars($row["first_name"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['first_name']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('first_name'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Middle Name</label>
                                    <input type="text" name="middle_name" value="<?php echo htmlspecialchars($row["middle_name"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['middle_name']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('middle_name'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Last Name</label>
                                    <input type="text" name="last_name" value="<?php echo htmlspecialchars($row["last_name"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['last_name']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('last_name'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Suffix</label>
                                    <input type="text" name="suffix" value="<?php echo htmlspecialchars($row["suffix"] ?? ""); ?>" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Birthdate</label>
                                    <input type="date" name="birthdate" title="Birthdate" value="<?php echo htmlspecialchars($row["birthdate"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['birthdate']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('birthdate'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Gender</label>
                                    <select name="gender" class="w-full rounded-2xl border <?php echo isset($errors['gender']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                        <option value="">Gender</option>
                                        <option value="Male" <?php echo (($row["gender"] ?? "") === "Male") ? "selected" : ""; ?>>Male</option>
                                        <option value="Female" <?php echo (($row["gender"] ?? "") === "Female") ? "selected" : ""; ?>>Female</option>
                                    </select>
                                    <?php echo error_text('gender'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Civil Status</label>
                                    <select name="civil_status" class="w-full rounded-2xl border <?php echo isset($errors['civil_status']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                        <option value="">Civil Status</option>
                                        <option value="Single" <?php echo (($row["civil_status"] ?? "") === "Single") ? "selected" : ""; ?>>Single</option>
                                        <option value="Married" <?php echo (($row["civil_status"] ?? "") === "Married") ? "selected" : ""; ?>>Married</option>
                                        <option value="Widowed" <?php echo (($row["civil_status"] ?? "") === "Widowed") ? "selected" : ""; ?>>Widowed</option>
                                    </select>
                                    <?php echo error_text('civil_status'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Birth Place</label>
                                    <input type="text" name="birthplace" value="<?php echo htmlspecialchars($row["birthplace"] ?? ""); ?>" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                                </div>

                                <div class="md:col-span-2">
                                    <label class="block text-sm font-semibold mb-1">Contact Number</label>
                                    <input type="tel" id="contact_number" name="contact_number" maxlength="11" value="<?php echo htmlspecialchars($row["contact_number"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['contact_number']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('contact_number'); ?>
                                </div>

                                <div class="md:col-span-2">
                                    <label class="block text-sm font-semibold mb-1">Permanent Address</label>
                                    <textarea name="permanent_address" rows="3" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm resize-none"><?php echo htmlspecialchars($row["permanent_address"] ?? ""); ?></textarea>
                                </div>

                                <div class="md:col-span-2">
                                    <label class="block text-sm font-semibold mb-1">Present Address</label>
                                    <textarea name="present_address" rows="3" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm resize-none"><?php echo htmlspecialchars($row["present_address"] ?? ""); ?></textarea>
                                </div>

                                <div class="md:col-span-2">
                                    <label class="block text-sm font-semibold mb-1">Emergency Contact Address</label>
                                    <textarea name="present_address_alt" rows="3" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm resize-none"><?php echo htmlspecialchars($row["present_address_alt"] ?? ""); ?></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="bg-white border border-gray-200 rounded-3xl shadow-sm p-6">
                            <h2 class="text-lg font-bold text-center text-black mb-5">Family / Emergency / Education</h2>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="md:col-span-2">
                                    <label class="block text-sm font-semibold mb-1">Father's Name</label>
                                    <input type="text" name="father_name" value="<?php echo htmlspecialchars($row["father_name"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['father_name']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('father_name'); ?>
                                </div>

                                <div class="md:col-span-2">
                                    <label class="block text-sm font-semibold mb-1">Mother's Maiden Name</label>
                                    <input type="text" name="mother_name" value="<?php echo htmlspecialchars($row["mother_name"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['mother_name']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('mother_name'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Emergency Contact Person</label>
                                    <input type="text" name="emergency_person" value="<?php echo htmlspecialchars($row["emergency_person"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['emergency_person']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('emergency_person'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Emergency Contact Number</label>
                                    <input type="tel" id="emergency_number" name="emergency_number" maxlength="11" value="<?php echo htmlspecialchars($row["emergency_number"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['emergency_number']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('emergency_number'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Educational Attainment</label>
                                    <select name="education" class="w-full rounded-2xl border <?php echo isset($errors['education']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                        <option value="">Educational Attainment</option>
                                        <option value="High School" <?php echo (($row["education"] ?? "") === "High School") ? "selected" : ""; ?>>High School</option>
                                        <option value="College Level" <?php echo (($row["education"] ?? "") === "College Level") ? "selected" : ""; ?>>College Level</option>
                                        <option value="College Graduate" <?php echo (($row["education"] ?? "") === "College Graduate") ? "selected" : ""; ?>>College Graduate</option>
                                        <option value="Vocational" <?php echo (($row["education"] ?? "") === "Vocational") ? "selected" : ""; ?>>Vocational</option>
                                    </select>
                                    <?php echo error_text('education'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Course of Study</label>
                                    <input type="text" name="course" value="<?php echo htmlspecialchars($row["course"] ?? ""); ?>" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                                </div>
                            </div>
                        </div>

                        <div class="bg-white border border-gray-200 rounded-3xl shadow-sm p-6 xl:col-span-2">
                            <h2 class="text-lg font-bold text-center text-black mb-5">Company / Payroll / IDs</h2>

                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                    <label class="block text-sm font-semibold mb-1">Employee Number</label>
                                    <input type="text" id="employee_id" name="employee_id" value="<?php echo htmlspecialchars($row["employee_id"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['employee_id']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('employee_id'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">HRIS ID</label>
                                    <input type="text" name="hris_id" value="<?php echo htmlspecialchars($row["hris_id"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['hris_id']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('hris_id'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Store Code</label>
                                    <input type="text" name="store_code" value="<?php echo htmlspecialchars($row["store_code"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['store_code']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('store_code'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Department</label>
                                    <input type="text" name="department" value="<?php echo htmlspecialchars($row["department"] ?? ""); ?>" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Position</label>
                                    <input type="text" name="position" value="<?php echo htmlspecialchars($row["position"] ?? ""); ?>" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Assigned Branch / Area</label>
                                    <input type="text" name="assigned_area" value="<?php echo htmlspecialchars($row["assigned_area"] ?? ""); ?>" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Hire Date</label>
                                    <input type="date" name="hire_date" title="Hire Date" value="<?php echo htmlspecialchars($row["hire_date"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['hire_date']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('hire_date'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Regularization Date</label>
                                    <input type="date" name="regularization_date" title="Regularization Date" value="<?php echo htmlspecialchars($row["regularization_date"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['regularization_date']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('regularization_date'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">End of Employment</label>
                                    <input type="date" id="end_of_employment" name="end_of_employment" title="End of Employment" value="<?php echo htmlspecialchars($row["end_of_employment"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['end_of_employment']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('end_of_employment'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Employment Status</label>
                                    <select id="employment_status" name="employment_status" class="w-full rounded-2xl border <?php echo isset($errors['employment_status']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                        <option value="">Employment Status</option>
                                        <option value="Active" <?php echo (($row["employment_status"] ?? "") === "Active") ? "selected" : ""; ?>>Active</option>
                                        <option value="Regular" <?php echo (($row["employment_status"] ?? "") === "Regular") ? "selected" : ""; ?>>Regular</option>
                                        <option value="Probationary" <?php echo (($row["employment_status"] ?? "") === "Probationary") ? "selected" : ""; ?>>Probationary</option>
                                        <option value="Resigned" <?php echo (($row["employment_status"] ?? "") === "Resigned") ? "selected" : ""; ?>>Resigned</option>
                                        <option value="Terminated" <?php echo (($row["employment_status"] ?? "") === "Terminated") ? "selected" : ""; ?>>Terminated</option>
                                    </select>
                                    <?php echo error_text('employment_status'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Salary Basis</label>
                                    <select name="salary_basis" class="w-full rounded-2xl border <?php echo isset($errors['salary_basis']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                        <option value="">Salary Basis</option>
                                        <option value="Daily" <?php echo (($row["salary_basis"] ?? "") === "Daily") ? "selected" : ""; ?>>Daily</option>
                                        <option value="Weekly" <?php echo (($row["salary_basis"] ?? "") === "Weekly") ? "selected" : ""; ?>>Weekly</option>
                                        <option value="Semi-Monthly" <?php echo (($row["salary_basis"] ?? "") === "Semi-Monthly") ? "selected" : ""; ?>>Semi-Monthly</option>
                                        <option value="Monthly" <?php echo (($row["salary_basis"] ?? "") === "Monthly") ? "selected" : ""; ?>>Monthly</option>
                                    </select>
                                    <?php echo error_text('salary_basis'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Rate</label>
                                    <input type="text" name="rate" value="<?php echo htmlspecialchars($row["rate"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['rate']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('rate'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Basic Salary</label>
                                    <input type="text" name="basic_salary" value="<?php echo htmlspecialchars($row["basic_salary"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['basic_salary']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('basic_salary'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">KPI</label>
                                    <input type="text" name="kpi" value="<?php echo htmlspecialchars($row["kpi"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['kpi']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('kpi'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Accommodation (Transpo/Food)</label>
                                    <input type="text" name="accommodation" value="<?php echo htmlspecialchars($row["accommodation"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['accommodation']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('accommodation'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Personal Email</label>
                                    <input type="email" name="personal_email" value="<?php echo htmlspecialchars($row["personal_email"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['personal_email']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('personal_email'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Company Email</label>
                                    <input type="email" name="company_email" value="<?php echo htmlspecialchars($row["company_email"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['company_email']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('company_email'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">Region</label>
                                    <input type="text" name="region" value="<?php echo htmlspecialchars($row["region"] ?? ""); ?>" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">TIN No.</label>
                                    <input type="text" name="tin_no" value="<?php echo htmlspecialchars($row["tin_no"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['tin_no']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('tin_no'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">SSS No.</label>
                                    <input type="text" name="sss_no" value="<?php echo htmlspecialchars($row["sss_no"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['sss_no']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('sss_no'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">PhilHealth No.</label>
                                    <input type="text" name="philhealth_no" value="<?php echo htmlspecialchars($row["philhealth_no"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['philhealth_no']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('philhealth_no'); ?>
                                </div>

                                <div>
                                    <label class="block text-sm font-semibold mb-1">PAG-IBIG No.</label>
                                    <input type="text" name="pagibig_no" value="<?php echo htmlspecialchars($row["pagibig_no"] ?? ""); ?>" class="w-full rounded-2xl border <?php echo isset($errors['pagibig_no']) ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-gray-100'; ?> py-3 px-4 text-sm">
                                    <?php echo error_text('pagibig_no'); ?>
                                </div>

                                <div class="md:col-span-3">
                                    <label class="block text-sm font-semibold mb-2">Document Checklist</label>
                                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                        <label class="flex items-center gap-2 rounded-2xl border border-gray-300 bg-gray-100 px-4 py-3 cursor-pointer">
                                            <input type="checkbox" name="medical" value="1" <?php echo checked_value_edit($row["medical"] ?? "0"); ?>>
                                            <span>Medical</span>
                                        </label>

                                        <label class="flex items-center gap-2 rounded-2xl border border-gray-300 bg-gray-100 px-4 py-3 cursor-pointer">
                                            <input type="checkbox" name="id_file" value="1" <?php echo checked_value_edit($row["id_file"] ?? "0"); ?>>
                                            <span>ID</span>
                                        </label>

                                        <label class="flex items-center gap-2 rounded-2xl border border-gray-300 bg-gray-100 px-4 py-3 cursor-pointer">
                                            <input type="checkbox" name="contract" value="1" <?php echo checked_value_edit($row["contract"] ?? "0"); ?>>
                                            <span>Contract</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="xl:col-span-2 flex justify-end gap-3">
                            <button
                                type="button"
                                onclick="window.location.href='employee.php'"
                                class="px-5 py-3 cursor-pointer rounded-2xl bg-red-500 text-black hover:bg-red-800 transition"
                            >
                                Cancel
                            </button>

                            <button
                                type="submit"
                                class="px-6 py-3 rounded-2xl bg-yellow-500 text-white font-medium hover:bg-yellow-600 transition cursor-pointer"
                            >
                                Update Employee
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </section>

    <script>
    function normalizeGovId(value) {
        return value.replace(/\D+/g, "");
    }

    function toggleEndOfEmployment() {
        const status = document.getElementById("employment_status").value;
        const endInput = document.getElementById("end_of_employment");

        if (status === "Resigned" || status === "Terminated") {
            endInput.removeAttribute("disabled");
        } else {
            endInput.value = "";
        }
    }

    document.getElementById("employeeForm").addEventListener("submit", function (e) {
        let hasError = false;

        const contactNumber = document.getElementById("contact_number").value.trim();
        const emergencyNumber = document.getElementById("emergency_number").value.trim();
        const employeeId = document.getElementById("employee_id").value.trim();
        const employmentStatus = document.getElementById("employment_status").value.trim();
        const endOfEmployment = document.getElementById("end_of_employment").value.trim();

        const tinInput = document.querySelector('input[name="tin_no"]');
        const sssInput = document.querySelector('input[name="sss_no"]');
        const philhealthInput = document.querySelector('input[name="philhealth_no"]');
        const pagibigInput = document.querySelector('input[name="pagibig_no"]');

        const tinNo = normalizeGovId(tinInput.value.trim());
        const sssNo = normalizeGovId(sssInput.value.trim());
        const philhealthNo = normalizeGovId(philhealthInput.value.trim());
        const pagibigNo = normalizeGovId(pagibigInput.value.trim());

        tinInput.value = tinNo;
        sssInput.value = sssNo;
        philhealthInput.value = philhealthNo;
        pagibigInput.value = pagibigNo;

        if (!/^09\d{9}$/.test(contactNumber)) {
            hasError = true;
        }

        if (emergencyNumber !== "" && !/^09\d{9}$/.test(emergencyNumber)) {
            hasError = true;
        }

        if (employeeId !== "" && !/^[A-Za-z0-9_-]+$/.test(employeeId)) {
            hasError = true;
        }

        if (tinNo !== "" && !(tinNo.length === 9 || tinNo.length === 12)) {
            hasError = true;
        }

        if (sssNo !== "" && sssNo.length !== 10) {
            hasError = true;
        }

        if (philhealthNo !== "" && philhealthNo.length !== 12) {
            hasError = true;
        }

        if (pagibigNo !== "" && pagibigNo.length !== 12) {
            hasError = true;
        }

        if ((employmentStatus === "Resigned" || employmentStatus === "Terminated") && endOfEmployment === "") {
            hasError = true;
            alert("Please select End of Employment for resigned or terminated employees.");
        }

        if (hasError) {
            e.preventDefault();
        }
    });

    document.addEventListener("DOMContentLoaded", function () {
        const employmentStatus = document.getElementById("employment_status");
        if (employmentStatus) {
            employmentStatus.addEventListener("change", toggleEndOfEmployment);
            toggleEndOfEmployment();
        }
    });
    </script>
</body>
</html>
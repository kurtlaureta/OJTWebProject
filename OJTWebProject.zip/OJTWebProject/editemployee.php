<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php";

$id = (int)($_GET["id"] ?? $_POST["id"] ?? 0);

if ($id <= 0) {
    die("Invalid employee ID.");
}

$message = "";
$errors = [];

function clean_input($value)
{
    return trim($value ?? "");
}

function is_valid_name($value)
{
    return preg_match("/^[a-zA-Z\s.'-]+$/", $value);
}

/* =========================
   LOAD EMPLOYEE DATA FIRST
========================= */
$stmt = $conn->prepare("SELECT * FROM employees WHERE id = ? LIMIT 1");
if (!$stmt) {
    die("Failed to prepare employee query.");
}

$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result || $result->num_rows === 0) {
    die("Employee not found.");
}

$row = $result->fetch_assoc();
$stmt->close();

/* =========================
   UPDATE EMPLOYEE
========================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $first_name = clean_input($_POST["first_name"] ?? "");
    $middle_name = clean_input($_POST["middle_name"] ?? "");
    $last_name = clean_input($_POST["last_name"] ?? "");
    $birthdate = clean_input($_POST["birthdate"] ?? "");
    $gender = clean_input($_POST["gender"] ?? "");
    $civil_status = clean_input($_POST["civil_status"] ?? "");
    $birthplace = clean_input($_POST["birthplace"] ?? "");
    $contact_number = clean_input($_POST["contact_number"] ?? "");
    $permanent_address = clean_input($_POST["permanent_address"] ?? "");
    $present_address = clean_input($_POST["present_address"] ?? "");
    $father_name = clean_input($_POST["father_name"] ?? "");
    $mother_name = clean_input($_POST["mother_name"] ?? "");
    $emergency_person = clean_input($_POST["emergency_person"] ?? "");
    $emergency_number = clean_input($_POST["emergency_number"] ?? "");
    $education = clean_input($_POST["education"] ?? "");
    $course = clean_input($_POST["course"] ?? "");
    $employee_id = clean_input($_POST["employee_id"] ?? "");
    $department = clean_input($_POST["department"] ?? "");
    $position = clean_input($_POST["position"] ?? "");
    $hire_date = clean_input($_POST["hire_date"] ?? "");
    $employment_status = clean_input($_POST["employment_status"] ?? "");
    $separation_date = clean_input($_POST["separation_date"] ?? "");
    $assigned_area = clean_input($_POST["assigned_area"] ?? "");

    /* =========================
       REQUIRED FIELDS
    ========================= */
    if ($first_name === "") $errors[] = "First name is required.";
    if ($last_name === "") $errors[] = "Last name is required.";
    if ($employee_id === "") $errors[] = "Employee ID is required.";
    if ($contact_number === "") $errors[] = "Contact number is required.";
    if ($birthdate === "") $errors[] = "Birthdate is required.";
    if ($gender === "") $errors[] = "Gender is required.";
    if ($civil_status === "") $errors[] = "Civil status is required.";
    if ($hire_date === "") $errors[] = "Hire date is required.";
    if ($employment_status === "") $errors[] = "Employment status is required.";

    if (($employment_status === "Resigned" || $employment_status === "Terminated") && $separation_date === "") {
        $errors[] = "Separation date is required for resigned or terminated employees.";
    }

    /* =========================
       NAME VALIDATION
    ========================= */
    if ($first_name !== "" && !is_valid_name($first_name)) {
        $errors[] = "First name contains invalid characters.";
    }

    if ($middle_name !== "" && !is_valid_name($middle_name)) {
        $errors[] = "Middle name contains invalid characters.";
    }

    if ($last_name !== "" && !is_valid_name($last_name)) {
        $errors[] = "Last name contains invalid characters.";
    }

    if ($father_name !== "" && !is_valid_name($father_name)) {
        $errors[] = "Father's name contains invalid characters.";
    }

    if ($mother_name !== "" && !is_valid_name($mother_name)) {
        $errors[] = "Mother's name contains invalid characters.";
    }

    if ($emergency_person !== "" && !is_valid_name($emergency_person)) {
        $errors[] = "Emergency contact person contains invalid characters.";
    }

    /* =========================
       PHONE NUMBER VALIDATION
    ========================= */
    if ($contact_number !== "" && !preg_match('/^09\d{9}$/', $contact_number)) {
        $errors[] = "Contact number must be exactly 11 digits and start with 09.";
    }

    if ($emergency_number !== "" && !preg_match('/^09\d{9}$/', $emergency_number)) {
        $errors[] = "Emergency contact number must be exactly 11 digits and start with 09.";
    }

    /* =========================
       EMPLOYEE ID VALIDATION
    ========================= */
    if ($employee_id !== "" && !preg_match('/^[A-Za-z0-9_-]+$/', $employee_id)) {
        $errors[] = "Employee ID must only contain letters, numbers, dash, or underscore.";
    }

    /* =========================
       VALID CHOICES
    ========================= */
    $valid_genders = ["Male", "Female"];
    $valid_civil_status = ["Single", "Married", "Widowed"];
    $valid_education = ["High School", "College Level", "College Graduate", "Vocational"];
    $valid_employment_status = ["Active", "Regular", "Probationary", "Resigned", "Terminated"];

    if ($gender !== "" && !in_array($gender, $valid_genders, true)) {
        $errors[] = "Invalid gender selected.";
    }

    if ($civil_status !== "" && !in_array($civil_status, $valid_civil_status, true)) {
        $errors[] = "Invalid civil status selected.";
    }

    if ($education !== "" && !in_array($education, $valid_education, true)) {
        $errors[] = "Invalid educational attainment selected.";
    }

    if ($employment_status !== "" && !in_array($employment_status, $valid_employment_status, true)) {
        $errors[] = "Invalid employment status selected.";
    }

    /* =========================
       DATE VALIDATION
    ========================= */
    $today = date("Y-m-d");

    if ($birthdate !== "") {
        $birth_obj = DateTime::createFromFormat("Y-m-d", $birthdate);
        if (!$birth_obj || $birth_obj->format("Y-m-d") !== $birthdate) {
            $errors[] = "Invalid birthdate.";
        } elseif ($birthdate > $today) {
            $errors[] = "Birthdate cannot be in the future.";
        }
    }

    if ($hire_date !== "") {
        $hire_obj = DateTime::createFromFormat("Y-m-d", $hire_date);
        if (!$hire_obj || $hire_obj->format("Y-m-d") !== $hire_date) {
            $errors[] = "Invalid hire date.";
        } elseif ($hire_date > $today) {
            $errors[] = "Hire date cannot be in the future.";
        }
    }

    if ($separation_date !== "") {
        $sep_obj = DateTime::createFromFormat("Y-m-d", $separation_date);
        if (!$sep_obj || $sep_obj->format("Y-m-d") !== $separation_date) {
            $errors[] = "Invalid separation date.";
        } elseif ($separation_date > $today) {
            $errors[] = "Separation date cannot be in the future.";
        }
    }

    if ($birthdate !== "" && $hire_date !== "") {
        $birth_ts = strtotime($birthdate);
        $hire_ts = strtotime($hire_date);

        if ($hire_ts < $birth_ts) {
            $errors[] = "Hire date cannot be earlier than birthdate.";
        } else {
            $age_at_hire = date_diff(date_create($birthdate), date_create($hire_date))->y;
            if ($age_at_hire < 16) {
                $errors[] = "Employee age at hire must be at least 16 years old.";
            }
        }
    }

    if ($hire_date !== "" && $separation_date !== "") {
        if ($separation_date < $hire_date) {
            $errors[] = "Separation date cannot be earlier than hire date.";
        }
    }

    /* =========================
       DUPLICATE EMPLOYEE ID CHECK
    ========================= */
    if (empty($errors)) {
        $checkQuery = "SELECT COUNT(*) AS count FROM employees WHERE employee_id = ? AND id != ?";
        $stmt = $conn->prepare($checkQuery);

        if ($stmt) {
            $stmt->bind_param("si", $employee_id, $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $duplicate = $result->fetch_assoc();

            if (($duplicate["count"] ?? 0) > 0) {
                $errors[] = "Employee ID already exists.";
            }

            $stmt->close();
        } else {
            $errors[] = "Failed to prepare duplicate employee ID check.";
        }
    }

    /* =========================
       AUTO ARCHIVE IF RESIGNED OR TERMINATED
    ========================= */
    $is_archived = ($employment_status === "Resigned" || $employment_status === "Terminated") ? 1 : 0;

    if ($employment_status !== "Resigned" && $employment_status !== "Terminated") {
        $separation_date = null;
    }

    /* =========================
       UPDATE RECORD
    ========================= */
    if (empty($errors)) {
        $stmt = $conn->prepare("UPDATE employees SET
            first_name = ?,
            middle_name = ?,
            last_name = ?,
            birthdate = ?,
            gender = ?,
            civil_status = ?,
            birthplace = ?,
            contact_number = ?,
            permanent_address = ?,
            present_address = ?,
            father_name = ?,
            mother_name = ?,
            emergency_person = ?,
            emergency_number = ?,
            education = ?,
            course = ?,
            employee_id = ?,
            department = ?,
            position = ?,
            hire_date = ?,
            employment_status = ?,
            separation_date = ?,
            assigned_area = ?,
            is_archived = ?
            WHERE id = ?");

        if ($stmt) {
            $stmt->bind_param(
                "sssssssssssssssssssssssii",
                $first_name,
                $middle_name,
                $last_name,
                $birthdate,
                $gender,
                $civil_status,
                $birthplace,
                $contact_number,
                $permanent_address,
                $present_address,
                $father_name,
                $mother_name,
                $emergency_person,
                $emergency_number,
                $education,
                $course,
                $employee_id,
                $department,
                $position,
                $hire_date,
                $employment_status,
                $separation_date,
                $assigned_area,
                $is_archived,
                $id
            );

            if ($stmt->execute()) {
                header("Location: employee.php?updated=1");
                exit;
            } else {
                $message = "Error updating employee: " . htmlspecialchars($stmt->error);
            }

            $stmt->close();
        } else {
            $message = "Failed to prepare update query.";
        }
    }

    if (!empty($errors)) {
        $message = implode("<br>", array_map("htmlspecialchars", $errors));

        $row = [
            "id" => $id,
            "first_name" => $first_name,
            "middle_name" => $middle_name,
            "last_name" => $last_name,
            "birthdate" => $birthdate,
            "gender" => $gender,
            "civil_status" => $civil_status,
            "birthplace" => $birthplace,
            "contact_number" => $contact_number,
            "permanent_address" => $permanent_address,
            "present_address" => $present_address,
            "father_name" => $father_name,
            "mother_name" => $mother_name,
            "emergency_person" => $emergency_person,
            "emergency_number" => $emergency_number,
            "education" => $education,
            "course" => $course,
            "employee_id" => $employee_id,
            "department" => $department,
            "position" => $position,
            "hire_date" => $hire_date,
            "employment_status" => $employment_status,
            "separation_date" => $separation_date,
            "assigned_area" => $assigned_area
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../index.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <title>Edit Employee</title>
</head>
<body class="flex overflow-x-hidden bg-gray-100">
    <?php include 'navbar.php'; ?>

    <section class="flex-1 min-h-screen ml-47">
        <nav class="bg-gray-200 w-full h-auto p-4 shadow-md shadow-gray-500">
            <div class="flex justify-between items-center flex-wrap gap-3">
                <div class="bg-blue-400 p-1 px-4 rounded-3xl cursor-pointer text-white duration-200 transition-all hover:bg-blue-700 w-fit">
                    <a href="employee.php" class="flex w-auto h-auto items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 mr-1">
                            <path fill-rule="evenodd" d="M9.53 2.47a.75.75 0 0 1 0 1.06L4.81 8.25H15a6.75 6.75 0 0 1 0 13.5h-3a.75.75 0 0 1 0-1.5h3a5.25 5.25 0 1 0 0-10.5H4.81l4.72 4.72a.75.75 0 1 1-1.06 1.06l-6-6a.75.75 0 0 1 0-1.06l6-6a.75.75 0 0 1 1.06 0Z" clip-rule="evenodd" />
                        </svg>
                        Back
                    </a>
                </div>

                <div class="flex items-center font-bold text-white bg-yellow-500 p-2 px-4 rounded-2xl">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 mr-2 text-blue-900">
                        <path d="M16.862 4.487a2.625 2.625 0 1 1 3.712 3.713L8.197 20.577a4.5 4.5 0 0 1-1.897 1.13l-2.685.895a.75.75 0 0 1-.948-.948l.895-2.685a4.5 4.5 0 0 1 1.13-1.897L16.862 4.487Z" />
                    </svg>
                    EDIT EMPLOYEE
                </div>

                <div class="flex text-[10px] font-bold text-black items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-3 text-green-500 mr-1">
                        <path fill-rule="evenodd" d="m11.54 22.351.07.04.028.016a.76.76 0 0 0 .723 0l.028-.015.071-.041a16.975 16.975 0 0 0 1.144-.742 19.58 19.58 0 0 0 2.683-2.282c1.944-1.99 3.963-4.98 3.963-8.827a8.25 8.25 0 0 0-16.5 0c0 3.846 2.02 6.837 3.963 8.827a19.58 19.58 0 0 0 2.682 2.282 16.975 16.975 0 0 0 1.145.742ZM12 13.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" clip-rule="evenodd" />
                    </svg>
                    WH1 SANTA ROSA
                </div>
            </div>
        </nav>

        <section class="p-3 flex justify-center">
            <div class="border-2 p-3 w-full max-w-7xl bg-white rounded-2xl shadow">
                <div class="w-full mx-auto px-6 py-6">

                    <?php if (!empty($message)): ?>
                        <div class="mb-4 rounded-xl bg-red-100 text-red-700 px-4 py-3">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="" id="employeeForm" class="grid grid-cols-1 xl:grid-cols-2 gap-6" novalidate>
                        <input type="hidden" name="id" value="<?php echo (int)($row["id"] ?? 0); ?>">

                        <div class="bg-white border border-gray-200 rounded-3xl shadow-sm p-6">
                            <h2 class="text-lg font-bold text-center text-black mb-5">Personal Details</h2>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <input type="text" name="first_name" value="<?php echo htmlspecialchars($row["first_name"] ?? ""); ?>" placeholder="First Name" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm" required>

                                <input type="text" name="middle_name" value="<?php echo htmlspecialchars($row["middle_name"] ?? ""); ?>" placeholder="Middle Name" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">

                                <input type="text" name="last_name" value="<?php echo htmlspecialchars($row["last_name"] ?? ""); ?>" placeholder="Last Name" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm md:col-span-2" required>

                                <input type="date" name="birthdate" value="<?php echo htmlspecialchars($row["birthdate"] ?? ""); ?>" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm" required>

                                <select name="gender" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm" required>
                                    <option value="">Gender</option>
                                    <option value="Male" <?php echo (($row["gender"] ?? "") === "Male") ? "selected" : ""; ?>>Male</option>
                                    <option value="Female" <?php echo (($row["gender"] ?? "") === "Female") ? "selected" : ""; ?>>Female</option>
                                </select>

                                <select name="civil_status" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm" required>
                                    <option value="">Civil Status</option>
                                    <option value="Single" <?php echo (($row["civil_status"] ?? "") === "Single") ? "selected" : ""; ?>>Single</option>
                                    <option value="Married" <?php echo (($row["civil_status"] ?? "") === "Married") ? "selected" : ""; ?>>Married</option>
                                    <option value="Widowed" <?php echo (($row["civil_status"] ?? "") === "Widowed") ? "selected" : ""; ?>>Widowed</option>
                                </select>

                                <input type="text" name="birthplace" value="<?php echo htmlspecialchars($row["birthplace"] ?? ""); ?>" placeholder="Birthplace" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">

                                <div class="md:col-span-2">
                                    <input type="tel" id="contact_number" name="contact_number" maxlength="11" value="<?php echo htmlspecialchars($row["contact_number"] ?? ""); ?>" placeholder="Contact Number" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm" required>
                                    <p id="contactNumberError" class="text-red-600 text-sm mt-1"></p>
                                </div>

                                <textarea name="permanent_address" placeholder="Permanent Address" rows="3" class="md:col-span-2 w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm resize-none"><?php echo htmlspecialchars($row["permanent_address"] ?? ""); ?></textarea>

                                <textarea name="present_address" placeholder="Present Address" rows="3" class="md:col-span-2 w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm resize-none"><?php echo htmlspecialchars($row["present_address"] ?? ""); ?></textarea>
                            </div>
                        </div>

                        <div class="bg-white border border-gray-200 rounded-3xl shadow-sm p-6">
                            <h2 class="text-lg font-bold text-center text-black mb-5">Family / Emergency / Education</h2>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <input type="text" name="father_name" value="<?php echo htmlspecialchars($row["father_name"] ?? ""); ?>" placeholder="Father's Name" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm md:col-span-2">

                                <input type="text" name="mother_name" value="<?php echo htmlspecialchars($row["mother_name"] ?? ""); ?>" placeholder="Mother's Name" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm md:col-span-2">

                                <input type="text" name="emergency_person" value="<?php echo htmlspecialchars($row["emergency_person"] ?? ""); ?>" placeholder="Emergency Contact Person" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">

                                <div>
                                    <input type="tel" id="emergency_number" name="emergency_number" maxlength="11" value="<?php echo htmlspecialchars($row["emergency_number"] ?? ""); ?>" placeholder="Emergency Contact Number" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                                    <p id="emergencyNumberError" class="text-red-600 text-sm mt-1"></p>
                                </div>

                                <select name="education" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">
                                    <option value="">Educational Attainment</option>
                                    <option value="High School" <?php echo (($row["education"] ?? "") === "High School") ? "selected" : ""; ?>>High School</option>
                                    <option value="College Level" <?php echo (($row["education"] ?? "") === "College Level") ? "selected" : ""; ?>>College Level</option>
                                    <option value="College Graduate" <?php echo (($row["education"] ?? "") === "College Graduate") ? "selected" : ""; ?>>College Graduate</option>
                                    <option value="Vocational" <?php echo (($row["education"] ?? "") === "Vocational") ? "selected" : ""; ?>>Vocational</option>
                                </select>

                                <input type="text" name="course" value="<?php echo htmlspecialchars($row["course"] ?? ""); ?>" placeholder="Course" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">

                                <div class="md:col-span-2 border-t border-gray-200 pt-5 mt-2">
                                    <h3 class="text-base font-semibold text-gray-800 mb-4">Company Details</h3>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <input type="text" id="employee_id" name="employee_id" value="<?php echo htmlspecialchars($row["employee_id"] ?? ""); ?>" placeholder="Employee ID" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm" required>

                                        <input type="text" name="department" value="<?php echo htmlspecialchars($row["department"] ?? ""); ?>" placeholder="Department" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">

                                        <input type="text" name="position" value="<?php echo htmlspecialchars($row["position"] ?? ""); ?>" placeholder="Position" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">

                                        <input type="date" name="hire_date" value="<?php echo htmlspecialchars($row["hire_date"] ?? ""); ?>" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm" required>

                                        <select id="employment_status" name="employment_status" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm" required>
                                            <option value="">Employment Status</option>
                                            <option value="Active" <?php echo (($row["employment_status"] ?? "") === "Active") ? "selected" : ""; ?>>Active</option>
                                            <option value="Regular" <?php echo (($row["employment_status"] ?? "") === "Regular") ? "selected" : ""; ?>>Regular</option>
                                            <option value="Probationary" <?php echo (($row["employment_status"] ?? "") === "Probationary") ? "selected" : ""; ?>>Probationary</option>
                                            <option value="Resigned" <?php echo (($row["employment_status"] ?? "") === "Resigned") ? "selected" : ""; ?>>Resigned</option>
                                            <option value="Terminated" <?php echo (($row["employment_status"] ?? "") === "Terminated") ? "selected" : ""; ?>>Terminated</option>
                                        </select>

                                        <input type="text" name="assigned_area" value="<?php echo htmlspecialchars($row["assigned_area"] ?? ""); ?>" placeholder="Assigned Branch / Area" class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm">

                                        <div id="separationDateWrapper" class="md:col-span-2">
                                            <h3 class="text-base font-semibold text-gray-800 mb-2">Employment Separation Details</h3>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                                Resignation / Termination Date
                                            </label>
                                            <input
                                                type="date"
                                                name="separation_date"
                                                id="separation_date"
                                                value="<?php echo htmlspecialchars($row["separation_date"] ?? ""); ?>"
                                                class="w-full rounded-2xl border border-gray-300 bg-gray-100 py-3 px-4 text-sm"
                                            >
                                            <p class="text-xs text-gray-500 mt-1">
                                                Fill this only if the employee is resigned or terminated.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="xl:col-span-2 flex justify-end gap-3">
                            <button
                                type="button"
                                onclick="window.location.href='employee.php'"
                                class="px-5 py-3 cursor-pointer rounded-2xl bg-red-500 text-black hover:bg-red-800 transition"
                            >
                                Cancel
                            </button>

                            <button
                                type="submit"
                                class="px-6 py-3 rounded-2xl bg-yellow-500 text-white font-medium hover:bg-yellow-600 transition cursor-pointer"
                            >
                                Update Employee
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </section>

    <script>
    function toggleSeparationDate() {
        const status = document.getElementById("employment_status").value;
        const wrapper = document.getElementById("separationDateWrapper");
        const separationDate = document.getElementById("separation_date");

        if (status === "Resigned" || status === "Terminated") {
            wrapper.style.display = "block";
        } else {
            wrapper.style.display = "none";
            separationDate.value = "";
        }
    }

    document.getElementById("employeeForm").addEventListener("submit", function (e) {
        let hasError = false;

        const contactNumber = document.getElementById("contact_number").value.trim();
        const emergencyNumber = document.getElementById("emergency_number").value.trim();
        const employeeId = document.getElementById("employee_id").value.trim();
        const employmentStatus = document.getElementById("employment_status").value.trim();
        const separationDate = document.getElementById("separation_date").value.trim();

        const contactNumberError = document.getElementById("contactNumberError");
        const emergencyNumberError = document.getElementById("emergencyNumberError");

        contactNumberError.textContent = "";
        emergencyNumberError.textContent = "";

        if (!/^09\d{9}$/.test(contactNumber)) {
            contactNumberError.textContent = "Contact number must be exactly 11 digits and start with 09.";
            hasError = true;
        }

        if (emergencyNumber !== "" && !/^09\d{9}$/.test(emergencyNumber)) {
            emergencyNumberError.textContent = "Emergency contact number must be exactly 11 digits and start with 09.";
            hasError = true;
        }

        if (employeeId !== "" && !/^[A-Za-z0-9_-]+$/.test(employeeId)) {
            alert("Employee ID must only contain letters, numbers, dash, or underscore.");
            hasError = true;
        }

        if ((employmentStatus === "Resigned" || employmentStatus === "Terminated") && separationDate === "") {
            alert("Please select a separation date for resigned or terminated employees.");
            hasError = true;
        }

        if (hasError) {
            e.preventDefault();
        }
    });

    document.addEventListener("DOMContentLoaded", function () {
        const employmentStatus = document.getElementById("employment_status");
        if (employmentStatus) {
            employmentStatus.addEventListener("change", toggleSeparationDate);
            toggleSeparationDate();
        }
    });
    </script>
</body>
</html>
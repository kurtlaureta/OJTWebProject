<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php";

$branch   = trim($_GET["branch"] ?? "");
$group_by = trim($_GET["group_by"] ?? "");
$sort     = trim($_GET["sort"] ?? "");
$search   = trim($_GET["search"] ?? "");
$page     = max(1, (int)($_GET["page"] ?? 1));
$limit    = 10;
$offset   = ($page - 1) * $limit;

/*
|--------------------------------------------------------------------------
| Load distinct branches for dropdown
|--------------------------------------------------------------------------
*/
$branches = [];
$branchSql = "SELECT DISTINCT assigned_area
              FROM employees
              WHERE is_archived = 0
                AND assigned_area IS NOT NULL
                AND assigned_area != ''
              ORDER BY assigned_area ASC";

$branchResult = $conn->query($branchSql);
if ($branchResult) {
    while ($branchRow = $branchResult->fetch_assoc()) {
        $branches[] = $branchRow["assigned_area"];
    }
}

/*
|--------------------------------------------------------------------------
| WHERE clause builder
|--------------------------------------------------------------------------
*/
$whereSql = " WHERE is_archived = 0 ";
$params = [];
$types = "";

if ($branch !== "") {
    $whereSql .= " AND assigned_area = ? ";
    $params[] = $branch;
    $types .= "s";
}

if ($search !== "") {
    $whereSql .= " AND (
        employee_id LIKE ?
        OR CONCAT(first_name, ' ', middle_name, ' ', last_name) LIKE ?
        OR department LIKE ?
        OR position LIKE ?
        OR employment_status LIKE ?
        OR assigned_area LIKE ?
    ) ";
    $searchLike = "%" . $search . "%";
    for ($i = 0; $i < 6; $i++) {
        $params[] = $searchLike;
        $types .= "s";
    }
}

/*
|--------------------------------------------------------------------------
| ORDER BY builder
|--------------------------------------------------------------------------
*/
$orderParts = [];

switch ($group_by) {
    case "department":
        $orderParts[] = "department ASC";
        break;
    case "position":
        $orderParts[] = "position ASC";
        break;
    case "name":
        $orderParts[] = "first_name ASC";
        $orderParts[] = "last_name ASC";
        break;
    case "employee_id":
        $orderParts[] = "employee_id ASC";
        break;
    case "status":
        $orderParts[] = "employment_status ASC";
        break;
}

switch ($sort) {
    case "az":
        $orderParts[] = "first_name ASC";
        $orderParts[] = "last_name ASC";
        break;
    case "za":
        $orderParts[] = "first_name DESC";
        $orderParts[] = "last_name DESC";
        break;
    case "newest":
        $orderParts[] = "hire_date DESC";
        break;
    case "oldest":
        $orderParts[] = "hire_date ASC";
        break;
    case "empid_asc":
        $orderParts[] = "employee_id ASC";
        break;
    case "empid_desc":
        $orderParts[] = "employee_id DESC";
        break;
    case "status_az":
        $orderParts[] = "employment_status ASC";
        break;
    case "status_za":
        $orderParts[] = "employment_status DESC";
        break;
}

$orderSql = !empty($orderParts)
    ? " ORDER BY " . implode(", ", $orderParts)
    : " ORDER BY id DESC ";

/*
|--------------------------------------------------------------------------
| Count total rows for pagination
|--------------------------------------------------------------------------
*/
$countSql = "SELECT COUNT(*) AS total FROM employees" . $whereSql;

if (!empty($params)) {
    $countStmt = $conn->prepare($countSql);
    if (!$countStmt) {
        die("Error preparing count statement: " . $conn->error);
    }

    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();
    $countResult = $countStmt->get_result();
    $totalRows = (int)($countResult->fetch_assoc()["total"] ?? 0);
    $countStmt->close();
} else {
    $countResult = $conn->query($countSql);
    $totalRows = (int)($countResult->fetch_assoc()["total"] ?? 0);
}

$totalPages = max(1, (int)ceil($totalRows / $limit));
if ($page > $totalPages) {
    $page = $totalPages;
    $offset = ($page - 1) * $limit;
}

/*
|--------------------------------------------------------------------------
| Main paginated query
|--------------------------------------------------------------------------
*/
$sql = "SELECT * FROM employees" . $whereSql . $orderSql . " LIMIT ? OFFSET ?";

$mainParams = $params;
$mainTypes = $types . "ii";
$mainParams[] = $limit;
$mainParams[] = $offset;

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Error preparing main query: " . $conn->error);
}

$stmt->bind_param($mainTypes, ...$mainParams);
$stmt->execute();
$result = $stmt->get_result();

/*
|--------------------------------------------------------------------------
| Pagination helper
|--------------------------------------------------------------------------
*/
function buildPageUrl($pageNum, $branch, $group_by, $sort, $search) {
    $query = http_build_query([
        "branch" => $branch,
        "group_by" => $group_by,
        "sort" => $sort,
        "search" => $search,
        "page" => $pageNum
    ]);
    return "employee.php?" . $query;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../index.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <title>Employee List</title>
</head>
<body class="flex bg-white">
    <?php include 'navbar.php'; ?>

    <section id="EmployeeList" class="flex-1 min-h-screen ml-47">
        <div class="bg-gray-200 w-full h-fit p-3 flex shadow-xl border-b border-gray-300 justify-between">
            <div class="text-black font-bold flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 text-green-700 mr-2">
                    <path fill-rule="evenodd" d="M7.502 6h7.128A3.375 3.375 0 0 1 18 9.375v9.375a3 3 0 0 0 3-3V6.108c0-1.505-1.125-2.811-2.664-2.94a48.972 48.972 0 0 0-.673-.05A3 3 0 0 0 15 1.5h-1.5a3 3 0 0 0-2.663 1.618c-.225.015-.45.032-.673.05C8.662 3.295 7.554 4.542 7.502 6ZM13.5 3A1.5 1.5 0 0 0 12 4.5h4.5A1.5 1.5 0 0 0 15 3h-1.5Z" clip-rule="evenodd" />
                    <path fill-rule="evenodd" d="M3 9.375C3 8.339 3.84 7.5 4.875 7.5h9.75c1.036 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875h-9.75A1.875 1.875 0 0 1 3 20.625V9.375ZM6 12a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V12Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM6 15a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V15Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM6 18a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V18Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd" />
                </svg>
                EMPLOYEE LIST
            </div>

            <div id="liveDateTime" class="font-bold text-black"></div>
        </div>

        <?php if (isset($_GET["msg"]) && $_GET["msg"] === "archived"): ?>
            <div class="max-w-7xl mx-auto mt-4 px-4">
                <div class="bg-yellow-100 border border-yellow-300 text-yellow-800 px-4 py-3 rounded-2xl">
                    Employee archived successfully.
                </div>
            </div>
        <?php endif; ?>

        <div class="w-full max-w-7xl mx-auto bg-gray-200 p-4 m-4 rounded-3xl flex flex-col lg:flex-row lg:items-center gap-3">
            <div class="w-full lg:flex-1 flex items-center border px-2 py-2 rounded-2xl hover:shadow-gray-400 hover:shadow-md bg-white">
                <input
                    type="text"
                    id="searchInput"
                    value="<?php echo htmlspecialchars($search); ?>"
                    placeholder="Search employees..."
                    class="w-full p-1 outline-none bg-transparent text-sm md:text-base"
                >
            </div>

            <form id="filterForm" method="GET" action="" class="w-full sm:w-full md:w-full lg:w-auto flex flex-col sm:flex-row gap-3">
                <input type="hidden" name="search" id="searchHidden" value="<?php echo htmlspecialchars($search); ?>">
                <input type="hidden" name="page" id="pageHidden" value="1">

                <select name="branch" onchange="syncSearchAndSubmit()"
                    class="w-full lg:w-auto appearance-none border border-black rounded-2xl text-sm bg-white p-2 text-center cursor-pointer hover:border-red-400 hover:bg-red-50">
                    <option value="">ALL BRANCHES</option>
                    <?php foreach ($branches as $branchName): ?>
                        <option value="<?php echo htmlspecialchars($branchName); ?>" <?php echo ($branch === $branchName) ? "selected" : ""; ?>>
                            <?php echo htmlspecialchars($branchName); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select name="group_by" onchange="syncSearchAndSubmit()"
                    class="w-full lg:w-auto appearance-none border border-black rounded-2xl text-sm bg-white p-2 text-center cursor-pointer hover:border-red-400 hover:bg-red-50">
                    <option value="">GROUP BY (ALL)</option>
                    <option value="department" <?php echo ($group_by === "department") ? "selected" : ""; ?>>Department</option>
                    <option value="position" <?php echo ($group_by === "position") ? "selected" : ""; ?>>Position</option>
                    <option value="name" <?php echo ($group_by === "name") ? "selected" : ""; ?>>Name</option>
                    <option value="employee_id" <?php echo ($group_by === "employee_id") ? "selected" : ""; ?>>Employee ID</option>
                    <option value="status" <?php echo ($group_by === "status") ? "selected" : ""; ?>>Status</option>
                </select>

                <select name="sort" onchange="syncSearchAndSubmit()"
                    class="w-full lg:w-auto appearance-none border border-black rounded-2xl text-sm bg-white p-2 text-center cursor-pointer hover:border-red-400 hover:bg-red-50">
                    <option value="">SORT</option>
                    <option value="az" <?php echo ($sort === "az") ? "selected" : ""; ?>>A-Z Name</option>
                    <option value="za" <?php echo ($sort === "za") ? "selected" : ""; ?>>Z-A Name</option>
                    <option value="newest" <?php echo ($sort === "newest") ? "selected" : ""; ?>>Date Hired: Newest</option>
                    <option value="oldest" <?php echo ($sort === "oldest") ? "selected" : ""; ?>>Date Hired: Oldest</option>
                    <option value="empid_asc" <?php echo ($sort === "empid_asc") ? "selected" : ""; ?>>Employee ID Ascending</option>
                    <option value="empid_desc" <?php echo ($sort === "empid_desc") ? "selected" : ""; ?>>Employee ID Descending</option>
                    <option value="status_az" <?php echo ($sort === "status_az") ? "selected" : ""; ?>>Status A-Z</option>
                    <option value="status_za" <?php echo ($sort === "status_za") ? "selected" : ""; ?>>Status Z-A</option>
                </select>
            </form>

            <a href="importemployee.php"
               class="w-full sm:w-full md:w-full lg:w-auto inline-flex justify-center items-center bg-green-500 p-2 px-6 rounded-3xl text-white hover:bg-green-700 text-sm">
                Import
            </a>

            <a href="exportemployee.php"
               class="w-full sm:w-full md:w-full lg:w-auto inline-flex justify-center items-center bg-purple-500 p-2 px-6 rounded-3xl text-white hover:bg-purple-700 text-sm">
                Export
            </a>

            <a href="addemployee.php"
               class="w-full sm:w-full md:w-full lg:w-auto inline-flex justify-center items-center bg-blue-400 p-2 px-6 rounded-3xl text-white hover:bg-blue-700 text-sm">
                Add Employee
            </a>
        </div>

        <div class="w-full max-w-7xl mx-auto">
            <div class="bg-gray-200 border border-gray-200 rounded-3xl shadow-sm p-3">
                <div class="flex justify-between items-center mb-2">
                    <h2 class="text-lg font-bold text-gray-800">Employee List</h2>
                    <div class="text-sm text-gray-600">
                        Showing <?php echo $totalRows > 0 ? ($offset + 1) : 0; ?> -
                        <?php echo min($offset + $limit, $totalRows); ?>
                        of <?php echo $totalRows; ?> employees
                    </div>
                </div>

                <div class="overflow-x-auto rounded-3xl overflow-hidden border border-gray-300">
                    <table class="w-full text-sm text-center border-collapse">
                        <thead>
                            <tr class="bg-gray-800 text-white">
                                <th class="p-3 border-b">Employee ID</th>
                                <th class="p-3 border-b">Full Name</th>
                                <th class="p-3 border-b">Birthdate</th>
                                <th class="p-3 border-b">Gender</th>
                                <th class="p-3 border-b">Contact Number</th>
                                <th class="p-3 border-b">Department</th>
                                <th class="p-3 border-b">Position</th>
                                <th class="p-3 border-b">Status</th>
                                <th class="p-3 border-b">Branch / Area</th>
                            </tr>
                        </thead>
                        <tbody id="employeeTableBody">
                            <?php if ($result && $result->num_rows > 0): ?>
                                <?php while ($row = $result->fetch_assoc()): ?>
                                    <?php
                                    $fullName = trim(
                                        ($row["first_name"] ?? "") . " " .
                                        ($row["middle_name"] ?? "") . " " .
                                        ($row["last_name"] ?? "")
                                    );
                                    ?>
                                    <tr
                                        class="hover:bg-green-200 employee-row cursor-pointer"
                                        data-id="<?php echo (int)$row["id"]; ?>"
                                        data-employee_id="<?php echo htmlspecialchars($row["employee_id"] ?? ""); ?>"
                                        data-fullname="<?php echo htmlspecialchars($fullName); ?>"
                                        data-first_name="<?php echo htmlspecialchars($row["first_name"] ?? ""); ?>"
                                        data-middle_name="<?php echo htmlspecialchars($row["middle_name"] ?? ""); ?>"
                                        data-last_name="<?php echo htmlspecialchars($row["last_name"] ?? ""); ?>"
                                        data-birthdate="<?php echo htmlspecialchars($row["birthdate"] ?? ""); ?>"
                                        data-gender="<?php echo htmlspecialchars($row["gender"] ?? ""); ?>"
                                        data-civil_status="<?php echo htmlspecialchars($row["civil_status"] ?? ""); ?>"
                                        data-birthplace="<?php echo htmlspecialchars($row["birthplace"] ?? ""); ?>"
                                        data-contact_number="<?php echo htmlspecialchars($row["contact_number"] ?? ""); ?>"
                                        data-permanent_address="<?php echo htmlspecialchars($row["permanent_address"] ?? ""); ?>"
                                        data-present_address="<?php echo htmlspecialchars($row["present_address"] ?? ""); ?>"
                                        data-father_name="<?php echo htmlspecialchars($row["father_name"] ?? ""); ?>"
                                        data-mother_name="<?php echo htmlspecialchars($row["mother_name"] ?? ""); ?>"
                                        data-emergency_person="<?php echo htmlspecialchars($row["emergency_person"] ?? ""); ?>"
                                        data-emergency_number="<?php echo htmlspecialchars($row["emergency_number"] ?? ""); ?>"
                                        data-education="<?php echo htmlspecialchars($row["education"] ?? ""); ?>"
                                        data-course="<?php echo htmlspecialchars($row["course"] ?? ""); ?>"
                                        data-department="<?php echo htmlspecialchars($row["department"] ?? ""); ?>"
                                        data-position="<?php echo htmlspecialchars($row["position"] ?? ""); ?>"
                                        data-hire_date="<?php echo htmlspecialchars($row["hire_date"] ?? ""); ?>"
                                        data-employment_status="<?php echo htmlspecialchars($row["employment_status"] ?? ""); ?>"
                                        data-assigned_area="<?php echo htmlspecialchars($row["assigned_area"] ?? ""); ?>"
                                    >
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["employee_id"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($fullName); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["birthdate"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["gender"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["contact_number"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["department"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["position"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["employment_status"] ?? ""); ?></td>
                                        <td class="p-3 border-b"><?php echo htmlspecialchars($row["assigned_area"] ?? ""); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="p-4 text-gray-500">No employee records found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                    <div class="mt-4 flex flex-wrap justify-center items-center gap-2">
                        <?php if ($page > 1): ?>
                            <a href="<?php echo htmlspecialchars(buildPageUrl($page - 1, $branch, $group_by, $sort, $search)); ?>"
                               class="px-4 py-2 rounded-xl bg-gray-300 hover:bg-gray-400 text-black">
                                Previous
                            </a>
                        <?php endif; ?>

                        <?php
                        $startPage = max(1, $page - 2);
                        $endPage = min($totalPages, $page + 2);

                        if ($startPage > 1) {
                            echo '<a href="' . htmlspecialchars(buildPageUrl(1, $branch, $group_by, $sort, $search)) . '" class="px-4 py-2 rounded-xl bg-gray-300 hover:bg-gray-400 text-black">1</a>';
                            if ($startPage > 2) {
                                echo '<span class="px-2">...</span>';
                            }
                        }

                        for ($i = $startPage; $i <= $endPage; $i++):
                        ?>
                            <a href="<?php echo htmlspecialchars(buildPageUrl($i, $branch, $group_by, $sort, $search)); ?>"
                               class="px-4 py-2 rounded-xl <?php echo $i === $page ? 'bg-green-500 text-white' : 'bg-gray-300 hover:bg-gray-400 text-black'; ?>">
                                <?php echo $i; ?>
                            </a>
                        <?php endfor; ?>

                        <?php
                        if ($endPage < $totalPages) {
                            if ($endPage < $totalPages - 1) {
                                echo '<span class="px-2">...</span>';
                            }
                            echo '<a href="' . htmlspecialchars(buildPageUrl($totalPages, $branch, $group_by, $sort, $search)) . '" class="px-4 py-2 rounded-xl bg-gray-300 hover:bg-gray-400 text-black">' . $totalPages . '</a>';
                        }
                        ?>

                        <?php if ($page < $totalPages): ?>
                            <a href="<?php echo htmlspecialchars(buildPageUrl($page + 1, $branch, $group_by, $sort, $search)); ?>"
                               class="px-4 py-2 rounded-xl bg-gray-300 hover:bg-gray-400 text-black">
                                Next
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- EMPLOYEE DETAIL MODAL -->
    <div id="employeeModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-50 p-4">
        <div class="bg-white w-full max-w-3xl rounded-3xl shadow-2xl relative overflow-hidden">
            <button id="closeModalBtn" class="absolute top-3 right-4 bg-red-500 cursor-pointer hover:bg-red-700 text-white w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold">
                ×
            </button>

            <div class="bg-gray-900 text-white px-6 py-5">
                <h2 class="text-2xl font-bold" id="modalFullName">Employee Name</h2>
                <p class="text-sm text-gray-300 mt-1" id="modalEmployeeId">EMP-000</p>
            </div>

            <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[70vh] overflow-y-auto">
                <div class="bg-gray-100 rounded-2xl p-4">
                    <h3 class="font-bold text-gray-800 mb-3">Personal Details</h3>
                    <p><strong>First Name:</strong> <span id="modalFirstName"></span></p>
                    <p><strong>Middle Name:</strong> <span id="modalMiddleName"></span></p>
                    <p><strong>Last Name:</strong> <span id="modalLastName"></span></p>
                    <p><strong>Birthdate:</strong> <span id="modalBirthdate"></span></p>
                    <p><strong>Gender:</strong> <span id="modalGender"></span></p>
                    <p><strong>Civil Status:</strong> <span id="modalCivilStatus"></span></p>
                    <p><strong>Birthplace:</strong> <span id="modalBirthplace"></span></p>
                    <p><strong>Contact Number:</strong> <span id="modalContactNumber"></span></p>
                    <p><strong>Permanent Address:</strong> <span id="modalPermanentAddress"></span></p>
                    <p><strong>Present Address:</strong> <span id="modalPresentAddress"></span></p>
                </div>

                <div class="bg-gray-100 rounded-2xl p-4">
                    <h3 class="font-bold text-gray-800 mb-3">Family / Company Details</h3>
                    <p><strong>Father's Name:</strong> <span id="modalFatherName"></span></p>
                    <p><strong>Mother's Name:</strong> <span id="modalMotherName"></span></p>
                    <p><strong>Emergency Contact:</strong> <span id="modalEmergencyPerson"></span></p>
                    <p><strong>Emergency Number:</strong> <span id="modalEmergencyNumber"></span></p>
                    <p><strong>Education:</strong> <span id="modalEducation"></span></p>
                    <p><strong>Course:</strong> <span id="modalCourse"></span></p>
                    <p><strong>Department:</strong> <span id="modalDepartment"></span></p>
                    <p><strong>Position:</strong> <span id="modalPosition"></span></p>
                    <p><strong>Hire Date:</strong> <span id="modalHireDate"></span></p>
                    <p><strong>Status:</strong> <span id="modalEmploymentStatus"></span></p>
                    <p><strong>Assigned Area:</strong> <span id="modalAssignedArea"></span></p>
                </div>

                <div class="bg-gray-100 rounded-2xl p-4 md:col-span-2">
                    <h3 class="font-bold text-gray-800 mb-3">Change Employment Status</h3>
                    <select id="statusSelect" class="w-full rounded-2xl border border-gray-300 bg-white py-3 px-4 text-sm">
                        <option value="Terminated">Terminated</option>
                        <option value="Resigned">Resigned</option>
                    </select>
                </div>
            </div>

            <div class="px-6 py-4 border-t flex justify-end gap-3">
                <a id="modalEditBtn" href="#" class="px-5 py-3 rounded-2xl bg-blue-500 text-white hover:bg-blue-700 transition">
                    Edit
                </a>
                <a id="modalArchiveBtn" href="#" class="px-5 py-3 rounded-2xl bg-yellow-500 text-white hover:bg-yellow-600 transition">
                    Archive
                </a>
            </div>
        </div>
    </div>

    <script>
        function updateDateTime() {
            const now = new Date();
            document.getElementById('liveDateTime').textContent =
                now.toLocaleString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: 'numeric',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true
                });
        }

        updateDateTime();
        setInterval(updateDateTime, 1000);

        const searchInput = document.getElementById("searchInput");
        const searchHidden = document.getElementById("searchHidden");
        const pageHidden = document.getElementById("pageHidden");
        const filterForm = document.getElementById("filterForm");

        const rows = document.querySelectorAll(".employee-row");
        const modal = document.getElementById("employeeModal");
        const closeModalBtn = document.getElementById("closeModalBtn");
        const modalEditBtn = document.getElementById("modalEditBtn");
        const modalArchiveBtn = document.getElementById("modalArchiveBtn");
        const statusSelect = document.getElementById("statusSelect");

        let selectedEmployeeId = "";

        function syncSearchAndSubmit() {
            searchHidden.value = searchInput.value.trim();
            pageHidden.value = 1;
            filterForm.submit();
        }

        let searchTimer = null;
        searchInput.addEventListener("input", function () {
            searchHidden.value = searchInput.value.trim();
            pageHidden.value = 1;

            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                filterForm.submit();
            }, 500);
        });

        rows.forEach(row => {
            row.addEventListener("click", function(e) {
                if (e.target.closest("a")) return;

                const id = this.dataset.id || "";
                selectedEmployeeId = id;

                document.getElementById("modalFullName").textContent = this.dataset.fullname || "";
                document.getElementById("modalEmployeeId").textContent = this.dataset.employee_id || "";
                document.getElementById("modalFirstName").textContent = this.dataset.first_name || "";
                document.getElementById("modalMiddleName").textContent = this.dataset.middle_name || "";
                document.getElementById("modalLastName").textContent = this.dataset.last_name || "";
                document.getElementById("modalBirthdate").textContent = this.dataset.birthdate || "";
                document.getElementById("modalGender").textContent = this.dataset.gender || "";
                document.getElementById("modalCivilStatus").textContent = this.dataset.civil_status || "";
                document.getElementById("modalBirthplace").textContent = this.dataset.birthplace || "";
                document.getElementById("modalContactNumber").textContent = this.dataset.contact_number || "";
                document.getElementById("modalPermanentAddress").textContent = this.dataset.permanent_address || "";
                document.getElementById("modalPresentAddress").textContent = this.dataset.present_address || "";
                document.getElementById("modalFatherName").textContent = this.dataset.father_name || "";
                document.getElementById("modalMotherName").textContent = this.dataset.mother_name || "";
                document.getElementById("modalEmergencyPerson").textContent = this.dataset.emergency_person || "";
                document.getElementById("modalEmergencyNumber").textContent = this.dataset.emergency_number || "";
                document.getElementById("modalEducation").textContent = this.dataset.education || "";
                document.getElementById("modalCourse").textContent = this.dataset.course || "";
                document.getElementById("modalDepartment").textContent = this.dataset.department || "";
                document.getElementById("modalPosition").textContent = this.dataset.position || "";
                document.getElementById("modalHireDate").textContent = this.dataset.hire_date || "";
                document.getElementById("modalEmploymentStatus").textContent = this.dataset.employment_status || "";
                document.getElementById("modalAssignedArea").textContent = this.dataset.assigned_area || "";

                modalEditBtn.href = "editemployee.php?id=" + id;

                modal.classList.remove("hidden");
                modal.classList.add("flex");
            });
        });

        modalArchiveBtn.addEventListener("click", function(e) {
            e.preventDefault();

            if (!selectedEmployeeId) {
                alert("Invalid employee record.");
                return;
            }

            const selectedStatus = statusSelect.value;
            const confirmed = confirm("Are you sure you want to archive this employee as " + selectedStatus + "?");

            if (confirmed) {
                window.location.href = "archive_process.php?id=" + encodeURIComponent(selectedEmployeeId) + "&status=" + encodeURIComponent(selectedStatus);
            }
        });

        function closeModal() {
            modal.classList.add("hidden");
            modal.classList.remove("flex");
        }

        closeModalBtn.addEventListener("click", closeModal);

        modal.addEventListener("click", function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });

        document.addEventListener("keydown", function(e) {
            if (e.key === "Escape") {
                closeModal();
            }
        });
    </script>
</body>
</html>
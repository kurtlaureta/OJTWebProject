<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php";
require __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/
function safeValue($value)
{
    return isset($value) ? trim((string)$value) : "";
}

function formatDateYmd($value)
{
    if (empty($value) || $value === "0000-00-00") {
        return "";
    }

    $timestamp = strtotime($value);
    return $timestamp ? date("Y-m-d", $timestamp) : "";
}

function computeAge($birthdate)
{
    if (empty($birthdate) || $birthdate === "0000-00-00") {
        return "";
    }

    try {
        $birth = new DateTime($birthdate);
        $today = new DateTime();
        return $today->diff($birth)->y;
    } catch (Exception $e) {
        return "";
    }
}

function buildCompleteName($row)
{
    $first  = safeValue($row["first_name"] ?? "");
    $middle = safeValue($row["middle_name"] ?? "");
    $last   = safeValue($row["last_name"] ?? "");
    $suffix = safeValue($row["suffix"] ?? "");

    $parts = [];

    if ($last !== "") {
        $parts[] = $last . ",";
    }
    if ($first !== "") {
        $parts[] = $first;
    }
    if ($middle !== "") {
        $parts[] = $middle;
    }
    if ($suffix !== "") {
        $parts[] = $suffix;
    }

    return trim(implode(" ", $parts));
}

function isChecked($value)
{
    $value = strtolower(trim((string)$value));
    return in_array($value, ['1', 'true', 'on', 'yes', 'checked'], true);
}

function medicalText($value)
{
    return isChecked($value) ? "Fit to Work" : "None";
}

function idText($value)
{
    return isChecked($value) ? "Submitted" : "None";
}

function contractText($value)
{
    return isChecked($value) ? "Signed" : "None";
}

function cellRef($columnIndex, $row)
{
    return Coordinate::stringFromColumnIndex($columnIndex) . $row;
}

/*
|--------------------------------------------------------------------------
| CREATE SPREADSHEET
|--------------------------------------------------------------------------
*/
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Employee_Export');

/*
|--------------------------------------------------------------------------
| TEMPLATE HEADERS
|--------------------------------------------------------------------------
*/
$headers = [
    "EMPLOYEE NUMBER",
    "HRIS ID#",
    "STORE CODE",
    "Area",
    "First Name",
    "Middle Name",
    "Last Name",
    "Complete Name",
    "Suffix",
    "Birth Date",
    "Gender",
    "Civil Status",
    "Age",
    "Birth Place",
    "Contact Number",
    "Permanent Address",
    "Present Address",
    "Position",
    "Department",
    "Date Hired",
    "Regularization Date",
    "End of Employment",
    "Employment Status",
    "Salary Basis",
    "Rate",
    "Basic Salary",
    "KPI",
    "Accommodation (Transpo/Food)",
    "Father's Name",
    "Mother's Maiden Name",
    "Emergency Contact Person (1)",
    "Emergency Contact Number (1)",
    "Present Address (Alt.)",
    "Education Attainment",
    "Course of Study",
    "Personal Email",
    "Company Email",
    "Region",
    "TIN No.",
    "SSS No.",
    "PhilHealth No.",
    "PAG-IBIG No.",
    "Medical",
    "ID",
    "Contract"
];

$lastColumn = 'AS';

/*
|--------------------------------------------------------------------------
| TITLE / INSTRUCTION
|--------------------------------------------------------------------------
*/
$sheet->mergeCells("A1:{$lastColumn}1");
$sheet->setCellValue('A1', 'FASTOCK Employee Export');

$sheet->mergeCells("A2:{$lastColumn}2");
$sheet->setCellValue(
    'A2',
    'One employee per row. Keep header names unchanged. Dates are exported in YYYY-MM-DD format.'
);

$sheet->getStyle("A1:{$lastColumn}1")->applyFromArray([
    'font' => [
        'bold' => true,
        'size' => 14,
        'color' => ['rgb' => 'FFFFFF']
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['rgb' => '1F4E78']
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_LEFT,
        'vertical' => Alignment::VERTICAL_CENTER
    ]
]);

$sheet->getStyle("A2:{$lastColumn}2")->applyFromArray([
    'font' => [
        'italic' => true,
        'size' => 10,
        'color' => ['rgb' => '333333']
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['rgb' => 'D9EAF7']
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_LEFT,
        'vertical' => Alignment::VERTICAL_CENTER
    ]
]);

$sheet->getRowDimension(1)->setRowHeight(24);
$sheet->getRowDimension(2)->setRowHeight(22);
$sheet->getRowDimension(3)->setRowHeight(6);

/*
|--------------------------------------------------------------------------
| HEADER ROW
|--------------------------------------------------------------------------
*/
$colIndex = 1;
foreach ($headers as $header) {
    $sheet->setCellValue(cellRef($colIndex, 4), $header);
    $colIndex++;
}

$sheet->getStyle("A4:{$lastColumn}4")->applyFromArray([
    'font' => [
        'bold' => true,
        'size' => 10,
        'color' => ['rgb' => '000000']
    ],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['rgb' => 'D9D9D9']
    ],
    'alignment' => [
        'horizontal' => Alignment::HORIZONTAL_CENTER,
        'vertical' => Alignment::VERTICAL_CENTER,
        'wrapText' => true
    ],
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => 'A6A6A6']
        ]
    ]
]);

$sheet->getRowDimension(4)->setRowHeight(32);

/*
|--------------------------------------------------------------------------
| QUERY EMPLOYEES
|--------------------------------------------------------------------------
*/
$sql = "
    SELECT *
    FROM employees
    WHERE is_archived = 0
    ORDER BY CAST(SUBSTRING_INDEX(employee_id, '-', -1) AS UNSIGNED) ASC
";

$result = $conn->query($sql);
$rowNumber = 5;

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $employeeId          = safeValue($row["employee_id"] ?? "");
        $hrisId              = safeValue($row["hris_id"] ?? "");
        $storeCode           = safeValue($row["store_code"] ?? "");
        $area                = safeValue($row["assigned_area"] ?? "");
        $firstName           = safeValue($row["first_name"] ?? "");
        $middleName          = safeValue($row["middle_name"] ?? "");
        $lastName            = safeValue($row["last_name"] ?? "");
        $completeName        = buildCompleteName($row);
        $suffix              = safeValue($row["suffix"] ?? "");
        $birthDate           = formatDateYmd($row["birthdate"] ?? "");
        $gender              = safeValue($row["gender"] ?? "");
        $civilStatus         = safeValue($row["civil_status"] ?? "");
        $age                 = computeAge($row["birthdate"] ?? "");
        $birthPlace          = safeValue($row["birthplace"] ?? "");
        $contactNumber       = safeValue($row["contact_number"] ?? "");
        $permanentAddress    = safeValue($row["permanent_address"] ?? "");
        $presentAddress      = safeValue($row["present_address"] ?? "");
        $position            = safeValue($row["position"] ?? "");
        $department          = safeValue($row["department"] ?? "");
        $dateHired           = formatDateYmd($row["hire_date"] ?? "");
        $regularizationDate  = formatDateYmd($row["regularization_date"] ?? "");
        $endOfEmployment     = formatDateYmd($row["separation_date"] ?? ($row["end_of_employment"] ?? ""));
        $employmentStatus    = safeValue($row["employment_status"] ?? "");
        $salaryBasis         = safeValue($row["salary_basis"] ?? "");
        $rate                = safeValue($row["rate"] ?? "");
        $basicSalary         = safeValue($row["basic_salary"] ?? "");
        $kpi                 = safeValue($row["kpi"] ?? "");
        $accommodation       = safeValue($row["accommodation"] ?? "");
        $fatherName          = safeValue($row["father_name"] ?? "");
        $motherName          = safeValue($row["mother_name"] ?? "");
        $emergencyPerson     = safeValue($row["emergency_person"] ?? "");
        $emergencyNumber     = safeValue($row["emergency_number"] ?? "");
        $presentAddressAlt   = safeValue($row["present_address_alt"] ?? "");
        $education           = safeValue($row["education"] ?? "");
        $course              = safeValue($row["course"] ?? "");
        $personalEmail       = safeValue($row["personal_email"] ?? "");
        $companyEmail        = safeValue($row["company_email"] ?? "");
        $region              = safeValue($row["region"] ?? "");
        $tin                 = safeValue($row["tin_no"] ?? ($row["tin"] ?? ""));
        $sss                 = safeValue($row["sss_no"] ?? ($row["sss"] ?? ""));
        $philhealth          = safeValue($row["philhealth_no"] ?? ($row["philhealth"] ?? ""));
        $pagibig             = safeValue($row["pagibig_no"] ?? ($row["pagibig"] ?? ""));

        $medical             = medicalText($row["medical"] ?? "");
        $idDoc               = idText($row["id"] ?? ($row["id_status"] ?? ""));
        $contract            = contractText($row["contract"] ?? "");

        $data = [
            $employeeId,
            $hrisId,
            $storeCode,
            $area,
            $firstName,
            $middleName,
            $lastName,
            $completeName,
            $suffix,
            $birthDate,
            $gender,
            $civilStatus,
            $age,
            $birthPlace,
            $contactNumber,
            $permanentAddress,
            $presentAddress,
            $position,
            $department,
            $dateHired,
            $regularizationDate,
            $endOfEmployment,
            $employmentStatus,
            $salaryBasis,
            $rate,
            $basicSalary,
            $kpi,
            $accommodation,
            $fatherName,
            $motherName,
            $emergencyPerson,
            $emergencyNumber,
            $presentAddressAlt,
            $education,
            $course,
            $personalEmail,
            $companyEmail,
            $region,
            $tin,
            $sss,
            $philhealth,
            $pagibig,
            $medical,
            $idDoc,
            $contract
        ];

        $colIndex = 1;
        foreach ($data as $value) {
            $cell = cellRef($colIndex, $rowNumber);

            if (in_array($colIndex, [1, 2, 3, 15, 32, 39, 40, 41, 42], true)) {
                $sheet->setCellValueExplicit($cell, (string)$value, DataType::TYPE_STRING);
            } else {
                $sheet->setCellValue($cell, $value);
            }

            $colIndex++;
        }

        $rowNumber++;
    }
}

/*
|--------------------------------------------------------------------------
| BODY STYLE
|--------------------------------------------------------------------------
*/
$endDataRow = max(5, $rowNumber - 1);

$sheet->getStyle("A5:{$lastColumn}{$endDataRow}")->applyFromArray([
    'alignment' => [
        'vertical' => Alignment::VERTICAL_TOP,
        'wrapText' => true
    ],
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['rgb' => 'D9D9D9']
        ]
    ]
]);

for ($r = 5; $r <= $endDataRow; $r++) {
    if ($r % 2 === 0) {
        $sheet->getStyle("A{$r}:{$lastColumn}{$r}")
            ->getFill()
            ->setFillType(Fill::FILL_SOLID)
            ->getStartColor()
            ->setRGB('F8F9FA');
    }
}

/*
|--------------------------------------------------------------------------
| COLUMN WIDTHS
|--------------------------------------------------------------------------
*/
$widths = [
    'A' => 16, 'B' => 14, 'C' => 14, 'D' => 18, 'E' => 16, 'F' => 16, 'G' => 16,
    'H' => 24, 'I' => 10, 'J' => 14, 'K' => 12, 'L' => 14, 'M' => 8,  'N' => 18,
    'O' => 16, 'P' => 24, 'Q' => 24, 'R' => 20, 'S' => 18, 'T' => 14, 'U' => 18,
    'V' => 18, 'W' => 18, 'X' => 14, 'Y' => 12, 'Z' => 14, 'AA' => 10, 'AB' => 24,
    'AC' => 20, 'AD' => 22, 'AE' => 18, 'AF' => 24, 'AG' => 18, 'AH' => 18, 'AI' => 18,
    'AJ' => 18, 'AK' => 14, 'AL' => 16, 'AM' => 16, 'AN' => 16, 'AO' => 16, 'AP' => 14,
    'AQ' => 12, 'AR' => 12, 'AS' => 12
];

foreach ($widths as $col => $width) {
    $sheet->getColumnDimension($col)->setWidth($width);
}

/*
|--------------------------------------------------------------------------
| FREEZE / FILTER
|--------------------------------------------------------------------------
*/
$sheet->freezePane('A5');
$sheet->setAutoFilter("A4:{$lastColumn}4");
$sheet->getSheetView()->setZoomScale(85);
$sheet->getDefaultRowDimension()->setRowHeight(20);

/*
|--------------------------------------------------------------------------
| OUTPUT
|--------------------------------------------------------------------------
*/
$filename = "fastock_employee_export_template_format.xlsx";

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');
header('Expires: 0');
header('Pragma: public');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
?>
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";
date_default_timezone_set('Asia/Manila');

header('Content-Type: application/json');

if (!isset($_SESSION["user_id"])) {
    echo json_encode([
        "success" => false,
        "message" => "Not logged in"
    ]);
    exit;
}

$user_id = (int) $_SESSION["user_id"];

$conn->query("SET time_zone = '+08:00'");

$stmt = $conn->prepare("UPDATE users SET status = 'online', last_activity = NOW() WHERE id = ?");
$stmt->bind_param("i", $user_id);
$ok = $stmt->execute();

echo json_encode([
    "success" => $ok ? true : false
]);
?>
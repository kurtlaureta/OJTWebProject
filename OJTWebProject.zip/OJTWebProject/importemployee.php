<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php";
require __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;

$message = "";
$successCount = 0;
$errorRows = [];

/* =========================
   HELPERS
========================= */
function cleanValue($value)
{
    return trim((string)($value ?? ""));
}

function normalizeSpaces($value)
{
    $value = cleanValue($value);
    return preg_replace('/\s+/', ' ', $value);
}

function normalizeDateValue($value)
{
    if ($value === null || $value === "") {
        return "";
    }

    if (is_numeric($value)) {
        try {
            return ExcelDate::excelToDateTimeObject($value)->format('Y-m-d');
        } catch (Exception $e) {
            return "";
        }
    }

    $value = trim((string)$value);
    if ($value === "") {
        return "";
    }

    $formats = ['Y-m-d', 'm/d/Y', 'n/j/Y', 'm-d-Y', 'n-j-Y', 'Y/m/d'];

    foreach ($formats as $format) {
        $dt = DateTime::createFromFormat($format, $value);
        if ($dt && $dt->format($format) === $value) {
            return $dt->format('Y-m-d');
        }
    }

    $timestamp = strtotime($value);
    if ($timestamp !== false) {
        return date('Y-m-d', $timestamp);
    }

    return "";
}

function normalizeCheckboxValue($value)
{
    $value = strtolower(trim((string)$value));

    $truthy = [
        "1", "yes", "y", "true", "checked",
        "submitted", "complete", "completed", "meron",
        "fit to work", "signed"
    ];

    return in_array($value, $truthy, true) ? 1 : 0;
}

function isValidName($value)
{
    return preg_match("/^[a-zA-Z\s.'-]+$/", $value);
}

function normalizeDecimal($value)
{
    $value = cleanValue($value);

    if ($value === "") {
        return "";
    }

    $value = str_replace(["₱", ",", " "], "", $value);

    return $value;
}

function isValidDecimalImport($value)
{
    return preg_match('/^\d+(\.\d+)?$/', $value);
}

function isValidEmailImport($value)
{
    return filter_var($value, FILTER_VALIDATE_EMAIL);
}

function normalizePhone($value)
{
    return preg_replace('/\D+/', '', (string)$value);
}

function normalizeGender($value)
{
    $value = strtolower(normalizeSpaces($value));

    $map = [
        'male' => 'Male',
        'm' => 'Male',
        'female' => 'Female',
        'f' => 'Female',
    ];

    return $map[$value] ?? cleanValue($value);
}

function normalizeCivilStatus($value)
{
    $value = strtolower(normalizeSpaces($value));

    $map = [
        'single' => 'Single',
        'married' => 'Married',
        'widowed' => 'Widowed',
        'widow' => 'Widowed',
    ];

    return $map[$value] ?? cleanValue($value);
}

function normalizeEmploymentStatus($value)
{
    $value = strtolower(normalizeSpaces($value));

    $map = [
        'active' => 'Active',
        'probationary' => 'Probationary',
        'regular' => 'Regular',
        'resigned' => 'Resigned',
        'terminated' => 'Terminated',
    ];

    return $map[$value] ?? cleanValue($value);
}

function normalizeSalaryBasis($value)
{
    $value = strtolower(normalizeSpaces($value));

    $map = [
        'daily' => 'Daily',
        'weekly' => 'Weekly',
        'semi-monthly' => 'Semi-Monthly',
        'semimonthly' => 'Semi-Monthly',
        'semi monthly' => 'Semi-Monthly',
        'monthly' => 'Monthly',
    ];

    return $map[$value] ?? cleanValue($value);
}

function normalizeEducation($value)
{
    return normalizeSpaces($value);
}

function cleanGovNumber($value)
{
    $value = cleanValue($value);
    if ($value === "") {
        return "";
    }

    return preg_replace('/\D+/', '', $value);
}

function govIdExists($conn, $column, $value)
{
    if ($value === "") {
        return false;
    }

    $allowedColumns = ['tin_no', 'sss_no', 'philhealth_no', 'pagibig_no'];
    if (!in_array($column, $allowedColumns, true)) {
        return false;
    }

    $sql = "
        SELECT id
        FROM employees
        WHERE REPLACE(REPLACE(REPLACE(REPLACE($column, '-', ''), ' ', ''), '.', ''), '/', '') = ?
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return false;
    }

    $stmt->bind_param("s", $value);
    $stmt->execute();
    $result = $stmt->get_result();
    $exists = $result && $result->num_rows > 0;
    $stmt->close();

    return $exists;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_FILES["excel_file"]) || $_FILES["excel_file"]["error"] !== UPLOAD_ERR_OK) {
        $message = "Please upload a valid Excel file.";
    } else {
        $fileTmpPath = $_FILES["excel_file"]["tmp_name"];
        $fileName = $_FILES["excel_file"]["name"];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if ($fileExt !== "xlsx") {
            $message = "Only .xlsx files are allowed.";
        } else {
            try {
                $spreadsheet = IOFactory::load($fileTmpPath);
                $sheet = $spreadsheet->getActiveSheet();
                $rows = $sheet->toArray(null, true, true, true);

                $seenEmployeeIds = [];
                $seenCompanyEmails = [];
                $seenTinNos = [];
                $seenSssNos = [];
                $seenPhilhealthNos = [];
                $seenPagibigNos = [];

                /*
                TEMPLATE FORMAT
                Row 1 = Title
                Row 2 = Instruction
                Row 3 = Blank
                Row 4 = Headers
                Row 5+ = Data

                A  = Employee Number
                B  = HRIS ID#
                C  = Store Code
                D  = Area
                E  = First Name
                F  = Middle Name
                G  = Last Name
                H  = Complete Name
                I  = Suffix
                J  = Birth Date
                K  = Gender
                L  = Civil Status
                M  = Age
                N  = Birth Place
                O  = Contact Number
                P  = Permanent Address
                Q  = Present Address
                R  = Position
                S  = Department
                T  = Date Hired
                U  = Regularization Date
                V  = End of Employment
                W  = Employment Status
                X  = Salary Basis
                Y  = Rate
                Z  = Basic Salary
                AA = KPI
                AB = Accommodation (Transpo/Food)
                AC = Father's Name
                AD = Mother's Maiden Name
                AE = Emergency Contact Person (1)
                AF = Emergency Contact Number (1)
                AG = Present Address (Alt.)
                AH = Education Attainment
                AI = Course of Study
                AJ = Personal Email
                AK = Company Email
                AL = Region
                AM = TIN No.
                AN = SSS No.
                AO = PhilHealth No.
                AP = PAG-IBIG No.
                AQ = Medical
                AR = ID
                AS = Contract
                */

                for ($rowIndex = 5; $rowIndex <= count($rows); $rowIndex++) {
                    $row = $rows[$rowIndex] ?? [];

                    $employee_id         = cleanValue($row['A'] ?? '');
                    $hris_id             = cleanValue($row['B'] ?? '');
                    $store_code          = cleanValue($row['C'] ?? '');
                    $assigned_area       = cleanValue($row['D'] ?? '');
                    $first_name          = cleanValue($row['E'] ?? '');
                    $middle_name         = cleanValue($row['F'] ?? '');
                    $last_name           = cleanValue($row['G'] ?? '');
                    $complete_name       = cleanValue($row['H'] ?? '');
                    $suffix              = cleanValue($row['I'] ?? '');
                    $birthdate           = normalizeDateValue($row['J'] ?? '');
                    $gender              = normalizeGender($row['K'] ?? '');
                    $civil_status        = normalizeCivilStatus($row['L'] ?? '');
                    $birthplace          = cleanValue($row['N'] ?? '');
                    $contact_number      = normalizePhone($row['O'] ?? '');
                    $permanent_address   = cleanValue($row['P'] ?? '');
                    $present_address     = cleanValue($row['Q'] ?? '');
                    $position            = cleanValue($row['R'] ?? '');
                    $department          = cleanValue($row['S'] ?? '');
                    $hire_date           = normalizeDateValue($row['T'] ?? '');
                    $regularization_date = normalizeDateValue($row['U'] ?? '');
                    $end_of_employment   = normalizeDateValue($row['V'] ?? '');
                    $employment_status   = normalizeEmploymentStatus($row['W'] ?? '');
                    $salary_basis        = normalizeSalaryBasis($row['X'] ?? '');
                    $rate                = normalizeDecimal($row['Y'] ?? '');
                    $basic_salary        = normalizeDecimal($row['Z'] ?? '');
                    $kpi                 = normalizeDecimal($row['AA'] ?? '');
                    $accommodation       = cleanValue($row['AB'] ?? '');
                    $father_name         = cleanValue($row['AC'] ?? '');
                    $mother_name         = cleanValue($row['AD'] ?? '');
                    $emergency_person    = cleanValue($row['AE'] ?? '');
                    $emergency_number    = normalizePhone($row['AF'] ?? '');
                    $present_address_alt = cleanValue($row['AG'] ?? '');
                    $education           = normalizeEducation($row['AH'] ?? '');
                    $course              = cleanValue($row['AI'] ?? '');
                    $personal_email      = cleanValue($row['AJ'] ?? '');
                    $company_email       = cleanValue($row['AK'] ?? '');
                    $region              = cleanValue($row['AL'] ?? '');
                    $tin_no              = cleanGovNumber($row['AM'] ?? '');
                    $sss_no              = cleanGovNumber($row['AN'] ?? '');
                    $philhealth_no       = cleanGovNumber($row['AO'] ?? '');
                    $pagibig_no          = cleanGovNumber($row['AP'] ?? '');
                    $medical             = normalizeCheckboxValue($row['AQ'] ?? '');
                    $id_file             = normalizeCheckboxValue($row['AR'] ?? '');
                    $contract            = normalizeCheckboxValue($row['AS'] ?? '');

                    $isCompletelyEmpty =
                        $employee_id === "" &&
                        $hris_id === "" &&
                        $store_code === "" &&
                        $assigned_area === "" &&
                        $first_name === "" &&
                        $middle_name === "" &&
                        $last_name === "" &&
                        $complete_name === "" &&
                        $suffix === "" &&
                        $birthdate === "" &&
                        $gender === "" &&
                        $civil_status === "" &&
                        $birthplace === "" &&
                        $contact_number === "" &&
                        $permanent_address === "" &&
                        $present_address === "" &&
                        $position === "" &&
                        $department === "" &&
                        $hire_date === "" &&
                        $regularization_date === "" &&
                        $end_of_employment === "" &&
                        $employment_status === "" &&
                        $salary_basis === "" &&
                        $rate === "" &&
                        $basic_salary === "" &&
                        $kpi === "" &&
                        $accommodation === "" &&
                        $father_name === "" &&
                        $mother_name === "" &&
                        $emergency_person === "" &&
                        $emergency_number === "" &&
                        $present_address_alt === "" &&
                        $education === "" &&
                        $course === "" &&
                        $personal_email === "" &&
                        $company_email === "" &&
                        $region === "" &&
                        $tin_no === "" &&
                        $sss_no === "" &&
                        $philhealth_no === "" &&
                        $pagibig_no === "" &&
                        (int)$medical === 0 &&
                        (int)$id_file === 0 &&
                        (int)$contract === 0;

                    if ($isCompletelyEmpty) {
                        continue;
                    }

                    $rowErrors = [];

                    /* REQUIRED */
                    if ($employee_id === "") $rowErrors[] = "Employee Number is required";
                    if ($first_name === "") $rowErrors[] = "First Name is required";
                    if ($last_name === "") $rowErrors[] = "Last Name is required";
                    if ($contact_number === "") $rowErrors[] = "Contact Number is required";
                    if ($birthdate === "") $rowErrors[] = "Birth Date is required";
                    if ($gender === "") $rowErrors[] = "Gender is required";
                    if ($civil_status === "") $rowErrors[] = "Civil Status is required";
                    if ($hire_date === "") $rowErrors[] = "Date Hired is required";
                    if ($employment_status === "") $rowErrors[] = "Employment Status is required";

                    /* AUTO COMPLETE NAME */
                    if ($complete_name === "") {
                        $complete_name = trim(
                            $first_name .
                            ($middle_name !== "" ? " " . $middle_name : "") .
                            " " . $last_name .
                            ($suffix !== "" ? " " . $suffix : "")
                        );
                    }

                    /* VALIDATIONS */
                    if ($first_name !== "" && !isValidName($first_name)) $rowErrors[] = "Invalid First Name";
                    if ($middle_name !== "" && !isValidName($middle_name)) $rowErrors[] = "Invalid Middle Name";
                    if ($last_name !== "" && !isValidName($last_name)) $rowErrors[] = "Invalid Last Name";
                    if ($father_name !== "" && !isValidName($father_name)) $rowErrors[] = "Invalid Father's Name";
                    if ($mother_name !== "" && !isValidName($mother_name)) $rowErrors[] = "Invalid Mother's Maiden Name";
                    if ($emergency_person !== "" && !isValidName($emergency_person)) $rowErrors[] = "Invalid Emergency Contact Person";

                    if ($employee_id !== "" && !preg_match('/^[A-Za-z0-9_-]+$/', $employee_id)) {
                        $rowErrors[] = "Employee Number must only contain letters, numbers, dash, or underscore";
                    }

                    if ($hris_id !== "" && !preg_match('/^[A-Za-z0-9_-]+$/', $hris_id)) {
                        $rowErrors[] = "HRIS ID must only contain letters, numbers, dash, or underscore";
                    }

                    if ($contact_number !== "" && !preg_match('/^09\d{9}$/', $contact_number)) {
                        $rowErrors[] = "Contact Number must be 11 digits and start with 09";
                    }

                    if ($emergency_number !== "" && !preg_match('/^09\d{9}$/', $emergency_number)) {
                        $rowErrors[] = "Emergency Contact Number must be 11 digits and start with 09";
                    }

                    $valid_genders = ["Male", "Female"];
                    $valid_civil_status = ["Single", "Married", "Widowed"];
                    $valid_employment_status = ["Probationary", "Regular", "Resigned", "Terminated", "Active"];
                    $valid_salary_basis = ["Daily", "Weekly", "Semi-Monthly", "Monthly"];

                    if ($gender !== "" && !in_array($gender, $valid_genders, true)) {
                        $rowErrors[] = "Invalid Gender";
                    }

                    if ($civil_status !== "" && !in_array($civil_status, $valid_civil_status, true)) {
                        $rowErrors[] = "Invalid Civil Status";
                    }

                    if ($employment_status !== "" && !in_array($employment_status, $valid_employment_status, true)) {
                        $rowErrors[] = "Invalid Employment Status";
                    }

                    if ($salary_basis !== "" && !in_array($salary_basis, $valid_salary_basis, true)) {
                        $rowErrors[] = "Invalid Salary Basis";
                    }

                    if ($rate !== "" && !isValidDecimalImport($rate)) $rowErrors[] = "Invalid Rate";
                    if ($basic_salary !== "" && !isValidDecimalImport($basic_salary)) $rowErrors[] = "Invalid Basic Salary";
                    if ($kpi !== "" && !isValidDecimalImport($kpi)) $rowErrors[] = "Invalid KPI";

                    if ($personal_email !== "" && !isValidEmailImport($personal_email)) {
                        $rowErrors[] = "Invalid Personal Email";
                    }

                    if ($company_email !== "" && !isValidEmailImport($company_email)) {
                        $rowErrors[] = "Invalid Company Email";
                    }

                    /* GOVERNMENT ID LENGTH VALIDATION */
                    if ($tin_no !== "" && !in_array(strlen($tin_no), [9, 12], true)) {
                        $rowErrors[] = "TIN No. must be exactly 9 or 12 digits";
                    }

                    if ($sss_no !== "" && strlen($sss_no) !== 10) {
                        $rowErrors[] = "SSS No. must be exactly 10 digits";
                    }

                    if ($philhealth_no !== "" && strlen($philhealth_no) !== 12) {
                        $rowErrors[] = "PhilHealth No. must be exactly 12 digits";
                    }

                    if ($pagibig_no !== "" && strlen($pagibig_no) !== 12) {
                        $rowErrors[] = "PAG-IBIG No. must be exactly 12 digits";
                    }

                    /* DATE LOGIC */
                    $today = date("Y-m-d");

                    if ($birthdate !== "" && $birthdate > $today) {
                        $rowErrors[] = "Birth Date cannot be in the future";
                    }

                    if ($hire_date !== "" && $hire_date > $today) {
                        $rowErrors[] = "Date Hired cannot be in the future";
                    }

                    if ($birthdate !== "" && $hire_date !== "") {
                        if (strtotime($hire_date) < strtotime($birthdate)) {
                            $rowErrors[] = "Date Hired cannot be earlier than Birth Date";
                        } else {
                            $age_at_hire = date_diff(date_create($birthdate), date_create($hire_date))->y;
                            if ($age_at_hire < 18) {
                                $rowErrors[] = "Employee must be at least 18 years old at hire date";
                            }
                        }
                    }

                    if ($regularization_date !== "" && $hire_date !== "" && strtotime($regularization_date) < strtotime($hire_date)) {
                        $rowErrors[] = "Regularization Date cannot be earlier than Date Hired";
                    }

                    if ($end_of_employment !== "" && $hire_date !== "" && strtotime($end_of_employment) < strtotime($hire_date)) {
                        $rowErrors[] = "End of Employment cannot be earlier than Date Hired";
                    }

                    if (in_array($employment_status, ["Resigned", "Terminated"], true) && $end_of_employment === "") {
                        $rowErrors[] = "End of Employment is required for Resigned or Terminated status";
                    }

                    if (in_array($employment_status, ["Active", "Probationary", "Regular"], true) && $end_of_employment !== "") {
                        $rowErrors[] = "End of Employment should be blank for active employees";
                    }

                    /* DUPLICATE CHECKS - DATABASE */
                    if ($employee_id !== "") {
                        $checkStmt = $conn->prepare("SELECT id FROM employees WHERE employee_id = ? LIMIT 1");
                        if ($checkStmt) {
                            $checkStmt->bind_param("s", $employee_id);
                            $checkStmt->execute();
                            $checkResult = $checkStmt->get_result();

                            if ($checkResult && $checkResult->num_rows > 0) {
                                $rowErrors[] = "Employee Number '{$employee_id}' already exists";
                            }
                            $checkStmt->close();
                        }
                    }

                    if ($company_email !== "") {
                        $checkEmailStmt = $conn->prepare("SELECT id FROM employees WHERE company_email = ? LIMIT 1");
                        if ($checkEmailStmt) {
                            $checkEmailStmt->bind_param("s", $company_email);
                            $checkEmailStmt->execute();
                            $checkEmailResult = $checkEmailStmt->get_result();

                            if ($checkEmailResult && $checkEmailResult->num_rows > 0) {
                                $rowErrors[] = "Company Email '{$company_email}' already exists";
                            }
                            $checkEmailStmt->close();
                        }
                    }

                    if ($tin_no !== "" && govIdExists($conn, 'tin_no', $tin_no)) {
                        $rowErrors[] = "TIN No. '{$tin_no}' already exists";
                    }

                    if ($sss_no !== "" && govIdExists($conn, 'sss_no', $sss_no)) {
                        $rowErrors[] = "SSS No. '{$sss_no}' already exists";
                    }

                    if ($philhealth_no !== "" && govIdExists($conn, 'philhealth_no', $philhealth_no)) {
                        $rowErrors[] = "PhilHealth No. '{$philhealth_no}' already exists";
                    }

                    if ($pagibig_no !== "" && govIdExists($conn, 'pagibig_no', $pagibig_no)) {
                        $rowErrors[] = "PAG-IBIG No. '{$pagibig_no}' already exists";
                    }

                    /* DUPLICATE CHECKS - SAME FILE */
                    $employeeIdKey = strtolower($employee_id);
                    $companyEmailKey = strtolower($company_email);

                    if ($employee_id !== "") {
                        if (isset($seenEmployeeIds[$employeeIdKey])) {
                            $rowErrors[] = "Employee Number '{$employee_id}' is duplicated in the file";
                        } else {
                            $seenEmployeeIds[$employeeIdKey] = true;
                        }
                    }

                    if ($company_email !== "") {
                        if (isset($seenCompanyEmails[$companyEmailKey])) {
                            $rowErrors[] = "Company Email '{$company_email}' is duplicated in the file";
                        } else {
                            $seenCompanyEmails[$companyEmailKey] = true;
                        }
                    }

                    if ($tin_no !== "") {
                        if (isset($seenTinNos[$tin_no])) {
                            $rowErrors[] = "TIN No. '{$tin_no}' is duplicated in the file";
                        } else {
                            $seenTinNos[$tin_no] = true;
                        }
                    }

                    if ($sss_no !== "") {
                        if (isset($seenSssNos[$sss_no])) {
                            $rowErrors[] = "SSS No. '{$sss_no}' is duplicated in the file";
                        } else {
                            $seenSssNos[$sss_no] = true;
                        }
                    }

                    if ($philhealth_no !== "") {
                        if (isset($seenPhilhealthNos[$philhealth_no])) {
                            $rowErrors[] = "PhilHealth No. '{$philhealth_no}' is duplicated in the file";
                        } else {
                            $seenPhilhealthNos[$philhealth_no] = true;
                        }
                    }

                    if ($pagibig_no !== "") {
                        if (isset($seenPagibigNos[$pagibig_no])) {
                            $rowErrors[] = "PAG-IBIG No. '{$pagibig_no}' is duplicated in the file";
                        } else {
                            $seenPagibigNos[$pagibig_no] = true;
                        }
                    }

                    if (!empty($rowErrors)) {
                        $errorRows[] = "Row {$rowIndex}: " . implode("; ", $rowErrors) . ".";
                        continue;
                    }

                    $stmt = $conn->prepare("INSERT INTO employees (
                        employee_id,
                        hris_id,
                        store_code,
                        assigned_area,
                        first_name,
                        middle_name,
                        last_name,
                        complete_name,
                        suffix,
                        birthdate,
                        gender,
                        civil_status,
                        birthplace,
                        contact_number,
                        permanent_address,
                        present_address,
                        present_address_alt,
                        position,
                        department,
                        hire_date,
                        regularization_date,
                        end_of_employment,
                        employment_status,
                        salary_basis,
                        rate,
                        basic_salary,
                        kpi,
                        accommodation,
                        father_name,
                        mother_name,
                        emergency_person,
                        emergency_number,
                        education,
                        course,
                        personal_email,
                        company_email,
                        region,
                        tin_no,
                        sss_no,
                        philhealth_no,
                        pagibig_no,
                        medical,
                        id_file,
                        contract,
                        is_archived
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)");

                    if (!$stmt) {
                        $errorRows[] = "Row {$rowIndex}: failed to prepare insert statement.";
                        continue;
                    }

                    $stmt->bind_param(
                        "ssssssssssssssssssssssssssssssssssssssssssss",
                        $employee_id,
                        $hris_id,
                        $store_code,
                        $assigned_area,
                        $first_name,
                        $middle_name,
                        $last_name,
                        $complete_name,
                        $suffix,
                        $birthdate,
                        $gender,
                        $civil_status,
                        $birthplace,
                        $contact_number,
                        $permanent_address,
                        $present_address,
                        $present_address_alt,
                        $position,
                        $department,
                        $hire_date,
                        $regularization_date,
                        $end_of_employment,
                        $employment_status,
                        $salary_basis,
                        $rate,
                        $basic_salary,
                        $kpi,
                        $accommodation,
                        $father_name,
                        $mother_name,
                        $emergency_person,
                        $emergency_number,
                        $education,
                        $course,
                        $personal_email,
                        $company_email,
                        $region,
                        $tin_no,
                        $sss_no,
                        $philhealth_no,
                        $pagibig_no,
                        $medical,
                        $id_file,
                        $contract
                    );

                    if ($stmt->execute()) {
                        $successCount++;
                    } else {
                        $errorRows[] = "Row {$rowIndex}: failed to insert. " . $stmt->error;
                    }

                    $stmt->close();
                }

                if ($successCount > 0) {
                    $message = "{$successCount} employee(s) imported successfully.";
                } elseif (empty($errorRows)) {
                    $message = "No rows were imported.";
                } else {
                    $message = "Import finished with errors.";
                }

            } catch (Exception $e) {
                $message = "Import failed: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <title>Import Employees</title>
</head>
<body class="flex bg-gray-100">
    <?php include 'navbar.php'; ?>

    <section class="flex-1 min-h-screen p-8">
        <div class="max-w-5xl mx-auto bg-white rounded-3xl shadow p-8">
            <h1 class="text-2xl font-bold mb-2">Import Employees</h1>
            <p class="text-gray-600 mb-6">
                Upload the Excel template file and import employee data into the system.
            </p>

            <div class="flex gap-3 mb-6 flex-wrap">
                <a href="fastock_employee_import_export_template.xlsx" download class="inline-block bg-blue-500 text-white px-5 py-3 rounded-2xl hover:bg-blue-700 transition">
                    Download Template
                </a>
                <a href="employee.php" class="inline-block bg-gray-500 text-white px-5 py-3 rounded-2xl hover:bg-gray-700 transition">
                    Back to Employee List
                </a>
            </div>

            <?php if ($message !== ""): ?>
                <div class="mb-6 rounded-2xl border border-gray-200 bg-white shadow-sm p-5">
                    <h2 class="text-lg font-bold text-gray-800 mb-2">Import Summary</h2>
                    <p class="text-gray-700 mb-3"><?php echo htmlspecialchars($message); ?></p>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div class="rounded-2xl bg-green-100 text-green-800 px-4 py-3">
                            <p class="text-sm">Successfully Imported</p>
                            <p class="text-2xl font-bold"><?php echo (int)$successCount; ?></p>
                        </div>

                        <div class="rounded-2xl bg-red-100 text-red-800 px-4 py-3">
                            <p class="text-sm">Failed Rows</p>
                            <p class="text-2xl font-bold"><?php echo count($errorRows); ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($errorRows)): ?>
                <div class="mb-6 rounded-2xl px-4 py-3 bg-red-100 text-red-800">
                    <h2 class="font-bold mb-2">Import Errors</h2>
                    <ul class="list-disc pl-5 space-y-1 max-h-80 overflow-y-auto">
                        <?php foreach ($errorRows as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="" method="POST" enctype="multipart/form-data" class="space-y-4">
                <div>
                    <label class="block mb-2 font-medium">Select Excel File (.xlsx)</label>
                    <input type="file" name="excel_file" accept=".xlsx" class="block w-full border border-gray-300 p-3 rounded-2xl bg-white">
                </div>

                <button type="submit" class="bg-green-500 text-white px-6 py-3 rounded-2xl hover:bg-green-700 transition">
                    Import File
                </button>
            </form>

            <div class="mt-8 bg-gray-50 rounded-2xl p-5 border">
                <h2 class="font-bold mb-2">Important</h2>
                <p class="text-sm text-gray-700 mb-2">Your import file should follow this format:</p>
                <ul class="text-sm text-gray-700 list-disc pl-5 space-y-1">
                    <li>Row 1 = Title</li>
                    <li>Row 2 = Instruction</li>
                    <li>Row 3 = Blank</li>
                    <li>Row 4 = Headers</li>
                    <li>Row 5 and below = Employee data</li>
                </ul>

                <div class="mt-4 text-sm text-gray-700">
                    <p class="font-semibold mb-1">Notes:</p>
                    <ul class="list-disc pl-5 space-y-1">
                        <li><strong>Medical</strong>, <strong>ID</strong>, and <strong>Contract</strong> accept values like <strong>1</strong>, <strong>Yes</strong>, <strong>Checked</strong>, <strong>Fit to Work</strong>, <strong>Submitted</strong>, or <strong>Signed</strong>.</li>
                        <li>Date columns are automatically converted to <strong>YYYY-MM-DD</strong>.</li>
                        <li>Contact numbers must be Philippine mobile format like <strong>09123456789</strong>.</li>
                        <li>Employee must be at least <strong>18 years old</strong> at hire date.</li>
                        <li><strong>Education Attainment</strong> and <strong>Accommodation</strong> can be free text.</li>
                        <li><strong>Rate</strong>, <strong>Basic Salary</strong>, and <strong>KPI</strong> accept decimal values.</li>
                        <li><strong>TIN</strong> must be <strong>9 or 12 digits</strong>.</li>
                        <li><strong>SSS</strong> must be <strong>10 digits</strong>.</li>
                        <li><strong>PhilHealth</strong> must be <strong>12 digits</strong>.</li>
                        <li><strong>PAG-IBIG</strong> must be <strong>12 digits</strong>.</li>
                        <li>Government IDs are checked for duplicates both in the <strong>database</strong> and within the <strong>uploaded file</strong>.</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
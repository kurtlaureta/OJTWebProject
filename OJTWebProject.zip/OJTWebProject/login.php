<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";
date_default_timezone_set('Asia/Manila');

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

if (isset($conn)) {
    $conn->query("SET time_zone = '+08:00'");
}

/* =========================
   IF ALREADY LOGGED IN
========================= */
if (isset($_SESSION['user_id'], $_SESSION['session_token'])) {
    $checkStmt = $conn->prepare("SELECT role, session_token FROM users WHERE id = ? LIMIT 1");
    if ($checkStmt) {
        $checkStmt->bind_param("i", $_SESSION["user_id"]);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();

        if ($checkResult && $checkResult->num_rows === 1) {
            $currentUser = $checkResult->fetch_assoc();

            if (
                !empty($currentUser["session_token"]) &&
                hash_equals($currentUser["session_token"], $_SESSION["session_token"])
            ) {
                $role = strtolower(trim($currentUser["role"] ?? "user"));

                if ($role === "admin") {
                    header("Location: home.php");
                } else {
                    header("Location: user_home.php");
                }
                exit;
            } else {
                session_unset();
                session_destroy();
                session_start();
            }
        } else {
            session_unset();
            session_destroy();
            session_start();
        }

        $checkStmt->close();
    }
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"] ?? "");
    $password = trim($_POST["password"] ?? "");

    if ($username === "" || $password === "") {
        $error = "Please enter username and password.";
    } else {
        $stmt = $conn->prepare("SELECT id, username, password, role, status FROM users WHERE username = ? LIMIT 1");
        if (!$stmt) {
            $error = "Failed to prepare login query.";
        } else {
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows === 1) {
                $user = $result->fetch_assoc();

                $storedPassword = $user["password"];
                $isValidPassword = false;

                // Support both hashed passwords and old plain text passwords
                if (password_verify($password, $storedPassword)) {
                    $isValidPassword = true;
                } elseif ($password === $storedPassword) {
                    $isValidPassword = true;

                    // Auto-upgrade old plain text password to hashed
                    $newHashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    $upgradeStmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    if ($upgradeStmt) {
                        $upgradeStmt->bind_param("si", $newHashedPassword, $user["id"]);
                        $upgradeStmt->execute();
                        $upgradeStmt->close();
                    }
                }

                if ($isValidPassword) {
                    session_regenerate_id(true);

                    $role = strtolower(trim($user["role"] ?? "user"));
                    $sessionToken = bin2hex(random_bytes(32));

                    $_SESSION["user_id"] = (int)$user["id"];
                    $_SESSION["username"] = $user["username"];
                    $_SESSION["role"] = $role;
                    $_SESSION["session_token"] = $sessionToken;

                    $updateStmt = $conn->prepare("
                        UPDATE users 
                        SET status = 'online',
                            last_activity = NOW(),
                            session_token = ?
                        WHERE id = ?
                    ");

                    if ($updateStmt) {
                        $updateStmt->bind_param("si", $sessionToken, $user["id"]);
                        $updateStmt->execute();
                        $updateStmt->close();
                    }

                    if ($role === "admin") {
                        header("Location: home.php");
                    } else {
                        header("Location: user_home.php");
                    }
                    exit;
                } else {
                    $error = "Invalid password.";
                }
            } else {
                $error = "Username not found.";
            }

            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../index.css">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100..900&display=swap" rel="stylesheet">
    <title>Login</title>

    <style type="text/tailwindcss">
        @theme {
            --font-roboto: "Roboto", sans-serif;
        }

        @layer base {
            body {
                @apply font-roboto;
            }
        }
    </style>
</head>
<body>
    <div class="min-h-screen bg-gray-400 text-black flex flex-col-reverse justify-center items-center sm:flex-col-reverse md:flex-row">
        <!-- left card -->
        <section class="bg-gradient-to-br from-gray-900 to-gray-800 text-white w-[400px] h-120 max-sm:rounded-b-2xl md:rounded-l-2xl">
            <div class="flex flex-col items-center">
                <div class="font-bold flex text-2xl flex-row-reverse justify-end text-white mt-5">
                    FASTOCK
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-8 mr-1 text-green-500">
                        <path fill-rule="evenodd" d="M4.5 3.75a3 3 0 0 0-3 3v10.5a3 3 0 0 0 3 3h15a3 3 0 0 0 3-3V6.75a3 3 0 0 0-3-3h-15Zm4.125 3a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Zm-3.873 8.703a4.126 4.126 0 0 1 7.746 0 .75.75 0 0 1-.351.92 7.47 7.47 0 0 1-3.522.877 7.47 7.47 0 0 1-3.522-.877.75.75 0 0 1-.351-.92ZM15 8.25a.75.75 0 0 0 0 1.5h3.75a.75.75 0 0 0 0-1.5H15ZM14.25 12a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H15a.75.75 0 0 1-.75-.75Zm.75 2.25a.75.75 0 0 0 0 1.5h3.75a.75.75 0 0 0 0-1.5H15Z" clip-rule="evenodd" />
                    </svg>
                </div>

                <h2 class="text-[12px] font-light text-gray-300">EMPLOYEE MASTERLIST</h2>

                <p class="text-4xl text-center font-bold mt-8">
                    Manage and track
                    <span class="bg-clip-text text-transparent bg-gradient-to-r from-green-500 to-green-300">
                        Employees
                    </span>
                    in your organization.
                </p>

                <p class="text-sm text-gray-200 font-extralight text-center px-13 mt-6">
                    Efficiently manage, monitor, export and organize all employee details at a click of a button.
                </p>

                <div class="grid grid-cols-3 w-auto h-auto justify-center px-10 py-6 gap-2 border-b border-b-gray-700">
                    <div class="border flex flex-col items-center p-2 rounded-sm border-gray-700 bg-gray-800 duration-100 transition-all hover:scale-105 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 text-green-400">
                            <path d="M3.375 3C2.339 3 1.5 3.84 1.5 4.875v.75c0 1.036.84 1.875 1.875 1.875h17.25c1.035 0 1.875-.84 1.875-1.875v-.75C22.5 3.839 21.66 3 20.625 3H3.375Z" />
                            <path fill-rule="evenodd" d="m3.087 9 .54 9.176A3 3 0 0 0 6.62 21h10.757a3 3 0 0 0 2.995-2.824L20.913 9H3.087ZM12 10.5a.75.75 0 0 1 .75.75v4.94l1.72-1.72a.75.75 0 1 1 1.06 1.06l-3 3a.75.75 0 0 1-1.06 0l-3-3a.75.75 0 1 1 1.06-1.06l1.72 1.72v-4.94a.75.75 0 0 1 .75-.75Z" clip-rule="evenodd" />
                        </svg>
                        <p class="mt-1 text-[12px] font-extralight">ARCHIVE</p>
                    </div>

                    <div class="border flex flex-col items-center p-2 rounded-sm border-gray-700 bg-gray-800 duration-100 transition-all hover:scale-105 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 text-green-400">
                            <path fill-rule="evenodd" d="M19.5 21a3 3 0 0 0 3-3V9a3 3 0 0 0-3-3h-5.379a.75.75 0 0 1-.53-.22L11.47 3.66A2.25 2.25 0 0 0 9.879 3H4.5a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h15Zm-6.75-10.5a.75.75 0 0 0-1.5 0v4.19l-1.72-1.72a.75.75 0 0 0-1.06 1.06l3 3a.75.75 0 0 0 1.06 0l3-3a.75.75 0 1 0-1.06-1.06l-1.72 1.72V10.5Z" clip-rule="evenodd" />
                        </svg>
                        <p class="mt-1 text-[12px] font-extralight">EXPORT</p>
                    </div>

                    <div class="border flex flex-col items-center p-2 rounded-sm border-gray-700 bg-gray-800 duration-100 transition-all hover:scale-105 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 text-green-400">
                            <path fill-rule="evenodd" d="M7.502 6h7.128A3.375 3.375 0 0 1 18 9.375v9.375a3 3 0 0 0 3-3V6.108c0-1.505-1.125-2.811-2.664-2.94a48.972 48.972 0 0 0-.673-.05A3 3 0 0 0 15 1.5h-1.5a3 3 0 0 0-2.663 1.618c-.225.015-.45.032-.673.05C8.662 3.295 7.554 4.542 7.502 6ZM13.5 3A1.5 1.5 0 0 0 12 4.5h4.5A1.5 1.5 0 0 0 15 3h-1.5Z" clip-rule="evenodd" />
                            <path fill-rule="evenodd" d="M3 9.375C3 8.339 3.84 7.5 4.875 7.5h9.75c1.036 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875h-9.75A1.875 1.875 0 0 1 3 20.625V9.375ZM6 12a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V12Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM6 15a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V15Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM6 18a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V18Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd" />
                        </svg>
                        <p class="mt-1 text-[12px] font-extralight">LISTS</p>
                    </div>
                </div>

                <div class="px-8 mt-3">
                    <p class="text-[10px] font-extralight text-gray-300">CREATED BY</p>
                    <p class="text-[12px] font-bold text-green-300">KURT BRYAN V. LAURETA & RAVEN BLAIR D. NOBLEZA</p>
                    <p class="text-[10px] font-extralight text-gray-300">© 2026 INTERN · All rights reserved.</p>
                </div>
            </div>
        </section>

        <!-- right card -->
        <div class="flex bg-white p-8 h-120 w-[400px] items-center flex-col shadow-xl max-sm:rounded-t-2xl md:rounded-r-2xl">
            <h1 class="text-2xl font-extrabold">WELCOME BACK</h1>
            <h2 class="text-[12px] font-light mb-8">Sign in to your account</h2>

            <form method="POST" action="" class="w-full" autocomplete="off">
                <p class="text-[15px] mb-1 ml-1 font-bold font-sans text-green-700">USERNAME</p>
                <div class="relative mb-3">
                    <input
                        type="text"
                        name="username"
                        value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                        placeholder="Enter your username"
                        class="w-full rounded-2xl border border-gray-300 bg-gray-300 py-3 pl-12 pr-3 text-gray-900 placeholder-grey-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="absolute left-3 top-1/2 h-5 w-5 transform -translate-y-1/2 text-black pointer-events-none">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
                    </svg>
                </div>

                <p class="text-[15px] mb-1 ml-1 font-bold font-sans text-green-700">PASSWORD</p>
                <div class="relative mb-3">
                    <input
                        type="password"
                        name="password"
                        id="passwordField"
                        placeholder="Enter your password"
                        class="w-full rounded-2xl border border-gray-300 bg-gray-300 py-3 pl-12 pr-12 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        oninput="toggleEyeIcon()"
                    >

                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="absolute left-3 top-1/2 h-5 w-5 transform -translate-y-1/2 text-black pointer-events-none">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />
                    </svg>

                    <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" onclick="togglePasswordVisibility()" viewBox="0 0 24 24" fill="currentColor" class="absolute right-3 top-1/2 h-5 w-5 transform -translate-y-1/2 text-black cursor-pointer opacity-0 pointer-events-none transition-all duration-200">
                        <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                        <path fill-rule="evenodd" d="M1.323 11.447C2.811 6.976 7.028 3.75 12.001 3.75c4.97 0 9.185 3.223 10.675 7.69.12.362.12.752 0 1.113-1.487 4.471-5.705 7.697-10.677 7.697-4.97 0-9.186-3.223-10.675-7.69a1.762 1.762 0 0 1 0-1.113ZM17.25 12a5.25 5.25 0 1 1-10.5 0 5.25 5.25 0 0 1 10.5 0Z" clip-rule="evenodd" />
                    </svg>
                </div>

                <button type="submit" class="border-4 cursor-pointer w-full py-2 px-4 mt-2 rounded-4xl text-green-700 font-medium duration-100 transition-all hover:bg-green-400 hover:border-green-400 hover:text-green-950 text-center">
                    Login
                </button>
            </form>

            <?php if (!empty($error)): ?>
                <div class="w-full mt-4 rounded-xl bg-red-100 text-red-700 px-4 py-2 text-sm text-center">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function togglePasswordVisibility() {
            const passwordField = document.getElementById('passwordField');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
            } else {
                passwordField.type = 'password';
            }
        }

        function toggleEyeIcon() {
            const passwordField = document.getElementById('passwordField');
            const eyeIcon = document.getElementById('eyeIcon');

            if (passwordField.value.length > 0) {
                eyeIcon.classList.remove('opacity-0', 'pointer-events-none');
                eyeIcon.classList.add('opacity-100', 'pointer-events-auto');
            } else {
                eyeIcon.classList.remove('opacity-100', 'pointer-events-auto');
                eyeIcon.classList.add('opacity-0', 'pointer-events-none');
            }
        }

        document.addEventListener("DOMContentLoaded", function () {
            toggleEyeIcon();
        });
    </script>
</body>
</html>
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";
date_default_timezone_set('Asia/Manila');

$conn->query("SET time_zone = '+08:00'");

if (isset($_SESSION["user_id"])) {
    $user_id = (int) $_SESSION["user_id"];

    $stmt = $conn->prepare("UPDATE users SET status = 'offline', last_activity = NOW() WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
}

$_SESSION = [];
session_unset();
session_destroy();

header("Location: login.php");
exit;
?>
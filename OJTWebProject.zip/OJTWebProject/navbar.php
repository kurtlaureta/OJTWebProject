<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$username = $_SESSION['username'] ?? 'User';
$role = $_SESSION['role'] ?? 'HR MANAGER';
?>

<style type="text/tailwindcss">
    @layer base{
        ul{
            @apply mt-3 ;
        }
    }
</style>

<script>
    function openLogoutModal() {
        const modal = document.getElementById("logoutModal");
        modal.classList.remove("hidden");
        modal.classList.add("flex");
    }

    function closeLogoutModal() {
        const modal = document.getElementById("logoutModal");
        modal.classList.remove("flex");
        modal.classList.add("hidden");
    }

    window.addEventListener("click", function(e) {
        const modal = document.getElementById("logoutModal");
        if (e.target === modal) {
            closeLogoutModal();
        }
    });
</script>
<nav class="h-screen w-fit bg-gray-900 flex flex-col justify-between fixed">
    <div>
        <div class="flex flex-col items-center border-b border-gray-700">
            <div class="m-4">
                <div class="font-bold flex flex-row-reverse justify-end text-white">
                    FASTOCK
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-6 mr-1 text-green-300">
                        <path fill-rule="evenodd" d="M4.5 3.75a3 3 0 0 0-3 3v10.5a3 3 0 0 0 3 3h15a3 3 0 0 0 3-3V6.75a3 3 0 0 0-3-3h-15Zm4.125 3a2.25 2.25 0 1 0 0 4.5 2.25 2.25 0 0 0 0-4.5Zm-3.873 8.703a4.126 4.126 0 0 1 7.746 0 .75.75 0 0 1-.351.92 7.47 7.47 0 0 1-3.522.877 7.47 7.47 0 0 1-3.522-.877.75.75 0 0 1-.351-.92ZM15 8.25a.75.75 0 0 0 0 1.5h3.75a.75.75 0 0 0 0-1.5H15ZM14.25 12a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H15a.75.75 0 0 1-.75-.75Zm.75 2.25a.75.75 0 0 0 0 1.5h3.75a.75.75 0 0 0 0-1.5H15Z" clip-rule="evenodd" />
                    </svg>
                </div>
                <h1 class="text-[10px] font-medium text-gray-400 mt-1">FASTOCK EMPLOYEE MASTERLIST</h1>
            </div>
        </div>

        <div class="p-3">
            <ul class="flex flex-col text-white">
                <li class="border border-gray-800 w-full p-2 mt-4 rounded-2xl flex items-center text-[14px] duration-300 transition-all bg-gray-800 hover:border-green-300 hover:text-green-300;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 mb-1 mr-2">
                        <path d="M11.47 3.841a.75.75 0 0 1 1.06 0l8.69 8.69a.75.75 0 1 0 1.06-1.061l-8.689-8.69a2.25 2.25 0 0 0-3.182 0l-8.69 8.69a.75.75 0 1 0 1.061 1.06l8.69-8.689Z" />
                        <path d="m12 5.432 8.159 8.159c.03.03.06.058.091.086v6.198c0 1.035-.84 1.875-1.875 1.875H15a.75.75 0 0 1-.75-.75v-4.5a.75.75 0 0 0-.75-.75h-3a.75.75 0 0 0-.75.75V21a.75.75 0 0 1-.75.75H5.625a1.875 1.875 0 0 1-1.875-1.875v-6.198a2.29 2.29 0 0 0 .091-.086L12 5.432Z" />
                    </svg>
                    <a href="home.php" class="w-full h-full flex items-center text-center ">Home</a>
                </li>
                <li class="border border-gray-800 w-full p-2 mt-4 rounded-2xl flex items-center text-[14px] duration-300 transition-all bg-gray-800 hover:border-green-300 hover:text-green-300;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 mb-1 mr-2">
                        <path fill-rule="evenodd" d="M7.502 6h7.128A3.375 3.375 0 0 1 18 9.375v9.375a3 3 0 0 0 3-3V6.108c0-1.505-1.125-2.811-2.664-2.94a48.972 48.972 0 0 0-.673-.05A3 3 0 0 0 15 1.5h-1.5a3 3 0 0 0-2.663 1.618c-.225.015-.45.032-.673.05C8.662 3.295 7.554 4.542 7.502 6ZM13.5 3A1.5 1.5 0 0 0 12 4.5h4.5A1.5 1.5 0 0 0 15 3h-1.5Z" clip-rule="evenodd" />
                        <path fill-rule="evenodd" d="M3 9.375C3 8.339 3.84 7.5 4.875 7.5h9.75c1.036 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875h-9.75A1.875 1.875 0 0 1 3 20.625V9.375ZM6 12a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V12Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM6 15a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V15Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM6 18a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V18Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd" />
                    </svg>
                    <a href="employee.php" class="w-full h-full flex items-center">Employee List</a>
                </li>
                <li class="border border-gray-800 w-full p-2 mt-4 rounded-2xl flex items-center text-[14px] duration-300 transition-all bg-gray-800 hover:border-green-300 hover:text-green-300;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 mb-1 mr-2">
                        <path d="M3.375 3C2.339 3 1.5 3.84 1.5 4.875v.75c0 1.036.84 1.875 1.875 1.875h17.25c1.035 0 1.875-.84 1.875-1.875v-.75C22.5 3.839 21.66 3 20.625 3H3.375Z" />
                        <path fill-rule="evenodd" d="m3.087 9 .54 9.176A3 3 0 0 0 6.62 21h10.757a3 3 0 0 0 2.995-2.824L20.913 9H3.087Zm6.163 3.75A.75.75 0 0 1 10 12h4a.75.75 0 0 1 0 1.5h-4a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd" />
                    </svg>
                    <a href="archiveemployee.php" class="w-full h-full flex items-center">Archive</a>
                </li>
                <!-- <li>
                    <a href="fastock_employee_import_export_template.xlsx" download class="w-full h-full flex items-center">
                        Download Template
                    </a>
                </li> -->
                <?php if (isset($_SESSION["role"]) && strtolower($_SESSION["role"]) === "admin"): ?>
                    <li class="border border-gray-800 w-full p-2 mt-4 rounded-2xl flex items-center text-[14px] duration-300 transition-all bg-gray-800 hover:border-green-300 hover:text-green-300;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 mb-1 mr-2">
                            <path fill-rule="evenodd" d="M7.5 6a4.5 4.5 0 1 1 9 0 4.5 4.5 0 0 1-9 0ZM3.751 20.105a8.25 8.25 0 0 1 16.498 0 .75.75 0 0 1-.437.695A18.683 18.683 0 0 1 12 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 0 1-.437-.695Z" clip-rule="evenodd" />
                        </svg>

                        <a href="users.php" class=" w-full h-full">
                            Users
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
            
        </div>
        
    </div>

    <div class="px-2 border-t border-gray-700">
        <div class="flex w-full bg-gray-800 p-3 rounded-2xl mt-4">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-12 text-green-300">
                <path fill-rule="evenodd" d="M18.685 19.097A9.723 9.723 0 0 0 21.75 12c0-5.385-4.365-9.75-9.75-9.75S2.25 6.615 2.25 12a9.723 9.723 0 0 0 3.065 7.097A9.716 9.716 0 0 0 12 21.75a9.716 9.716 0 0 0 6.685-2.653Zm-12.54-1.285A7.486 7.486 0 0 1 12 15a7.486 7.486 0 0 1 5.855 2.812A8.224 8.224 0 0 1 12 20.25a8.224 8.224 0 0 1-5.855-2.438ZM15.75 9a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" clip-rule="evenodd" />
            </svg>
            <div class="ml-2 self-center text-center">
                <h1 class="text-white text-[15px] mb-1"><?php echo htmlspecialchars($username); ?></h1>
                <h1 class="text-[10px] text-white"><?php echo htmlspecialchars($role); ?></h1>
            </div>
        </div>
        <!-- logout button -->
        <a href="#"
            onclick="openLogoutModal()"
            class="flex text-red-400 border border-red-500 rounded-[14px] justify-center mt-4 mb-4 p-1 duration-300 transition-all hover:bg-red-500 hover:text-black">
            Logout
        </a>

        <div id="logoutModal" class="hidden fixed inset-0 bg-black/50 z-50 items-center justify-center">
            <div class="bg-white w-[90%] max-w-md rounded-2xl shadow-2xl p-6 animate-[fadeIn_.2s_ease-in-out]">
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center text-red-600 text-2xl">
                        ⚠
                    </div>
                    <div>
                        <h2 class="text-xl font-bold text-gray-800">Confirm Logout</h2>
                        <p class="text-sm text-gray-500">You are about to end your session.</p>
                    </div>
                </div>

                <p class="text-gray-700 mb-6">
                    Are you sure you want to log out?
                </p>

                <div class="flex justify-end gap-3">
                    <button onclick="closeLogoutModal()"
                            class="px-4 py-2 rounded-xl bg-gray-200 text-gray-700 hover:bg-gray-300 transition">
                        Cancel
                    </button>

                    <a href="logout.php"
                    class="px-4 py-2 rounded-xl bg-red-600 text-white hover:bg-red-700 transition">
                    Yes, Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
</nav>
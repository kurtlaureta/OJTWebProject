<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

include "db.php";

$id = (int)($_GET["id"] ?? 0);
$employee_id = trim($_GET["employee_id"] ?? "");

if ($id <= 0 || $employee_id === "") {
    die("Invalid request.");
}

/*
|--------------------------------------------------------------------------
| Check if employee ID already exists in another record
|--------------------------------------------------------------------------
*/
$checkSql = "SELECT id FROM employees WHERE employee_id = ? AND id != ? LIMIT 1";
$checkStmt = $conn->prepare($checkSql);

if (!$checkStmt) {
    die("Error preparing duplicate check: " . $conn->error);
}

$checkStmt->bind_param("si", $employee_id, $id);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult && $checkResult->num_rows > 0) {
    $checkStmt->close();
    die("Employee ID already exists.");
}

$checkStmt->close();

/*
|--------------------------------------------------------------------------
| Restore employee
|--------------------------------------------------------------------------
*/
$restoreSql = "UPDATE employees
               SET employee_id = ?, employment_status = 'Active', is_archived = 0
               WHERE id = ?";

$restoreStmt = $conn->prepare($restoreSql);

if (!$restoreStmt) {
    die("Error preparing restore statement: " . $conn->error);
}

$restoreStmt->bind_param("si", $employee_id, $id);

if ($restoreStmt->execute()) {
    $restoreStmt->close();
    header("Location: archiveemployee.php?msg=restored");
    exit;
} else {
    $error = $restoreStmt->error;
    $restoreStmt->close();
    die("Error restoring employee: " . $error);
}
?>
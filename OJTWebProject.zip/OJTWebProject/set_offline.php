<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";
date_default_timezone_set('Asia/Manila');

if (!isset($_SESSION["user_id"])) {
    http_response_code(200);
    exit;
}

$user_id = (int) $_SESSION["user_id"];

$conn->query("SET time_zone = '+08:00'");

$stmt = $conn->prepare("UPDATE users SET status = 'offline', last_activity = NOW() WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();

http_response_code(200);
exit;
?>
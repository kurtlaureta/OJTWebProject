<?php
include "admin_only.php";
include "users_functions.php";

date_default_timezone_set('Asia/Manila');

if (isset($conn)) {
    $conn->query("SET time_zone = '+08:00'");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users Management</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-gray-950 text-white min-h-screen">

    <div class="max-w-7xl mx-auto p-6">
        <div class="flex items-center justify-between mb-6">
            <div>
                <h1 class="text-3xl font-bold">Users Management</h1>
                <p class="text-gray-400">Admin-only user monitoring and account creation</p>
            </div>

            <div class="flex items-center gap-3">
                <a href="home.php"
                   class="px-4 py-2 rounded-xl bg-gray-700 hover:bg-gray-600 transition text-white">
                    ← Back to Home
                </a>

                <button onclick="openCreateModal()"
                        class="px-4 py-2 rounded-xl bg-green-600 hover:bg-green-700 transition">
                    + Create User
                </button>
            </div>
        </div>

        <div class="overflow-x-auto bg-gray-900 rounded-2xl shadow-lg border border-gray-800">
            <table class="w-full text-left">
                <thead class="bg-gray-800 text-gray-200">
                    <tr>
                        <th class="px-4 py-3">ID</th>
                        <th class="px-4 py-3">Username</th>
                        <th class="px-4 py-3">Role</th>
                        <th class="px-4 py-3">Status</th>
                        <th class="px-4 py-3">Last Activity</th>
                        <th class="px-4 py-3">How Long Ago</th>
                        <th class="px-4 py-3">Created</th>
                    </tr>
                </thead>
                <tbody id="usersTableBody" class="transition-opacity duration-300">
                    <?php include "users_table.php"; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Create User Modal -->
    <div id="createUserModal" class="hidden fixed inset-0 bg-black/60 z-50 items-center justify-center">
        <div class="bg-white text-black w-[90%] max-w-lg rounded-2xl p-6 shadow-2xl">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-2xl font-bold">Create User Account</h2>
                <button onclick="closeCreateModal()" class="text-gray-500 hover:text-black text-xl">✕</button>
            </div>

            <form action="create_user.php" method="POST" class="space-y-4" autocomplete="off">
                <div>
                    <label class="block mb-1 font-medium">Username</label>
                    <input type="text" name="username" required
                           class="w-full border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block mb-1 font-medium">Password</label>
                    <input type="password" name="password" required
                           class="w-full border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block mb-1 font-medium">Role</label>
                    <select name="role"
                            class="w-full border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="user">User</option>
                        <option value="staff">Staff</option>
                        <option value="employee">Employee</option>
                        <option value="manager">Manager</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>

                <div class="flex justify-end gap-3 pt-2">
                    <button type="button" onclick="closeCreateModal()"
                            class="px-4 py-2 rounded-xl bg-gray-300 hover:bg-gray-400 transition">
                        Cancel
                    </button>
                    <button type="submit"
                            class="px-4 py-2 rounded-xl bg-green-600 text-white hover:bg-green-700 transition">
                        Create Account
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openCreateModal() {
            const modal = document.getElementById("createUserModal");
            modal.classList.remove("hidden");
            modal.classList.add("flex");
        }

        function closeCreateModal() {
            const modal = document.getElementById("createUserModal");
            modal.classList.remove("flex");
            modal.classList.add("hidden");
        }

        window.addEventListener("click", function(e) {
            const modal = document.getElementById("createUserModal");
            if (e.target === modal) {
                closeCreateModal();
            }
        });

        let isRefreshing = false;

        async function refreshUsersTable() {
            const tableBody = document.getElementById("usersTableBody");
            const modal = document.getElementById("createUserModal");

            if (!tableBody || isRefreshing) return;

            if (modal && modal.classList.contains("flex")) {
                return;
            }

            isRefreshing = true;

            try {
                tableBody.style.opacity = "0.55";

                const response = await fetch("users_table.php?ts=" + Date.now(), {
                    method: "GET",
                    cache: "no-store",
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    }
                });

                if (!response.ok) {
                    throw new Error("Failed to fetch users table");
                }

                const html = await response.text();

                setTimeout(() => {
                    tableBody.innerHTML = html;
                    tableBody.style.opacity = "1";
                    isRefreshing = false;
                }, 180);

            } catch (error) {
                console.error("Auto-refresh failed:", error);
                tableBody.style.opacity = "1";
                isRefreshing = false;
            }
        }

        async function sendHeartbeat() {
            try {
                await fetch("heartbeat.php?ts=" + Date.now(), {
                    method: "GET",
                    cache: "no-store"
                });
            } catch (error) {
                console.error("Heartbeat failed:", error);
            }
        }

        setInterval(sendHeartbeat, 10000);
        setInterval(refreshUsersTable, 10000);

        window.addEventListener("beforeunload", function() {
            navigator.sendBeacon("set_offline.php");
        });
    </script>

</body>
</html>
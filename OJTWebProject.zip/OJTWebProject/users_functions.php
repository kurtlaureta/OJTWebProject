<?php
date_default_timezone_set('Asia/Manila');

if (!function_exists('timeAgo')) {
    function timeAgo($datetime) {
        if (empty($datetime) || $datetime === "0000-00-00 00:00:00") {
            return "No activity";
        }

        $timestamp = strtotime($datetime);
        if (!$timestamp) {
            return "No activity";
        }

        $diff = time() - $timestamp;
        if ($diff < 0) $diff = 0;

        if ($diff < 10) return "Just now";
        if ($diff < 60) return $diff . " sec ago";
        if ($diff < 3600) return floor($diff / 60) . " min ago";
        if ($diff < 86400) return floor($diff / 3600) . " hr ago";
        if ($diff < 2592000) return floor($diff / 86400) . " day(s) ago";

        return date("M d, Y h:i A", $timestamp);
    }
}

if (!function_exists('getLiveStatus')) {
    function getLiveStatus($status, $last_activity) {
        if (strtolower((string)$status) === 'offline') {
            return 'offline';
        }

        if (empty($last_activity) || $last_activity === "0000-00-00 00:00:00") {
            return 'offline';
        }

        $timestamp = strtotime($last_activity);
        if (!$timestamp) {
            return 'offline';
        }

        $diff = time() - $timestamp;
        if ($diff < 0) $diff = 0;

        // shorter window para mas accurate
        return ($diff <= 30) ? 'online' : 'offline';
    }
}
?>
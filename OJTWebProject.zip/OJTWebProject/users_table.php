<?php
include "admin_only.php";
include "users_functions.php";

date_default_timezone_set('Asia/Manila');

if (isset($conn)) {
    $conn->query("SET time_zone = '+08:00'");
}

$sql = "SELECT id, username, role, status, last_activity, created_at
        FROM users
        ORDER BY created_at DESC";

$result = $conn->query($sql);
?>

<?php if ($result && $result->num_rows > 0): ?>
    <?php while ($user = $result->fetch_assoc()): ?>
        <?php $live_status = getLiveStatus($user["status"], $user["last_activity"]); ?>
        <tr class="border-t border-gray-800 hover:bg-gray-800/60 transition-all duration-300">
            <td class="px-4 py-3"><?php echo (int)$user["id"]; ?></td>
            <td class="px-4 py-3"><?php echo htmlspecialchars($user["username"]); ?></td>
            <td class="px-4 py-3 capitalize"><?php echo htmlspecialchars($user["role"]); ?></td>
            <td class="px-4 py-3">
                <?php if ($live_status === "online"): ?>
                    <span class="px-3 py-1 rounded-full text-sm bg-green-500/20 text-green-400 border border-green-500/30">
                        Online
                    </span>
                <?php else: ?>
                    <span class="px-3 py-1 rounded-full text-sm bg-red-500/20 text-red-400 border border-red-500/30">
                        Offline
                    </span>
                <?php endif; ?>
            </td>
            <td class="px-4 py-3">
                <?php
                echo (!empty($user["last_activity"]) && $user["last_activity"] !== "0000-00-00 00:00:00")
                    ? date("M d, Y h:i A", strtotime($user["last_activity"]))
                    : "No activity";
                ?>
            </td>
            <td class="px-4 py-3 text-gray-300">
                <?php echo timeAgo($user["last_activity"]); ?>
            </td>
            <td class="px-4 py-3">
                <?php
                echo (!empty($user["created_at"]) && $user["created_at"] !== "0000-00-00 00:00:00")
                    ? date("M d, Y h:i A", strtotime($user["created_at"]))
                    : "No date";
                ?>
            </td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr>
        <td colspan="7" class="px-4 py-6 text-center text-gray-400">No users found.</td>
    </tr>
<?php endif; ?>